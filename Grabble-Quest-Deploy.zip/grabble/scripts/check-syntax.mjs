// Syntax-checks every JavaScript file in the project.
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const root = path.join(path.dirname(new URL(import.meta.url).pathname), '..');
let bad = 0;
const walk = (d) => { for (const f of fs.readdirSync(d, { withFileTypes: true })) { if (f.name === 'node_modules' || f.name === 'vendor') continue; const p = path.join(d, f.name); if (f.isDirectory()) walk(p); else if (/\.(m?js)$/.test(f.name)) { try { execFileSync(process.execPath, ['--check', p], { stdio: 'pipe' }); } catch (e) { bad++; console.error('FAIL', p, String(e.stderr)); } } } };
walk(root);
console.log(bad ? `${bad} file(s) failed` : 'all files parse');
process.exit(bad ? 1 : 0);
