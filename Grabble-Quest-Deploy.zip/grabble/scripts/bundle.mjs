// Bundles the whole client into ONE html page (inline script) for hosts that block separate script files.
// Usage: node scripts/bundle.mjs  -> dist/page.html
import fs from 'node:fs';
import path from 'node:path';
const root = path.join(path.dirname(new URL(import.meta.url).pathname), '..');
const THREE_URL = 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
const mods = new Map(); // id -> code
const file = (id) => id.startsWith('shared/') ? path.join(root, id) : path.join(root, 'public', id);
function resolve(from, spec) { return path.posix.normalize(path.posix.join(path.posix.dirname(from), spec)).replace(/^\/+/, '').replace(/^(\.\.\/)+/, ''); }
function visit(id) {
  if (mods.has(id)) return;
  if (id === 'js/three.js') { mods.set(id, null); return; }
  let src = fs.readFileSync(file(id), 'utf8');
  const exportsList = [];
  const deps = [];
  src = src.replace(/^import\s+\*\s+as\s+(\w+)\s+from\s+'([^']+)';?/gm, (m, ns, spec) => { const d = resolve(id, spec); deps.push(d); return `const ${ns} = __req('${d}');`; });
  src = src.replace(/^import\s+\{([^}]*)\}\s+from\s+'([^']+)';?/gm, (m, names, spec) => { const d = resolve(id, spec); deps.push(d); return `const {${names.replace(/\s+as\s+/g, ': ')}} = __req('${d}');`; });
  src = src.replace(/^export\s+\*\s+from\s+'([^']+)';?/gm, (m, spec) => { const d = resolve(id, spec); deps.push(d); return `Object.assign(__exports, __req('${d}'));`; });
  src = src.replace(/^export\s+\{([^}]*)\}\s+from\s+'([^']+)';?/gm, (m, names, spec) => { const d = resolve(id, spec); deps.push(d); const parts = names.split(',').map((s) => s.trim()).filter(Boolean); return `{ const __t = __req('${d}'); ${parts.map((p) => { const [a, b] = p.split(/\s+as\s+/); return `__exports.${b || a} = __t.${a};`; }).join(' ')} }`; });
  src = src.replace(/^export\s+\{([^}]*)\};?/gm, (m, names) => { names.split(',').map((s) => s.trim()).filter(Boolean).forEach((p) => { const [a, b] = p.split(/\s+as\s+/); exportsList.push([b || a, a]); }); return ''; });
  src = src.replace(/^export\s+(async\s+function|function\*?|class|const|let|var)\s+(\w+)/gm, (m, kw, name) => { exportsList.push([name, name]); return `${kw} ${name}`; });
  if (/^export\s+default/m.test(src)) throw new Error('export default not supported: ' + id);
  if (/^\s*(import|export)\s/m.test(src.replace(/\/\/.*$/gm, ''))) { const l = src.split('\n').find((x) => /^\s*(import|export)\s/.test(x)); throw new Error(`unhandled import/export in ${id}: ${l}`); }
  mods.set(id, `__def('${id}', function (__req, __exports) {\n${src}\n${exportsList.map(([e, l]) => `__exports.${e} = ${l};`).join('\n')}\n});`);
  deps.forEach(visit);
}
visit('js/main.js');
const order = [];
const seen = new Set();
// topological order (dependencies first) by scanning __req targets
function topo(id) { if (seen.has(id)) return; seen.add(id); const code = mods.get(id); if (code) for (const m of code.matchAll(/__req\('([^']+)'\)/g)) topo(m[1]); order.push(id); }
topo('js/main.js');
const body = order.map((id) => mods.get(id)).filter(Boolean).join('\n');
const runtime = `const __defs = {}, __cache = {};
const __def = (id, fn) => { __defs[id] = fn; };
const __req = (id) => { if (id === 'js/three.js') return THREE; if (__cache[id]) return __cache[id].e; const e = {}; __cache[id] = { e }; if (!__defs[id]) throw new Error('missing module ' + id); __defs[id](__req, e); return e; };`;
const bundle = `const __note = (t) => { const n = document.getElementById('vr-note'); if (n) { n.style.color = '#ff8a8a'; n.textContent = t; } };\nlet THREE;\ntry { THREE = await import('${THREE_URL}'); } catch (e) { __note('Could not load the 3D engine (Three.js) from the CDN: ' + (e && e.message ? e.message : e) + '. This host blocks it.'); throw e; }\n${runtime}\n${body}\ntry { __req('js/main.js'); } catch (e) { __note('Game crashed on start: ' + (e && e.stack ? e.stack.split('\\n').slice(0, 3).join(' | ') : e)); throw e; }\n`;
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist/bundle.mjs'), bundle);
const css = fs.readFileSync(path.join(root, 'public/css/style.css'), 'utf8');
const h = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
const bodyHtml = h.slice(h.indexOf('<body>') + 6, h.indexOf('</body>')).replace(/<script[^>]*><\/script>/g, '');
fs.writeFileSync(path.join(root, 'dist/page.html'), `<title>Grabble</title>\n<style>\n${css}\n</style>\n${bodyHtml}\n<script type="module">\n${bundle.replace(/<\/script/g, '<\\/script')}\n</script>\n`);
console.log('modules:', order.length, 'bundle bytes:', bundle.length);
