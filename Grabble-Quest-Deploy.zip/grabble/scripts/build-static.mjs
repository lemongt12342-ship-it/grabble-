// Builds dist/: the whole game as plain static files (solo play and the plaza need no server).
// Upload dist/ to any static host with https (Netlify Drop, Cloudflare Pages, GitHub Pages), then give the
// resulting link to pwabuilder.com to get an Android APK for the Quest.
import fs from 'node:fs';
import path from 'node:path';
const root = path.join(path.dirname(new URL(import.meta.url).pathname), '..');
const out = path.join(root, 'dist');
fs.rmSync(out, { recursive: true, force: true });
fs.cpSync(path.join(root, 'public'), out, { recursive: true });
fs.cpSync(path.join(root, 'shared'), path.join(out, 'shared'), { recursive: true });
console.log('Built', out);
