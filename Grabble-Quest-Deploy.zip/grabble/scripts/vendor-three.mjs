// Downloads Three.js r160 into public/js/vendor and points the shim at it, so the game no longer needs
// a CDN at runtime (useful for offline LAN play and a stricter CSP). Run once on a machine with internet:
//   npm run setup
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const url = 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
const res = await fetch(url);
if (!res.ok) { console.error('Download failed:', res.status); process.exit(1); }
const text = await res.text();
if (!text.includes('REVISION') || text.length < 500000) { console.error('Unexpected file contents, refusing to save.'); process.exit(1); }
const dir = path.join(root, 'public/js/vendor');
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(path.join(dir, 'three.module.js'), text);
fs.writeFileSync(path.join(root, 'public/js/three.js'), "export * from './vendor/three.module.js';\n");
console.log('Saved three.module.js sha256', crypto.createHash('sha256').update(text).digest('hex'));
console.log('Done. The game now loads Three.js from your own server.');
