// The Grabble simulation. One Sim = one room. It runs on the server for multiplayer and inside the
// browser for solo play, so both modes behave identically. Clients send poses and button states;
// everything that matters (movement, grabbing, scoring, roles) is decided here.

import { DT, LOCO, LIMITS, VERSION } from './constants.js';
import { add, sub, mul, dist, len, copy, clamp, r3, round, rng, cleanName, norm } from './util.js';
import { buildArena } from './arenas.js';
import { ITEMS, GLOVES } from './items.js';
import { newLoco, newPoseState, stepLoco, setPoseTarget, approachPose, handWorld, head } from './loco.js';
import { pointInBox } from './collide.js';
import { MODES } from './modes/index.js';
import { MODIFIERS } from './modifiers.js';
import * as SI from './simitems.js';
import * as SH from './simhaz.js';
import { stepBot } from './bots.js';

const HEX = /^#[0-9a-fA-F]{6}$/;
export const COSMETIC_KEYS = ['fur', 'accent', 'glove', 'hat', 'trail', 'pet', 'emote', 'pose', 'voice', 'skin'];

export class Sim {
  constructor(opts = {}) {
    this.opts = opts;
    this.modeId = MODES[opts.mode] ? opts.mode : 'sandbox';
    this.mode = MODES[this.modeId];
    this.seed = (opts.seed ?? 1) >>> 0;
    this.rng = rng(this.seed ^ 0xabc123);
    this.kidSafe = !!opts.kidSafe;
    this.difficulty = opts.difficulty || 'normal';
    const pick = this.mode.arena ? this.mode.arena(this, opts) : { kind: 'courtyard', theme: 'toybox' };
    this.arenaKind = opts.arenaKind || pick.kind;
    this.themeId = opts.theme || pick.theme || 'toybox';
    this.arena = this.mode.buildArena ? this.mode.buildArena(this, opts) : buildArena(this.arenaKind, this.themeId, this.seed);
    if (this.mode.buildArena) this.arena.colliders.forEach((c, i) => { c.id = i; if (c.on === undefined) c.on = true; });
    this.cols = this.arena.colliders;
    this.zones = this.arena.zones.map((z) => ({ ...z }));
    this.hazards = this.arena.hazards.map((h, i) => ({ ...h, id: i + 1 }));
    this.t = 0;
    this.tickN = 0;
    this.phase = 'lobby';
    this.countdown = 0;
    this.timeLeft = this.mode.time || 0;
    this.players = new Map();
    this.items = new Map();
    this.ents = new Map();
    this.nid = 0;
    this.events = [];
    this.env = { gravity: this.arena.gravity, waterY: this.arena.waterY };
    this.lava = this.arena.lava ? { y: this.arena.lava.y0, vy: 0 } : null;
    this.mods = [];
    this.noises = [];
    this.result = null;
    this.mdata = {};
    this.itemsAuto = true;
    this.botCount = 0;
    for (const m of opts.mods || []) if (MODIFIERS[m] && !this.mods.includes(m)) this.mods.push(m);
    for (const m of this.mods) MODIFIERS[m].apply(this);
    if (this.mode.auto) { this.begin(); this.phase = 'play'; }
  }

  info() {
    return { v: VERSION, mode: this.modeId, kind: this.arenaKind, theme: this.themeId, seed: this.seed, mods: this.mods, kid: this.kidSafe, diff: this.difficulty, level: this.level || 0 };
  }

  // ---------------------------------------------------------------------------------------------
  // players
  addPlayer(id, o = {}) {
    if (this.players.size >= LIMITS.maxPlayers) return null;
    const ps = newPoseState();
    const cos = {};
    const src = o.cos || {};
    for (const k of COSMETIC_KEYS) {
      const v = src[k];
      if (typeof v === 'string' && (HEX.test(v) || /^[a-z0-9_]{1,24}$/.test(v))) cos[k] = v;
    }
    if (!GLOVES[cos.glove]) cos.glove = 'none';
    const p = {
      id, name: cleanName(o.name, 'Player'), bot: !!o.bot, team: 0, role: '', alive: true, spec: false,
      root: [0, 0, 0], vel: [0, 0, 0], yaw: 0, rel: ps.rel, target: ps.target,
      grip: [0, 0], use: [0, 0], prevGrip: [0, 0], prevUse: [0, 0], stamina: 1, hp: 100, maxHp: 100,
      score: 0, stats: {}, fx: {}, hold: [null, null], loco: newLoco(), cos,
      handScale: [1, 1], reach: 1, grabbing: [null, null], held: null, struggle: 0,
      noGrip: [0, 0], inv: null, seq: 0, ready: false, si: this.players.size, emoteT: 0, sanity: 1, dg: null,
      ai: o.bot ? { goal: null, t: 0, wob: this.rng() * 6.28 } : null,
    };
    this.players.set(id, p);
    this.applyGear(p);
    this.respawn(p);
    this.emit({ e: 'join', id, name: p.name });
    if (this.mode.onJoin) this.mode.onJoin(this, p);
    return p;
  }

  applyGear(p) {
    const g = GLOVES[p.cos.glove] || GLOVES.none;
    const s = g.scale * (this.env.handScale || 1);
    p.handScale = [s, s];
    p.gear = g;
  }

  removePlayer(id) {
    const p = this.players.get(id);
    if (!p) return;
    SI.dropAll(this, p);
    this.players.delete(id);
    if (this.mode.onLeave) this.mode.onLeave(this, p);
    this.emit({ e: 'leave', id });
  }

  addBot(name) {
    const id = 'bot' + ++this.botCount;
    return this.addPlayer(id, { name: name || 'Bot ' + this.botCount, bot: true });
  }

  fillBots(n) {
    while (this.players.size < n && this.players.size < LIMITS.maxPlayers) this.addBot();
  }

  humans() { return [...this.players.values()].filter((p) => !p.bot); }
  list() { return [...this.players.values()]; }
  alive() { return [...this.players.values()].filter((p) => p.alive && !p.spec); }

  respawn(p, pos) {
    const sp = this.arena.spawns;
    const s = pos || (sp.length ? sp[(p.si + (this.tickN > 0 ? this.rng.int(sp.length) : 0)) % sp.length] : [0, 0.2, 0]);
    p.root = [s[0], s[1] + 0.05, s[2]];
    p.vel = [0, 0, 0];
    p.loco = newLoco();
    p.alive = true;
    p.struggle = 0;
    p.held = null;
    SI.dropAll(this, p);
    p.rel.h = [0, 1.6, 0];
    p.rel.l = [-0.25, 1.0, 0.3];
    p.rel.r = [0.25, 1.0, 0.3];
    p.target = { h: [0, 1.6, 0], l: [-0.25, 1.0, 0.3], r: [0.25, 1.0, 0.3], g: [0, 0], u: [0, 0] };
    p.loco.prevRel = [copy(p.rel.l), copy(p.rel.r)];
  }

  setPose(id, pose, seq) {
    const p = this.players.get(id);
    if (!p || p.bot) return;
    if (typeof seq === 'number' && seq > p.seq) p.seq = seq | 0;
    setPoseTarget(p, pose, p.reach);
  }

  action(id, a) {
    const p = this.players.get(id);
    if (!p || !a || typeof a !== 'object') return;
    if (a.a === 'ready') p.ready = !!a.v;
    else if (a.a === 'emote' && this.t - p.emoteT > 2 && typeof a.id === 'string' && /^[a-z0-9_]{1,24}$/.test(a.id)) {
      p.emoteT = this.t;
      this.emit({ e: 'emote', id, k: a.id });
    } else if (a.a === 'cos' && a.cos) {
      for (const k of COSMETIC_KEYS) {
        const v = a.cos[k];
        if (typeof v === 'string' && (HEX.test(v) || /^[a-z0-9_]{1,24}$/.test(v))) p.cos[k] = v;
      }
      if (!GLOVES[p.cos.glove]) p.cos.glove = 'none';
      this.applyGear(p);
    } else if (a.a === 'name') p.name = cleanName(a.name, p.name);
  }

  allReady() {
    const h = this.humans();
    return h.length > 0 && h.every((p) => p.ready);
  }

  // ---------------------------------------------------------------------------------------------
  // match flow
  begin() {
    for (const [, it] of this.items) it.dead = true;
    this.items.clear();
    this.ents.clear();
    this.cleanSetup = true;
    if (this.mode.init) this.mode.init(this);
    for (const m of this.mods) if (MODIFIERS[m].update) MODIFIERS[m].update(this, 0);
  }

  start() {
    if (this.phase !== 'lobby') return false;
    for (const p of this.players.values()) { p.score = 0; p.stats = {}; p.fx = {}; this.respawn(p); }
    this.timeLeft = this.mode.time || 0;
    this.begin();
    this.phase = 'countdown';
    this.countdown = 3;
    this.emit({ e: 'phase', ph: 'countdown' });
    return true;
  }

  endMatch(result) {
    if (this.phase === 'over') return;
    const ranking = this.list().map((p) => ({ id: p.id, name: p.name, score: Math.round(p.score), team: p.team, bot: p.bot, stats: p.stats })).sort((a, b) => b.score - a.score);
    this.result = { winners: [], reason: '', ranking, ...(result || {}) };
    if (!this.result.winners.length && ranking.length) this.result.winners = [ranking[0].id];
    this.phase = 'over';
    this.emit({ e: 'end', res: this.result });
  }

  // ---------------------------------------------------------------------------------------------
  // helpers used by modes
  emit(e) { if (this.events.length < LIMITS.maxEvents) this.events.push(e); }
  drainEvents() { const e = this.events; this.events = []; return e; }
  hasFx(p, k) { return (p.fx[k] || 0) > this.t; }
  setFx(p, k, dur) { p.fx[k] = this.t + dur; }
  stat(p, k, n = 1) { p.stats[k] = (p.stats[k] || 0) + n; }
  giveScore(p, n, why) { p.score += n; if (why) this.emit({ e: 'score', id: p.id, n, why }); }
  msg(text, id) { this.emit({ e: 'msg', text: String(text).slice(0, 80), id }); }
  body(p) { const h = head(p); return [h[0], h[1] - 0.35, h[2]]; }
  headPos(p) { return head(p); }
  zone(id) { return this.zones.find((z) => z.id === id); }
  addZone(z) { this.zones.push(z); return z; }
  removeZone(id) { this.zones = this.zones.filter((z) => z.id !== id); }
  inZone(pos, z) { return pointInBox(pos, z); }
  playersIn(z, f) { return this.list().filter((p) => p.alive && !p.spec && pointInBox(this.body(p), z) && (!f || f(p))); }
  itemsIn(z, f) { return [...this.items.values()].filter((it) => !it.holder && pointInBox(it.pos, z) && (!f || f(it))); }
  nearestPlayer(pos, f, maxD = 1e9) {
    let best = null, bd = maxD;
    for (const p of this.players.values()) {
      if (!p.alive || p.spec || (f && !f(p))) continue;
      const d = dist(pos, this.body(p));
      if (d < bd) { bd = d; best = p; }
    }
    return best;
  }
  spawnItem(type, pos, o = {}) { return SI.spawnItem(this, type, pos, o); }
  removeItem(it) { SI.removeItem(this, it); }
  eliminate(p, why) {
    if (!p.alive) return;
    p.alive = false;
    SI.dropAll(this, p);
    p.grabbing = [null, null];
    this.emit({ e: 'elim', id: p.id, why: why || '' });
    if (this.mode.onElim) this.mode.onElim(this, p, why);
  }
  knock(p, dir, power = 4, stun = 0.6) {
    SI.dropAll(this, p);
    p.vel = add(p.vel, mul(dir, power));
    p.loco.anchor = [null, null];
    this.setFx(p, 'stun', stun);
    this.emit({ e: 'sfx', k: 'bonk', pos: r3(this.body(p)) });
  }

  // ---------------------------------------------------------------------------------------------
  playerEnv(p) {
    const e = this.env;
    const pe = {
      gravity: e.gravity, waterY: e.waterY, iceAll: e.iceAll, bounceAll: e.bounceAll, reverse: e.reverse,
      maxSpeed: e.maxSpeed ?? LOCO.maxSpeed, handMask: [true, true], noAnchor: false,
    };
    if (this.hasFx(p, 'boost')) pe.maxSpeed = Math.max(pe.maxSpeed, LOCO.boostSpeed);
    if (this.hasFx(p, 'stun') || this.hasFx(p, 'hold')) { pe.handMask = [false, false]; pe.noAnchor = true; }
    if (e.oneHand) pe.handMask[1] = false;
    if (this.hasFx(p, 'slow')) pe.maxSpeed *= 0.55;
    return pe;
  }

  // ---------------------------------------------------------------------------------------------
  tick(dt = DT) {
    const ts = this.env.timeScale || 1;
    dt *= ts;
    this.t += dt;
    this.tickN++;
    if (this.phase === 'countdown') {
      this.countdown -= dt;
      if (this.countdown <= 0) { this.phase = 'play'; this.emit({ e: 'phase', ph: 'play' }); }
    }
    for (const m of this.mods) if (MODIFIERS[m].update) MODIFIERS[m].update(this, dt);

    const frozenAll = this.phase === 'countdown' || this.phase === 'over';
    for (const p of this.players.values()) {
      if (p.reach !== (this.hasFx(p, 'arms') ? 1.8 : 1) * (p.gear ? p.gear.reach : 1)) {
        p.reach = (this.hasFx(p, 'arms') ? 1.8 : 1) * (p.gear ? p.gear.reach : 1);
      }
      if (p.ai) { stepBot(this, p, dt); continue; }
      approachPose(p, dt);
      if (!p.alive) { p.vel = [0, 0, 0]; continue; }
      if (frozenAll && this.phase === 'countdown') { p.vel = [0, 0, 0]; continue; }
      if (this.hasFx(p, 'frozen')) { p.vel = [0, 0, 0]; continue; }
      SI.handleGrips(this, p);
      stepLoco(p, dt, this.cols, this.playerEnv(p));
      p.sanity = p.sanity ?? 1;
    }
    SI.stepHeld(this, dt);
    SI.stepPlayerGrabs(this, dt);
    SI.stepContests(this, dt);
    SI.stepItems(this, dt);
    SI.stepWeapons(this, dt);
    SH.stepHazards(this, dt);
    SH.stepEntities(this, dt);
    SH.stepCrumble(this, dt);

    for (const p of this.players.values()) {
      p.prevGrip = [p.grip[0], p.grip[1]];
      p.prevUse = [p.use[0], p.use[1]];
      if (p.alive && p.root[1] < this.arena.bounds.min[1] - 8 && !this.lava) this.fell(p);
    }
    if (this.phase === 'play') {
      if (this.mode.update) this.mode.update(this, dt);
      if (this.mode.time > 0 && this.phase === 'play') {
        this.timeLeft -= dt;
        if (this.timeLeft <= 0) {
          this.timeLeft = 0;
          this.endMatch(this.mode.finish ? this.mode.finish(this) : {});
        }
      }
    }
  }

  fell(p) {
    if (this.mode.onFall) return this.mode.onFall(this, p);
    this.respawn(p);
    this.emit({ e: 'sfx', k: 'fall', id: p.id });
  }

  // ---------------------------------------------------------------------------------------------
  // what clients see
  snapshot() {
    const pl = [];
    for (const p of this.players.values()) {
      const fx = [];
      for (const k in p.fx) if (p.fx[k] > this.t) fx.push(k);
      pl.push({
        i: p.id, p: r3(p.root), v: r3(p.vel, 1), y: round(p.yaw, 2), h: r3(p.rel.h), l: r3(p.rel.l), r: r3(p.rel.r),
        g: [round(p.grip[0], 1), round(p.grip[1], 1)], a: p.alive ? 1 : 0, t: p.team, ro: p.role, hp: Math.round(p.hp),
        st: round(p.stamina, 2), fx, sc: Math.round(p.score), hd: [p.hold[0] || 0, p.hold[1] || 0],
        ak: [p.loco.anchor[0] ? 1 : 0, p.loco.anchor[1] ? 1 : 0], by: p.held ? p.held.by : '', dg: p.dg || '',
        sn: round(p.sanity ?? 1, 2), q: p.seq, inv: p.inv || '',
      });
    }
    const it = [];
    for (const i of this.items.values()) {
      const o = { i: i.id, t: i.type, p: r3(i.pos), h: i.holder ? i.holder.pid : '', hd: i.holder ? i.holder.hand : 0 };
      if (i.state.heat !== undefined) o.s = round(i.state.heat, 2);
      if (i.on !== undefined) o.on = i.on ? 1 : 0;
      it.push(o);
    }
    const en = [];
    for (const e of this.ents.values()) en.push({ i: e.id, k: e.kind, p: r3(e.pos), y: round(e.yaw || 0, 2), hp: Math.round(e.hp), s: e.st || '', lv: e.lvl || 0, sc: e.scale || 1 });
    const dyn = [];
    for (const c of this.cols) if (c.dyn) dyn.push([c.id, c.on ? 1 : 0, ...c.min.map((v) => round(v, 2)), ...c.max.map((v) => round(v, 2))]);
    return {
      t: round(this.t, 2), ph: this.phase, tl: round(this.timeLeft, 1), cd: round(Math.max(0, this.countdown), 1),
      pl, it, en, dc: dyn, lv: this.lava ? round(this.lava.y, 2) : null,
      zn: this.zones.filter((z) => z.pub).map((z) => ({ id: z.id, kind: z.kind, min: z.min, max: z.max, team: z.team })),
      md: this.mode.pub ? this.mode.pub(this) : null, env: pubEnv(this.env),
    };
  }
}

function pubEnv(e) {
  return { silent: !!e.silent, blind: !!e.blackout, giant: e.handScale || 1, size: e.sizeNow || 1, heavy: !!e.heavyNow, g: e.gravity };
}
