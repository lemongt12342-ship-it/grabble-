// Arena builders. Deterministic from (kind, theme, seed), so the server never has to send geometry:
// every client rebuilds the same world from three small values.

import { box, boxC } from './collide.js';
import { rng } from './util.js';

export const THEMES = {
  toybox: { name: 'Toy Box', sky: '#8ec5ff', fog: '#cfe6ff', floor: '#5aa9f0', platform: '#69db7c', wall: '#ff8787', accent: '#ffd43b', gravity: 9.8 },
  candy: { name: 'Candy Factory', sky: '#ffd6e8', fog: '#ffc2dc', floor: '#f783ac', platform: '#ff8787', wall: '#fcc2d7', accent: '#ffec99', gravity: 9.8 },
  space: { name: 'Space Station', sky: '#070b1e', fog: '#0d1438', floor: '#495057', platform: '#748ffc', wall: '#343a40', accent: '#63e6be', gravity: 4.6 },
  attic: { name: 'Haunted Attic', sky: '#150f1f', fog: '#261a38', floor: '#5c4033', platform: '#7a5c45', wall: '#3d2b4f', accent: '#ffa94d', gravity: 9.8 },
  market: { name: 'Underwater Market', sky: '#0a3550', fog: '#0f5f82', floor: '#1c7ed6', platform: '#3bc9db', wall: '#1864ab', accent: '#ffe066', gravity: 9.8, water: true },
  volcano: { name: 'Volcano Base', sky: '#2b0d0a', fog: '#4a1710', floor: '#3b2a26', platform: '#6d4c41', wall: '#2a1b18', accent: '#ff922b', gravity: 9.8 },
  hub: { name: 'Spawn Plaza', sky: '#9ad0ff', fog: '#d8ecff', floor: '#74c0a8', platform: '#ffd8a8', wall: '#b197fc', accent: '#ffd43b', gravity: 9.8 },
  night: { name: 'Night Arena', sky: '#0e1330', fog: '#1b2250', floor: '#3b4672', platform: '#5f6f94', wall: '#283056', accent: '#ffd43b', gravity: 9.8 },
};
export const THEME_IDS = Object.keys(THEMES);

const plat = (cx, y, cz, w, d, th = 0.4, extra = {}) => boxC(cx, y - th / 2, cz, w, th, d, { c: 'platform', ...extra });
const pillar = (cx, cz, w, h, y0 = 0, extra = {}) => boxC(cx, y0 + h / 2, cz, w, h, w, { c: 'platform', grab: true, ...extra });
const wallBox = (min, max, extra = {}) => box(min, max, { c: 'wall', boundary: true, ...extra });

function floor(sx, sz, mat = 'stone') {
  return box([-sx / 2, -4, -sz / 2], [sx / 2, 0, sz / 2], { c: 'floor', mat });
}
function boundary(sx, sz, h, y0 = 0) {
  const t = 1, hx = sx / 2, hz = sz / 2;
  return [
    wallBox([-hx - t, y0 - 4, -hz - t], [hx + t, y0 + h, -hz]),
    wallBox([-hx - t, y0 - 4, hz], [hx + t, y0 + h, hz + t]),
    wallBox([-hx - t, y0 - 4, -hz], [-hx, y0 + h, hz]),
    wallBox([hx, y0 - 4, -hz], [hx + t, y0 + h, hz]),
  ];
}
function ring(n, radius, y, jitter = 0, r = null) {
  const out = [];
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + (r ? r.range(-jitter, jitter) : 0);
    out.push([Math.cos(a) * radius, y, Math.sin(a) * radius]);
  }
  return out;
}

function base(kind, themeId, seed, sx, sz) {
  const theme = THEMES[themeId] || THEMES.toybox;
  return {
    kind, themeId, seed, theme, size: [sx, sz],
    colliders: [], spawns: [], zones: [], props: [], hazards: [], itemSpots: [],
    bounds: { min: [-sx / 2, -30, -sz / 2], max: [sx / 2, 60, sz / 2] },
    lava: null, waterY: undefined, gravity: theme.gravity, kidSafe: true,
  };
}

// ---- hub: the spawn plaza with the computer, hoops, trophy wall and photo booth ----------------
function hub(themeId, seed) {
  const a = base('hub', themeId, seed, 36, 36);
  a.colliders.push(floor(36, 36), ...boundary(36, 36, 14));
  // The terminal desk and computer. Screen faces +z, toward the spawn.
  a.colliders.push(boxC(0, 0.5, -11, 3.2, 1.0, 1.0, { c: 'platform' }));
  a.terminal = { pos: [0, 1.65, -10.45], size: [1.7, 1.0], normal: [0, 0, 1] };
  a.props.push({ k: 'desk', pos: [0, 0.5, -11], s: [3.2, 1.0, 1.0] }, { k: 'monitor', pos: a.terminal.pos, s: [1.9, 1.2, 0.1] });
  a.zones.push({ id: 'terminal', kind: 'terminal', min: [-2, 0, -10.4], max: [2, 2.6, -6] });
  // spawn pad
  a.spawns = ring(8, 2.5, 0.2).map((p) => p);
  a.props.push({ k: 'pad', pos: [0, 0.02, 0], s: [7, 0.04, 7] });
  // basketball hoop and ring toss
  a.colliders.push(pillar(11, -9, 0.4, 3.4, 0, { grab: false }), plat(10.3, 3.2, -9, 1.4, 0.2, 0.15, { grab: false }));
  a.zones.push({ id: 'hoop', kind: 'hoop', min: [9.9, 2.6, -9.4], max: [10.7, 3.1, -8.6] });
  a.props.push({ k: 'hoop', pos: [10.3, 3.1, -9] });
  a.colliders.push(pillar(-11, -9, 0.3, 1.2, 0, { grab: false }));
  a.zones.push({ id: 'peg', kind: 'peg', min: [-11.3, 1.1, -9.3], max: [-10.7, 1.6, -8.7] });
  // trophy wall, photo booth, trade pads, claw machine
  a.props.push({ k: 'trophywall', pos: [0, 2.5, 17.5], s: [14, 4, 0.4] });
  a.props.push({ k: 'photobooth', pos: [-12, 1.2, 8], s: [2.5, 2.4, 2.5] });
  a.zones.push({ id: 'photo', kind: 'photo', min: [-13.5, 0, 6.5], max: [-10.5, 2.5, 9.5] });
  a.zones.push({ id: 'tradeA', kind: 'trade', min: [-9, 0.9, 3], max: [-7.6, 1.5, 4.4] }, { id: 'tradeB', kind: 'trade', min: [-6.4, 0.9, 3], max: [-5, 1.5, 4.4] });
  a.colliders.push(boxC(-8.3, 0.45, 3.7, 1.4, 0.9, 1.4, { c: 'platform' }), boxC(-5.7, 0.45, 3.7, 1.4, 0.9, 1.4, { c: 'platform' }));
  a.props.push({ k: 'claw', pos: [12, 1.6, 8], s: [3, 3.2, 3] });
  a.zones.push({ id: 'arcade', kind: 'arcade', min: [10, 0, 6], max: [14, 3, 10] });
  // a few climbable pillars and a ledge so new players can practice the arm-swing
  a.colliders.push(pillar(-6, -2, 1, 4), plat(-6, 4, 0.5, 2.5, 3, 0.4), pillar(6, 2, 1, 3));
  a.itemSpots = [[3, 0.3, 4], [-3, 0.3, 5], [5, 0.3, -4], [-5, 0.3, -4], [0, 0.3, 9]];
  a.bounds = { min: [-17, -10, -17], max: [17, 30, 17] };
  return a;
}

// ---- courtyard: the general purpose arena used by tag, hill, hot seat, hide and seek and more ----
function courtyard(themeId, seed) {
  const r = rng(seed ^ 0x51ed);
  const a = base('courtyard', themeId, seed, 44, 44);
  a.colliders.push(floor(44, 44), ...boundary(44, 44, 18));
  // one quadrant, mirrored four ways so no spawn is unfair
  const quad = [];
  for (let i = 0; i < 4; i++) {
    const x = r.range(3, 18), z = r.range(3, 18), t = r.pick(['platform', 'pillar', 'ramp', 'wall']);
    quad.push({ x, z, t, h: r.range(1.2, 4.5), w: r.range(2.5, 5) });
  }
  for (const q of quad) {
    for (const [sx, sz] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) {
      const x = q.x * sx, z = q.z * sz;
      if (q.t === 'platform') a.colliders.push(plat(x, q.h, z, q.w, q.w), pillar(x, z, 0.5, q.h - 0.2));
      else if (q.t === 'pillar') a.colliders.push(pillar(x, z, 1.1, q.h + 1.5));
      else if (q.t === 'ramp') for (let s = 0; s < 4; s++) a.colliders.push(boxC(x + sx * s * 1.1, (s + 1) * 0.4, z, 1.1, (s + 1) * 0.8, q.w, { c: 'platform' }));
      else a.colliders.push(boxC(x, 0.9, z, q.w, 1.8, 0.5, { c: 'wall' }));
    }
  }
  // central tower with a crown platform
  a.colliders.push(pillar(0, 0, 2, 6), plat(0, 6, 0, 5, 5), plat(-6, 3, 0, 3, 3), plat(6, 4.5, 0, 3, 3));
  a.spawns = ring(10, 14, 0.2);
  a.itemSpots = ring(16, 9, 0.4).concat(ring(8, 17, 0.4), [[0, 6.4, 0]]);
  themeProps(a, r);
  return a;
}

function themeProps(a, r) {
  const kinds = { candy: ['lollipop', 'gumdrop'], toybox: ['abcblock', 'toycar'], space: ['pod', 'antenna'], attic: ['crate', 'cobweb'], market: ['stall', 'coral'], volcano: ['rock', 'ember'], night: ['lamp', 'banner'], hub: ['flower'] }[a.themeId] || ['crate'];
  for (let i = 0; i < 18; i++) a.props.push({ k: r.pick(kinds), pos: [r.range(-20, 20), 0, r.range(-20, 20)], s: [1, r.range(1, 3), 1], rot: r.range(0, 6.28) });
}

// ---- lava pit: stepping platforms rising from a lava lake -----------------------------------------
function lavapit(themeId, seed) {
  const r = rng(seed ^ 0x1a7a);
  const a = base('lavapit', themeId, seed, 40, 40);
  a.colliders.push(box([-20, -14, -20], [20, -12, 20], { c: 'floor' }), ...boundary(40, 40, 36, -14));
  a.lava = { y0: -6, speed: 0.1, max: 22 };
  a.colliders.push(box([-6, -12, -6], [6, 0, 6], { c: 'platform', mat: 'stone', grab: false }));
  const n = 14;
  for (let i = 0; i < n; i++) {
    const ang = (i / n) * Math.PI * 2 * 2.2 + r.range(-0.3, 0.3), rad = 8 + (i / n) * 8 + r.range(-1, 1), y = 1.5 + (i / n) * 18;
    const x = Math.cos(ang) * rad, z = Math.sin(ang) * rad, w = r.range(2.6, 4);
    a.colliders.push(plat(x, y, z, w, w, 0.4, { crumble: i % 3 === 1, dyn: i % 3 === 1 }), pillar(x + w / 2 - 0.3, z, 0.4, 3.5, y - 3.5));
  }
  a.colliders.push(plat(0, 21, 0, 6, 6, 0.5));
  for (let i = 0; i < 6; i++) { // ice patches and ledges on the walls to climb
    const side = i % 4;
    const p = [[-19.4, 0], [19.4, 0], [0, -19.4], [0, 19.4]][side];
    a.colliders.push(boxC(p[0], 2 + i * 3, p[1] + (i - 3) * 2, side < 2 ? 1 : 0.6, 0.4, side < 2 ? 0.6 : 1, { c: 'platform', grab: true }));
  }
  a.spawns = ring(8, 3, 0.2);
  a.itemSpots = ring(6, 5, 0.4);
  a.hazards.push({ kind: 'geyser', pos: [-9, -6, 5], r: 1.6, period: 9, phase: 2 }, { kind: 'geyser', pos: [9, -6, -5], r: 1.6, period: 11, phase: 5 });
  a.bounds = { min: [-20, -14, -20], max: [20, 40, 20] };
  a.gravity = 9.8;
  return a;
}

// ---- tower: obstacle climb ---------------------------------------------------------------------------
function tower(themeId, seed) {
  const r = rng(seed ^ 0x70e7);
  const a = base('tower', themeId, seed, 30, 30);
  a.colliders.push(floor(30, 30), ...boundary(30, 30, 52));
  a.colliders.push(boxC(0, 20, 0, 5, 40, 5, { c: 'wall' }));
  const levels = 8;
  for (let l = 0; l < levels; l++) {
    const y = 1.2 + l * 5, ang0 = l * 1.3;
    a.colliders.push(plat(Math.cos(ang0) * 5.5, y + 2.4, Math.sin(ang0) * 5.5, 3.2, 3.2));
    for (let k = 0; k < 4; k++) { // ledges spiral up the tower
      const ang = ang0 + k * 0.5, yy = y + k * 1.2;
      a.colliders.push(boxC(Math.cos(ang) * 2.75, yy, Math.sin(ang) * 2.75, 0.9, 0.25, 0.9, { c: 'accent', grab: true }));
    }
    a.zones.push({ id: 'cp' + l, kind: 'checkpoint', index: l, min: [Math.cos(ang0) * 5.5 - 1.6, y + 2.4, Math.sin(ang0) * 5.5 - 1.6], max: [Math.cos(ang0) * 5.5 + 1.6, y + 4.4, Math.sin(ang0) * 5.5 + 1.6], spawn: [Math.cos(ang0) * 5.5, y + 2.6, Math.sin(ang0) * 5.5] });
    if (l % 2 === 1) a.hazards.push({ kind: 'blade', pos: [0, y + 3.2, 0], len: 7.5, speed: 1 + l * 0.12, r: 0.25 });
    if (l % 3 === 2) a.zones.push({ id: 'wind' + l, kind: 'wind', min: [-4, y, -8], max: [4, y + 5, 8], force: [r.pick([-6, 6]), 0, 0] });
  }
  a.colliders.push(plat(0, 41, 0, 7, 7, 0.5));
  a.zones.push({ id: 'finish', kind: 'finish', min: [-3, 41, -3], max: [3, 44, 3] });
  a.hazards.push({ kind: 'rocks', pos: [0, 44, 0], r: 10, period: 3.2 });
  a.spawns = ring(8, 11, 0.2);
  a.itemSpots = ring(6, 9, 0.4);
  a.bounds = { min: [-15, -10, -15], max: [15, 60, 15] };
  return a;
}

// ---- dodgeball court ---------------------------------------------------------------------------------
function dodge(themeId, seed) {
  const a = base('dodge', themeId, seed, 32, 18);
  a.colliders.push(floor(32, 18), ...boundary(32, 18, 8));
  a.colliders.push(boxC(0, 0.6, 0, 0.3, 1.2, 18, { c: 'wall', see: false }));
  a.zones.push({ id: 'teamA', kind: 'half', team: 0, min: [-16, -2, -9], max: [0, 6, 9] }, { id: 'teamB', kind: 'half', team: 1, min: [0, -2, -9], max: [16, 6, 9] });
  a.zones.push({ id: 'benchA', kind: 'bench', team: 0, min: [-18, 0, -9], max: [-16, 3, 9] }, { id: 'benchB', kind: 'bench', team: 1, min: [16, 0, -9], max: [18, 3, 9] });
  a.colliders.push(boxC(-6, 1, 0, 1.2, 2, 1.2, { c: 'platform', grab: true }), boxC(6, 1, 0, 1.2, 2, 1.2, { c: 'platform', grab: true }));
  a.spawns = [[-10, 0.2, -4], [-10, 0.2, 4], [-12, 0.2, 0], [-8, 0.2, 0], [-13, 0.2, 6], [10, 0.2, -4], [10, 0.2, 4], [12, 0.2, 0], [8, 0.2, 0], [13, 0.2, -6]];
  a.itemSpots = [[0, 0.3, -6], [0, 0.3, -2], [0, 0.3, 2], [0, 0.3, 6], [0, 0.3, 0], [0.5, 0.3, 4]];
  a.bounds = { min: [-17, -10, -9], max: [17, 12, 9] };
  return a;
}

// ---- capture the flag ---------------------------------------------------------------------------------
function ctf(themeId, seed) {
  const r = rng(seed ^ 0xcf1a);
  const a = base('ctf', themeId, seed, 50, 28);
  a.colliders.push(floor(50, 28), ...boundary(50, 28, 16));
  a.zones.push({ id: 'baseA', kind: 'base', team: 0, min: [-24, 0, -4], max: [-19, 4, 4], flag: [-22, 0.4, 0] }, { id: 'baseB', kind: 'base', team: 1, min: [19, 0, -4], max: [24, 4, 4], flag: [22, 0.4, 0] });
  for (const s of [1, -1]) {
    a.colliders.push(boxC(s * 14, 1.5, 0, 1, 3, 10, { c: 'wall' }), plat(s * 8, 3, 6, 4, 4), plat(s * 8, 3, -6, 4, 4), pillar(s * 8, 6, 0.6, 3), pillar(s * 8, -6, 0.6, 3), plat(s * 3, 5, 0, 3, 5));
    for (let i = 0; i < 2; i++) a.colliders.push(boxC(s * r.range(10, 18), 0.8, r.range(-10, 10), 2, 1.6, 2, { c: 'platform' }));
  }
  a.spawns = [[-20, 0.2, -6], [-20, 0.2, 6], [-18, 0.2, 0], [-22, 0.2, 8], [-22, 0.2, -8], [20, 0.2, -6], [20, 0.2, 6], [18, 0.2, 0], [22, 0.2, 8], [22, 0.2, -8]];
  a.itemSpots = [[0, 0.4, 0], [0, 0.4, 8], [0, 0.4, -8]];
  a.bounds = { min: [-25, -10, -14], max: [25, 20, 14] };
  return a;
}

// ---- vault: heist ---------------------------------------------------------------------------------------
function vault(themeId, seed) {
  const r = rng(seed ^ 0x7a17);
  const a = base('vault', themeId, seed, 40, 30);
  a.colliders.push(floor(40, 30), ...boundary(40, 30, 10));
  // inner wall with a door gap splits the entry hall (x<-4) from the vault (x>4)
  a.colliders.push(boxC(-4, 3, -9, 1, 6, 12, { c: 'wall' }), boxC(-4, 3, 9, 1, 6, 12, { c: 'wall' }), boxC(8, 3, -6, 1, 6, 18, { c: 'wall' }), boxC(8, 3, 12, 1, 6, 6, { c: 'wall' }));
  a.colliders.push(boxC(14, 0.6, -8, 2, 1.2, 2, { c: 'platform' }), boxC(14, 0.6, 8, 2, 1.2, 2, { c: 'platform' }), boxC(18, 0.6, 0, 2, 1.2, 4, { c: 'platform' }));
  a.zones.push({ id: 'exit', kind: 'exit', min: [-19, 0, -3], max: [-15, 4, 3] }, { id: 'vaultroom', kind: 'room', min: [8.5, 0, -15], max: [20, 8, 15] });
  for (let i = 0; i < 5; i++) a.hazards.push({ kind: 'laser', a: [9, 0.4 + i * 0.7, -14], b: [9, 0.4 + i * 0.7, -2], period: 4 + i, on: 2 + (i % 3), phase: i });
  a.hazards.push({ kind: 'laser', a: [-3.5, 0.5, -3], b: [-3.5, 2.5, 3], period: 6, on: 3, phase: 1 });
  a.spawns = ring(6, 3, 0.2).map((p) => [p[0] - 14, p[1], p[2]]);
  a.itemSpots = [[14, 1.4, -8], [14, 1.4, 8], [18, 1.4, 0], [16, 0.3, -12], [16, 0.3, 12], [11, 0.3, 0], [18, 0.3, -9], [18, 0.3, 9]];
  a.bounds = { min: [-20, -10, -15], max: [20, 12, 15] };
  return a;
}

// ---- kitchen --------------------------------------------------------------------------------------------
function kitchen(themeId, seed) {
  const a = base('kitchen', themeId, seed, 30, 24);
  a.colliders.push(floor(30, 24), ...boundary(30, 24, 8));
  a.colliders.push(boxC(0, 0.5, -9, 20, 1, 2, { c: 'platform' }), boxC(-10, 0.5, 0, 2, 1, 14, { c: 'platform' }), boxC(10, 0.5, 0, 2, 1, 14, { c: 'platform' }));
  a.zones.push({ id: 'pass', kind: 'pass', min: [-3, 0.9, -10], max: [3, 2.2, -8] });
  const types = ['bun', 'patty', 'lettuce', 'tomato', 'cheese', 'rice', 'fishfillet'];
  a.stations = types.map((t, i) => ({ item: t, pos: [-9.9 + (i < 3 ? 0 : 19.8), 1.2, -5 + (i % 4 === 3 ? 4.5 : (i % 3) * 3.5)] }));
  a.spawns = ring(5, 3, 0.2);
  a.itemSpots = a.stations.map((s) => s.pos);
  a.bounds = { min: [-15, -10, -12], max: [15, 10, 12] };
  return a;
}

// ---- conveyor hall -----------------------------------------------------------------------------------------
function belt(themeId, seed) {
  const a = base('belt', themeId, seed, 40, 24);
  a.colliders.push(floor(40, 24), ...boundary(40, 24, 8));
  for (let i = 0; i < 3; i++) {
    const z = -6 + i * 6;
    a.zones.push({ id: 'belt' + i, kind: 'belt', min: [-18, 0, z - 1], max: [14, 1.4, z + 1], vel: [1.2 + i * 0.4, 0, 0] });
    a.colliders.push(boxC(-2, 0.35, z, 32, 0.7, 2, { c: 'accent', mat: 'stone' }));
  }
  a.zones.push({ id: 'binA', kind: 'bin', team: 0, min: [15, 0, -9], max: [19, 3, -3] }, { id: 'binB', kind: 'bin', team: 1, min: [15, 0, 3], max: [19, 3, 9] }, { id: 'incinerator', kind: 'void', min: [14, 0, -7], max: [15, 2, 7] });
  a.spawns = ring(6, 3, 0.2).map((p) => [p[0] - 8, p[1], p[2] + 9]);
  a.itemSpots = [[-18, 1.8, -6], [-18, 1.8, 0], [-18, 1.8, 6]];
  a.bounds = { min: [-20, -10, -12], max: [20, 10, 12] };
  return a;
}

// ---- pool: treasure dive and the underwater market -------------------------------------------------
function pool(themeId, seed) {
  const r = rng(seed ^ 0x9001);
  const a = base('pool', themeId, seed, 36, 36);
  a.colliders.push(box([-18, -18, -18], [18, -14, 18], { c: 'floor' }), ...boundary(36, 36, 14, -18));
  a.waterY = 0;
  for (let i = 0; i < 12; i++) a.colliders.push(plat(r.range(-14, 14), -14 + r.range(0.8, 5), r.range(-14, 14), r.range(2, 5), r.range(2, 5), 0.6, { grab: true }));
  a.colliders.push(plat(0, 0.6, -15, 6, 3, 0.4));
  a.zones.push({ id: 'boat', kind: 'bin', team: 0, min: [-3, 0, -16.5], max: [3, 3, -13.5] });
  for (let i = 0; i < 4; i++) a.zones.push({ id: 'air' + i, kind: 'air', min: [-10 + i * 6, -9, -6 + (i % 2) * 8], max: [-8 + i * 6, -7, -4 + (i % 2) * 8] });
  a.spawns = ring(6, 2, 0.8).map((p) => [p[0], 0.8, p[2] - 12]);
  a.itemSpots = Array.from({ length: 24 }, () => [r.range(-14, 14), -13.6 + r.range(0, 3), r.range(-14, 14)]);
  a.bounds = { min: [-18, -18, -18], max: [18, 6, 18] };
  a.gravity = 9.8;
  return a;
}

// ---- stage: boss fight and survival arena ---------------------------------------------------------------
function stage(themeId, seed) {
  const a = base('stage', themeId, seed, 40, 40);
  a.colliders.push(floor(40, 40), ...boundary(40, 40, 20));
  for (const [x, z] of ring(6, 12, 0)) a.colliders.push(pillar(x, z, 1.6, 5), plat(x, 5, z, 3, 3));
  a.colliders.push(plat(0, 3, 14, 6, 3), plat(0, 3, -14, 6, 3), plat(14, 2, 0, 3, 6), plat(-14, 2, 0, 3, 6));
  a.spawns = ring(8, 4, 0.2);
  a.itemSpots = ring(10, 9, 0.4);
  a.zones.push({ id: 'boss', kind: 'boss', min: [-3, 0, -18], max: [3, 6, -14] });
  a.bounds = { min: [-20, -10, -20], max: [20, 24, 20] };
  return a;
}

// ---- sandbox: a free-play room ------------------------------------------------------------------------------
function sandbox(themeId, seed) {
  const a = base('sandbox', themeId, seed, 36, 36);
  a.colliders.push(floor(36, 36), ...boundary(36, 36, 14));
  a.colliders.push(boxC(0, 0.5, 0, 1.2, 1, 1.2, { c: 'accent' }), pillar(8, 8, 1, 3), plat(8, 3, 8, 4, 4), pillar(-8, -8, 1, 2.2), plat(-8, 2.2, -8, 4, 4));
  a.zones.push({ id: 'spawner', kind: 'spawner', min: [-0.8, 1, -0.8], max: [0.8, 2.2, 0.8] });
  a.spawns = ring(6, 5, 0.2);
  a.itemSpots = [[0, 1.4, 0]];
  a.bounds = { min: [-18, -10, -18], max: [18, 30, 18] };
  return a;
}

const BUILDERS = { hub, courtyard, lavapit, tower, dodge, ctf, vault, kitchen, belt, pool, stage, sandbox };
export const ARENA_KINDS = Object.keys(BUILDERS);

export function buildArena(kind, themeId = 'toybox', seed = 1) {
  const fn = BUILDERS[kind];
  if (!fn) throw new Error('unknown arena ' + kind);
  const a = fn(THEMES[themeId] ? themeId : 'toybox', seed >>> 0);
  a.colliders.forEach((c, i) => { c.id = i; if (c.on === undefined) c.on = true; });
  return a;
}
