// Hazards, zones, crumbling platforms and entities (monsters, decoys, bosses) for the Sim.

import { dist, add, sub, mul, norm, copy, len, r3, distXZ, clamp } from './util.js';
import { pointInBox } from './collide.js';
import { head } from './loco.js';

export function spawnEntity(sim, kind, pos, o = {}) {
  const e = { id: ++sim.nid, kind, pos: copy(pos), vel: [0, 0, 0], yaw: 0, hp: 100, maxHp: 100, r: 0.5, st: '', lvl: 1, scale: 1, born: sim.t, ...o };
  sim.ents.set(e.id, e);
  return e;
}

export const hittable = (e) => e.hp > 0 && e.hittable !== false && e.kind !== 'decoy';

export function damageEntity(sim, e, dmg, by, stun = 0) {
  if (!hittable(e)) return;
  e.hp -= dmg * (e.armor ? 1 / e.armor : 1);
  if (stun > 0) e.stunUntil = Math.max(e.stunUntil || 0, sim.t + stun / (e.resist || 1));
  e.lastHitBy = by ? by.id : null;
  sim.emit({ e: 'sfx', k: 'hit', pos: r3(e.pos) });
  if (e.hp <= 0) {
    e.hp = 0;
    if (sim.mode.onEntityDeath) sim.mode.onEntityDeath(sim, e, by);
    if (e.persistent) { e.st = 'dead'; e.respawnAt = sim.t + (e.respawnIn || 20); } else sim.ents.delete(e.id);
  }
}

export function shoot(sim, p, o, dir, wp) {
  sim.emit({ e: 'sfx', k: 'shot', pos: r3(o) });
  let best = null, bt = 25;
  for (const e of sim.ents.values()) {
    if (!hittable(e)) continue;
    const to = sub(e.pos, o);
    const t = to[0] * dir[0] + to[1] * dir[1] + to[2] * dir[2];
    if (t < 0 || t > bt) continue;
    const closest = [o[0] + dir[0] * t, o[1] + dir[1] * t, o[2] + dir[2] * t];
    if (dist(closest, e.pos) < e.r + 0.3) { best = e; bt = t; }
  }
  if (best) damageEntity(sim, best, wp.dmg, p, wp.stun);
}

export function itemHitsEntity(sim, it, speed) {
  if (it.holder) return;
  for (const e of sim.ents.values()) {
    if (!hittable(e) || sim.t - (it.state.eh || -9) < 0.4) continue;
    if (dist(it.pos, e.pos) < e.r + it.def.r) {
      it.state.eh = sim.t;
      damageEntity(sim, e, Math.min(30, it.def.m * speed * 1.6), it.lastThrower ? sim.players.get(it.lastThrower) : null, 0.4);
    }
  }
}

export function zoneForces(sim, it, dt) {
  for (const z of sim.zones) {
    if (!pointInBox(it.pos, z)) continue;
    if (z.kind === 'belt') { it.vel[0] += (z.vel[0] - it.vel[0]) * Math.min(1, 6 * dt); it.vel[2] += (z.vel[2] - it.vel[2]) * Math.min(1, 6 * dt); it.rest = 0; }
    else if (z.kind === 'wind') { it.vel[0] += z.force[0] * dt * 0.3; it.vel[2] += z.force[2] * dt * 0.3; it.rest = 0; }
  }
}

export function stepCrumble(sim, dt) {
  for (const c of sim.cols) {
    if (c.temp && sim.t > c.temp) { c.on = false; c.gone = true; continue; }
    if (!c.crumble) continue;
    if (c.on) {
      let touched = false;
      for (const p of sim.players.values()) if (p.loco.touch[0] === c || p.loco.touch[1] === c) touched = true;
      c.touchT = touched ? (c.touchT || 0) + dt : Math.max(0, (c.touchT || 0) - dt * 0.5);
      if (c.touchT > 1.2) { c.on = false; c.backAt = sim.t + 4.5; c.touchT = 0; sim.emit({ e: 'sfx', k: 'crumble', pos: r3([(c.min[0] + c.max[0]) / 2, c.max[1], (c.min[2] + c.max[2]) / 2]) }); }
    } else if (c.backAt && sim.t > c.backAt) { c.on = true; c.backAt = 0; }
  }
  // drop colliders that were temporary
  for (let i = sim.cols.length - 1; i >= 0; i--) if (sim.cols[i].gone && i === sim.cols.length - 1) sim.cols.pop();
}

export function stepHazards(sim, dt) {
  // smoke clouds and zones with an expiry
  sim.zones = sim.zones.filter((z) => !z.until || sim.t < z.until);

  // rising lava
  if (sim.lava && sim.phase === 'play') {
    const cfg = sim.arena.lava;
    const surge = Math.sin(sim.t * 0.45) > 0.65 ? 2.6 : 1;
    const accel = 1 + Math.min(1.4, sim.t / 140);
    sim.lava.y = Math.min(cfg.max, sim.lava.y + cfg.speed * (sim.lavaSpeedMul || 1) * surge * accel * dt);
    sim.lava.warn = surge > 1;
    for (const p of sim.players.values()) {
      if (!p.alive || p.spec || sim.hasFx(p, 'lavaproof')) continue;
      if (p.root[1] + p.rel.l[1] < sim.lava.y - 0.1 && p.root[1] + p.rel.r[1] < sim.lava.y - 0.1) {
        if (sim.mode.onLava) sim.mode.onLava(sim, p);
        else sim.eliminate(p, 'lava');
      }
    }
  }

  for (const h of sim.hazards) {
    if (h.kind === 'geyser') {
      const ph = (sim.t + h.phase) % h.period;
      h.on = ph > h.period - 1.6;
      if (h.on) for (const p of sim.players.values()) if (p.alive && distXZ(sim.body(p), h.pos) < h.r && sim.body(p)[1] < 12 + (sim.lava ? sim.lava.y : 0)) sim.knock(p, [0, 1, 0], 6, 0.9);
    } else if (h.kind === 'blade') {
      const ang = sim.t * h.speed;
      const dx = Math.cos(ang) * h.len / 2, dz = Math.sin(ang) * h.len / 2;
      h.ang = ang;
      for (const p of sim.players.values()) {
        if (!p.alive || p.spec) continue;
        const b = sim.body(p);
        if (Math.abs(b[1] - h.pos[1]) > 0.9) continue;
        const rx = b[0] - h.pos[0], rz = b[2] - h.pos[2];
        const t = clamp((rx * dx + rz * dz) / (dx * dx + dz * dz || 1), -1, 1);
        const d = Math.hypot(rx - dx * t, rz - dz * t);
        if (d < h.r + 0.3 && !sim.hasFx(p, 'stun')) sim.knock(p, norm([-dz * t, 0.4, dx * t]), 6, 0.8);
      }
    } else if (h.kind === 'rocks') {
      h.next = h.next ?? sim.t + h.period;
      if (sim.phase === 'play' && sim.t >= h.next) {
        h.next = sim.t + h.period * (0.6 + sim.rng() * 0.8);
        const a = sim.rng() * 6.283, r = sim.rng() * h.r;
        sim.spawnItem('rock', [h.pos[0] + Math.cos(a) * r, h.pos[1], h.pos[2] + Math.sin(a) * r], { vel: [0, -2, 0] });
      }
    } else if (h.kind === 'laser') {
      const ph = (sim.t + h.phase) % h.period;
      h.on = ph < h.on_t || ph < (h.on ?? 2);
      h.live = ph < (h.onDur ?? 2.2);
      if (h.live) for (const p of sim.players.values()) {
        if (!p.alive || p.spec) continue;
        const b = sim.body(p), a = h.a, c = h.b;
        const ab = sub(c, a), ap = sub(b, a);
        const t = clamp((ap[0] * ab[0] + ap[1] * ab[1] + ap[2] * ab[2]) / (ab[0] * ab[0] + ab[1] * ab[1] + ab[2] * ab[2] || 1), 0, 1);
        if (dist(b, add(a, mul(ab, t))) < 0.42) {
          if (sim.mode.onLaser) sim.mode.onLaser(sim, p, h);
          else if (!sim.hasFx(p, 'stun')) sim.knock(p, [0, 0.5, 0], 3, 0.7);
        }
      }
    }
  }
}

export function stepEntities(sim, dt) {
  for (const e of [...sim.ents.values()]) {
    if (e.until && sim.t > e.until) { sim.ents.delete(e.id); continue; }
    if (e.kind === 'decoy') {
      const o = sim.players.get(e.owner);
      if (o && o.alive) {
        // the decoy copies its owner's heading and drifts away so chasers pick it as a target
        e.yaw = o.yaw;
        e.pos = add(e.pos, mul(norm([Math.cos(e.yaw), 0, Math.sin(e.yaw)]), 1.5 * dt));
      }
      continue;
    }
    if (e.persistent && e.st === 'dead' && sim.t > (e.respawnAt || 0)) { e.hp = e.maxHp; e.st = ''; if (e.spawn) e.pos = copy(e.spawn); e.target = null; e.catch = null; }
    if (e.stunUntil && sim.t < e.stunUntil) { e.st = 'stun'; continue; }
    if (e.st === 'stun') e.st = '';
    if (typeof e.think === 'function') e.think(sim, e, dt);
    else if (sim.mode.thinkEntity) sim.mode.thinkEntity(sim, e, dt);
  }
}
