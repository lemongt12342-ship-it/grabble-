// Round modifiers. "Mystery round" picks two at random. Each one changes the shared environment or
// every player's rules for the whole match. Applied by the Sim; the client reads `sim.mods` to show them.

export const MODIFIERS = {
  lowgrav: { name: 'Low gravity', apply: (s) => { s.env.gravity = (s.env.gravity ?? 9.8) * 0.45; } },
  giant: { name: 'Giant hands', apply: (s) => { s.env.handScale = 2.0; } },
  reversed: { name: 'Reversed arms', apply: (s) => { s.env.reverse = true; } },
  speed: { name: 'Speed round', apply: (s) => { s.env.timeScale = 1.6; s.env.maxSpeed = 10; } },
  silent: { name: 'Silent round', apply: (s) => { s.env.silent = true; } },
  blind: { name: 'Blindfold', apply: (s) => { s.env.blind = true; }, update: (s) => { s.env.blackout = Math.floor(s.t / 6) % 3 === 2; } },
  onehand: { name: 'One hand', apply: (s) => { s.env.oneHand = true; } },
  slippery: { name: 'Slippery world', apply: (s) => { s.env.iceAll = true; } },
  bouncy: { name: 'Bouncy world', apply: (s) => { s.env.bounceAll = true; } },
  swap: { name: 'Heavy and light', apply: (s) => { s.env.massSwap = true; }, update: (s) => { s.env.heavyNow = Math.floor(s.t / 5) % 2 === 0; } },
  shrink: { name: 'Shrink and grow', apply: (s) => { s.env.sizeWobble = true; }, update: (s) => { s.env.sizeNow = 1 + 0.5 * Math.sin(s.t * 0.6); } },
};

export const MODIFIER_IDS = Object.keys(MODIFIERS);
