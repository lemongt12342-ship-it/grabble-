export const VERSION = 1;
export const TICK_HZ = 60;
export const DT = 1 / TICK_HZ;
export const SNAP_HZ = 20;

export const LIMITS = {
  maxPlayers: 10,
  maxItems: 160,
  maxEvents: 64,
  nameLen: 16,
  roomCodeLen: 5,
  msgBytes: 4096,
  poseHz: 90, // max pose messages per second per connection
};

// Gorilla Tag style locomotion. You move only by pushing against surfaces with your hands.
export const LOCO = {
  gravity: 9.8,
  maxSpeed: 7.0, // m/s, normal cap
  boostSpeed: 10.0, // speed boots, dash
  velMult: 1.12, // launch bonus when the last hand leaves a surface
  airDrag: 0.04,
  handR: 0.07,
  headR: 0.17,
  skin: 0.012,
  histLen: 5,
  maxHandSpeed: 20, // reported hand movement is clamped to this (anti-teleport)
  armMax: 1.05, // max distance from head to hand
  headBox: 1.4, // max head offset from the rig origin (room scale)
  iceSlip: 0.94,
  slimeSlip: 0.55,
  anchorMaxSpeed: 14,
  gripOn: 0.7,
  gripOff: 0.4,
  reach: 0.3, // how close a hand must be to an item to grab it
};

export const TEAM_COLORS = ['#ff6b6b', '#4dabf7', '#ffd43b', '#69db7c', '#da77f2', '#ffa94d'];
