// Small math, validation and RNG helpers. Pure functions, no DOM, no Node APIs.
// Shared by the browser client and the server.

export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
export const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
export const mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
export const addScaled = (a, b, s) => [a[0] + b[0] * s, a[1] + b[1] * s, a[2] + b[2] * s];
export const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
export const len = (a) => Math.hypot(a[0], a[1], a[2]);
export const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]);
export const distXZ = (a, b) => Math.hypot(a[0] - b[0], a[2] - b[2]);
export const norm = (a) => {
  const l = len(a);
  return l < 1e-9 ? [0, 0, 0] : [a[0] / l, a[1] / l, a[2] / l];
};
export const limitLen = (a, m) => {
  const l = len(a);
  return l > m && l > 0 ? mul(a, m / l) : a;
};
export const copy = (a) => [a[0], a[1], a[2]];
export const round = (v, n = 2) => {
  const k = 10 ** n;
  return Math.round(v * k) / k;
};
export const r3 = (a, n = 2) => [round(a[0], n), round(a[1], n), round(a[2], n)];

export const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
export const num = (v, lo, hi, def = 0) => (isNum(v) ? clamp(v, lo, hi) : def);
export function vec(v, lim, def = [0, 0, 0]) {
  if (!Array.isArray(v) || v.length < 3) return def.slice();
  return [num(v[0], -lim, lim, def[0]), num(v[1], -lim, lim, def[1]), num(v[2], -lim, lim, def[2])];
}

// Names: letters, numbers, space, underscore, dash, dot. No control, bidi or zero-width characters.
const BLOCK = ['fuck', 'shit', 'bitch', 'cunt', 'nigg', 'fag', 'rape', 'nazi'];
export function cleanName(s, def = 'Player', max = 16) {
  if (typeof s !== 'string') return def;
  let t = s.normalize('NFKC').replace(/[\u0000-\u001f\u007f-\u009f​-‏‪-‮⁠-⁯﻿]/g, '');
  t = t.replace(/[^\p{L}\p{N} _\-.]/gu, '').replace(/\s+/g, ' ').trim().slice(0, max);
  const flat = t.toLowerCase().replace(/[^a-z]/g, '');
  if (BLOCK.some((w) => flat.includes(w))) return def;
  return t.length ? t : def;
}

export function str(v, max, re, def = '') {
  if (typeof v !== 'string' || v.length > max) return def;
  return re && !re.test(v) ? def : v;
}

// Deterministic seeded RNG (mulberry32).
export function rng(seed) {
  let a = seed >>> 0;
  const f = () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  f.range = (lo, hi) => lo + (hi - lo) * f();
  f.int = (n) => Math.floor(f() * n);
  f.pick = (arr) => arr[Math.floor(f() * arr.length)];
  f.chance = (p) => f() < p;
  f.shuffle = (arr) => {
    const a2 = arr.slice();
    for (let i = a2.length - 1; i > 0; i--) {
      const j = Math.floor(f() * (i + 1));
      [a2[i], a2[j]] = [a2[j], a2[i]];
    }
    return a2;
  };
  f.weighted = (entries) => {
    // entries: [[value, weight], ...]
    let total = 0;
    for (const e of entries) total += e[1];
    let r = f() * total;
    for (const e of entries) {
      r -= e[1];
      if (r <= 0) return e[0];
    }
    return entries[entries.length - 1][0];
  };
  return f;
}

export function hashStr(s) {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

export function todaySeed(date = new Date()) {
  const y = date.getUTCFullYear(), m = date.getUTCMonth() + 1, d = date.getUTCDate();
  return y * 10000 + m * 100 + d;
}
