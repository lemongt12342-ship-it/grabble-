// Player look options. Pure data, so the server, the client UI and the tests can all use it.
export const DEFAULT_COS = { fur: '#4a3f9c', accent: '#f1e3c0', glove: 'none', pad: '#ff7a3d', eyes: '#ffd43b', hat: 'none', trail: 'none' };
export const HATS = ['none', 'party', 'crown', 'tophat', 'halo', 'cap'];
export const TRAILS = ['none', 'sparkle', 'flame', 'bubbles', 'stars'];
export const FUR_COLORS = ['#4a3f9c', '#2f6fdd', '#16a085', '#3fa34d', '#d4a017', '#e8590c', '#d6336c', '#7b4a2d', '#5c5f66', '#e9ecef', '#111018', '#9c36b5'];
export const FACE_COLORS = ['#f1e3c0', '#ffd8a8', '#d0ebff', '#c3fae8', '#ffdeeb', '#e5dbff', '#ced4da', '#fff3bf'];
export const PAD_COLORS = ['#ff7a3d', '#ff4d6d', '#ffd43b', '#69db7c', '#4dabf7', '#da77f2', '#ffffff', '#212529'];
export const EYE_COLORS = ['#ffd43b', '#74c0fc', '#69db7c', '#ff8787', '#e599f7', '#ffffff', '#ffa94d', '#63e6be'];
