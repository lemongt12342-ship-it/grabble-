// More game modes: Heist, Kitchen Rush, Conveyor Sort, Treasure Dive, Zombie Survival and Boss Fight.
import { dist, distXZ, norm, sub, add, mul, copy } from '../util.js';
import { RARITY, POOLS, ORDERS, ITEMS } from '../items.js';
import { scatter } from './common.js';
import { pointInBox } from '../collide.js';
import { spawnEntity, damageEntity } from '../simhaz.js';

// ---- helpers ------------------------------------------------------------------------------------------------
const center = (z) => [(z.min[0] + z.max[0]) / 2, (z.min[1] + z.max[1]) / 2, (z.min[2] + z.max[2]) / 2];
const consume = (sim, it) => { it.dead = true; sim.items.delete(it.id); };
const free = (it) => !it.holder;
const itemsIn = (sim, zone) => [...sim.items.values()].filter((it) => free(it) && pointInBox(it.pos, zone));
const pts = (it) => (RARITY[it.def.rar] || RARITY.common).pts;
const stamp = (sim, p, it) => { it.state.by = p.id; };
const msg = (sim, text) => sim.emit({ e: 'msg', text });

// fast thrown items hurt monsters, so there is always something to fight with
function thrownHits(sim, dmg = 7) {
  for (const it of sim.items.values()) {
    if (it.holder || !it.vel) continue;
    const v = Math.hypot(it.vel[0], it.vel[1], it.vel[2]);
    if (v < 6 || sim.t - (it.state.eh || -9) < 0.6) continue;
    for (const e of sim.ents.values()) {
      if (e.hp <= 0 || e.hittable === false) continue;
      if (dist(it.pos, e.pos) < e.r + 0.35) {
        it.state.eh = sim.t;
        damageEntity(sim, e, dmg * Math.min(1.5, v / 8), it.state.by ? sim.players.get(it.state.by) : null);
        it.vel = mul(it.vel, -0.3);
        break;
      }
    }
  }
}

// ---- Heist: sneak into the vault, grab loot, get it out past the lasers --------------------------------------
export const heist = {
  time: 150,
  steal: true,
  arena: () => ({ kind: 'vault', theme: 'night' }),
  init(sim) {
    sim.mdata = { t: 0 };
    for (const s of sim.arena.itemSpots) sim.spawnItem(POOLS.loot[sim.rng.int(POOLS.loot.length)], [s[0], s[1] + 0.2, s[2]]);
  },
  onGrab: stamp,
  onLaser(sim, p) { if (!sim.hasFx(p, 'immune')) { sim.respawn(p); sim.setFx(p, 'immune', 2); msg(sim, `${p.name} tripped a laser`); } },
  onFall(sim, p) { sim.respawn(p); },
  update(sim, dt) {
    const ex = sim.zone('exit');
    for (const it of itemsIn(sim, ex)) {
      const p = it.state.by && sim.players.get(it.state.by);
      if (p) { sim.giveScore(p, pts(it), 'stash'); sim.stat(p, 'loot'); }
      consume(sim, it);
    }
    sim.mdata.t += dt;
    if (sim.mdata.t > 4 && sim.items.size < 12) {
      sim.mdata.t = 0;
      const s = sim.arena.itemSpots[sim.rng.int(sim.arena.itemSpots.length)];
      sim.spawnItem(POOLS.loot[sim.rng.int(POOLS.loot.length)], [s[0], s[1] + 0.2, s[2]]);
    }
  },
  bot(sim, p) {
    if (p.hold[0] || p.hold[1]) return { goal: center(sim.zone('exit')), speed: 3.2 };
    let best = null, bd = 1e9;
    for (const it of sim.items.values()) if (free(it)) { const d = dist(it.pos, sim.body(p)); if (d < bd) { bd = d; best = it.pos; } }
    return best ? { goal: best, speed: 3.2 } : null;
  },
  pub() { return {}; },
  finish() { return { reason: 'time' }; },
};

// ---- Kitchen Rush: everyone cooks the same orders together ---------------------------------------------------------
export const kitchen = {
  time: 150,
  arena: () => ({ kind: 'kitchen', theme: 'candy' }),
  init(sim) {
    sim.mdata = { order: ORDERS[0], t: 0, done: 0 };
    for (const s of sim.arena.stations) sim.spawnItem(s.item, [s.pos[0], s.pos[1] + 0.2, s.pos[2]]);
  },
  onFall(sim, p) { sim.respawn(p); },
  update(sim, dt) {
    const d = sim.mdata;
    d.t += dt;
    if (d.t > 2.5 && sim.items.size < 36) {
      d.t = 0;
      const s = sim.arena.stations[sim.rng.int(sim.arena.stations.length)];
      sim.spawnItem(s.item, [s.pos[0], s.pos[1] + 0.2, s.pos[2]]);
    }
    const there = itemsIn(sim, sim.zone('pass'));
    const picks = [];
    for (const need of d.order.need) {
      const it = there.find((x) => x.type === need && !picks.includes(x));
      if (!it) return;
      picks.push(it);
    }
    picks.forEach((it) => consume(sim, it));
    for (const p of sim.list()) sim.giveScore(p, d.order.pts, d.order.id);
    d.done++;
    msg(sim, `Order up: ${d.order.id}!`);
    d.order = ORDERS[sim.rng.int(ORDERS.length)];
  },
  bot(sim, p) {
    const need = sim.mdata.order.need;
    if (p.hold[0] || p.hold[1]) return { goal: center(sim.zone('pass')), speed: 3 };
    for (const it of sim.items.values()) if (free(it) && need.includes(it.type)) return { goal: it.pos, speed: 3 };
    return null;
  },
  pub(sim) { return { order: sim.mdata.order.need, orderId: sim.mdata.order.id, done: sim.mdata.done }; },
  finish() { return { reason: 'time' }; },
};

// ---- Conveyor Sort: two teams grab goods off the belts into their own bin -----------------------------------------
export const conveyor = {
  time: 120,
  steal: true,
  arena: () => ({ kind: 'belt', theme: 'market' }),
  init(sim) {
    sim.mdata = { t: 0, score: [0, 0] };
    sim.list().forEach((p, i) => { p.team = i % 2; });
  },
  onJoin(sim, p) { p.team = sim.list().filter((q) => q.team === 0).length <= sim.list().filter((q) => q.team === 1).length ? 0 : 1; },
  onGrab: stamp,
  onFall(sim, p) { sim.respawn(p); },
  update(sim, dt) {
    const d = sim.mdata;
    d.t += dt;
    if (d.t > 1.6 && sim.items.size < 40) {
      d.t = 0;
      const s = sim.arena.itemSpots[sim.rng.int(sim.arena.itemSpots.length)];
      const t = sim.rng() < 0.6 ? POOLS.loot[sim.rng.int(POOLS.loot.length)] : POOLS.toys[sim.rng.int(POOLS.toys.length)];
      sim.spawnItem(t, [s[0], s[1] + 0.2, s[2]]);
    }
    for (const z of sim.zones) {
      if (z.kind === 'bin' && z.team !== undefined) {
        for (const it of itemsIn(sim, z)) {
          const n = ITEMS[it.type] && (ITEMS[it.type].flags || []).includes('loot') ? pts(it) : 1;
          d.score[z.team] += n;
          const p = it.state.by && sim.players.get(it.state.by);
          if (p && p.team === z.team) sim.giveScore(p, n, 'bin');
          consume(sim, it);
        }
      } else if (z.kind === 'void') for (const it of itemsIn(sim, z)) consume(sim, it);
    }
  },
  bot(sim, p) {
    if (p.hold[0] || p.hold[1]) return { goal: center(sim.zones.find((z) => z.kind === 'bin' && z.team === p.team)), speed: 3.2 };
    let best = null, bd = 1e9;
    for (const it of sim.items.values()) if (free(it)) { const dd = dist(it.pos, sim.body(p)); if (dd < bd) { bd = dd; best = it.pos; } }
    return best ? { goal: best, speed: 3.2 } : null;
  },
  pub(sim) { return { score: sim.mdata.score }; },
  finish(sim) {
    const s = sim.mdata.score;
    if (s[0] === s[1]) return { winners: [], reason: 'tie' };
    const t = s[0] > s[1] ? 0 : 1;
    return { winners: sim.list().filter((p) => p.team === t).map((p) => p.id), reason: 'sorted the most' };
  },
};

// ---- Treasure Dive: swim down, grab treasure, bring it back to the boat -------------------------------------------
export const treasure = {
  time: 120,
  steal: true,
  arena: () => ({ kind: 'pool', theme: 'space' }),
  init(sim) {
    sim.mdata = { t: 0 };
    for (const s of sim.arena.itemSpots) sim.spawnItem(POOLS.loot[sim.rng.int(POOLS.loot.length)], [s[0], s[1] + 0.2, s[2]]);
  },
  onGrab: stamp,
  onFall(sim, p) { sim.respawn(p); },
  update(sim, dt) {
    for (const it of itemsIn(sim, sim.zone('boat'))) {
      const p = it.state.by && sim.players.get(it.state.by);
      if (p) { sim.giveScore(p, pts(it), 'treasure'); sim.stat(p, 'loot'); }
      consume(sim, it);
    }
    sim.mdata.t += dt;
    if (sim.mdata.t > 3 && sim.items.size < 26) {
      sim.mdata.t = 0;
      const s = sim.arena.itemSpots[sim.rng.int(sim.arena.itemSpots.length)];
      sim.spawnItem(POOLS.loot[sim.rng.int(POOLS.loot.length)], [s[0], s[1] + 0.2, s[2]]);
    }
  },
  bot(sim, p) {
    if (p.hold[0] || p.hold[1]) return { goal: center(sim.zone('boat')), speed: 3 };
    return null;
  },
  pub() { return {}; },
  finish() { return { reason: 'time' }; },
};

// ---- monsters used by the survival and boss modes ---------------------------------------------------------------------
function nearestTarget(sim, e) {
  let t = null, td = 1e9;
  for (const p of sim.players.values()) {
    if (!p.alive || p.spec) continue;
    const d = distXZ(p.root, e.pos);
    if (d < td) { td = d; t = p; }
  }
  return t ? { p: t, d: td } : null;
}

function chase(sim, e, dt, speed) {
  const tg = nearestTarget(sim, e);
  if (!tg) return null;
  const to = sub(sim.body(tg.p), e.pos); to[1] = 0;
  if (tg.d > 0.2) {
    const dir = norm(to);
    e.pos = [e.pos[0] + dir[0] * speed * dt, e.pos[1], e.pos[2] + dir[2] * speed * dt];
    e.yaw = Math.atan2(dir[2], dir[0]);
    const b = sim.arena.bounds;
    e.pos[0] = Math.max(b.min[0] + 1, Math.min(b.max[0] - 1, e.pos[0]));
    e.pos[2] = Math.max(b.min[2] + 1, Math.min(b.max[2] - 1, e.pos[2]));
  }
  return tg;
}

function hurtPlayer(sim, p, from, dmg) {
  if (sim.hasFx(p, 'immune')) return;
  p.hp -= dmg;
  sim.emit({ e: 'sfx', k: 'chomp', pos: [from[0], from[1], from[2]] });
  sim.knock(p, norm(sub(sim.body(p), from)), 4, 0.8);
  sim.setFx(p, 'immune', 0.8);
  if (p.hp <= 0) { p.hp = 0; sim.eliminate(p, 'zombie'); }
}

function thinkZombie(sim, e, dt) {
  e.cooldown = Math.max(0, (e.cooldown || 0) - dt);
  const tg = chase(sim, e, dt, e.speed || 2);
  e.st = tg && tg.d < 6 ? 'chase' : '';
  if (tg && e.cooldown <= 0 && tg.d < e.r + 0.8 && Math.abs(sim.body(tg.p)[1] - e.pos[1]) < 1.6) {
    e.cooldown = 1.1;
    hurtPlayer(sim, tg.p, e.pos, e.damage || 10);
  }
}

function spawnZombie(sim, wave, at) {
  const ang = sim.rng() * Math.PI * 2;
  const pos = at || [Math.cos(ang) * 17, 1.0, Math.sin(ang) * 17];
  const hp = 25 + wave * 9;
  return spawnEntity(sim, 'zombie', pos, { hp, maxHp: hp, r: 0.55, speed: Math.min(3.4, 1.5 + wave * 0.16), damage: 7 + wave * 1.5, lvl: wave, scale: 1, persistent: false });
}

function arm(sim, extra = 0) {
  scatter(sim, [...POOLS.found_weapons, 'bat', 'pipe', 'pu_arms', 'pu_boots', ...POOLS.toys.slice(0, 5)], 10 + extra, 40);
  for (const p of sim.players.values()) { p.hp = p.maxHp = 100; }
}

// ---- Zombie Survival: waves get bigger and meaner -------------------------------------------------------------------
export const zombies = {
  time: 600,
  arena: () => ({ kind: 'stage', theme: 'attic' }),
  init(sim) {
    sim.mdata = { wave: 0, queue: 0, gap: 4, spawnT: 0, kills: 0, maxWave: 8 };
    arm(sim);
  },
  thinkEntity(sim, e, dt) { if (e.kind === 'zombie') thinkZombie(sim, e, dt); },
  onEntityDeath(sim, e, by) {
    sim.mdata.kills++;
    if (by) { sim.giveScore(by, 5, 'kill'); sim.stat(by, 'kills'); }
    if (sim.rng() < 0.18) scatter(sim, ['pu_boots', 'pu_arms', 'pu_dash', ...POOLS.found_weapons], 1, 50);
  },
  onElim(sim) {
    if (!sim.alive().length) sim.endMatch({ winners: [], lost: true, reason: `overrun on wave ${sim.mdata.wave}` });
  },
  onFall(sim, p) { sim.respawn(p); },
  update(sim, dt) {
    const d = sim.mdata;
    thrownHits(sim);
    if (sim.items.size < 10 && sim.rng() < 0.01) scatter(sim, [...POOLS.found_weapons, 'bat', 'pipe'], 1, 40);
    const left = [...sim.ents.values()].filter((e) => e.kind === 'zombie' && e.hp > 0).length;
    if (d.queue > 0) {
      d.spawnT += dt;
      if (d.spawnT > 0.9 && left < 26) { d.spawnT = 0; d.queue--; spawnZombie(sim, d.wave); }
    } else if (left === 0) {
      d.gap -= dt;
      if (d.gap <= 0) {
        if (d.wave >= d.maxWave) { sim.endMatch({ winners: sim.alive().map((p) => p.id), reason: 'survived all waves' }); return; }
        d.wave++;
        d.queue = 3 + d.wave * 2;
        d.gap = 5;
        for (const p of sim.alive()) p.hp = Math.min(p.maxHp, p.hp + 30);
        msg(sim, `Wave ${d.wave}`);
      }
    }
  },
  bot(sim, p) {
    // stand on a pillar platform when zombies are near; otherwise wander and pick things up
    return null;
  },
  pub(sim) { return { wave: sim.mdata.wave, total: sim.mdata.maxWave, left: [...sim.ents.values()].filter((e) => e.kind === 'zombie' && e.hp > 0).length + sim.mdata.queue }; },
  finish(sim) { return { winners: sim.alive().map((p) => p.id), reason: 'time' }; },
};

// ---- Boss Fight: a giant that slams the ground. Get off the floor when it winds up. -------------------------------------
export const boss = {
  time: 420,
  arena: () => ({ kind: 'stage', theme: 'volcano' }),
  init(sim) {
    sim.mdata = { phase: 1, minionT: 8 };
    arm(sim, 6);
    const n = Math.max(1, sim.humans().length || 1);
    const hp = 500 + 200 * n;
    const z = sim.zone('boss');
    const b = spawnEntity(sim, 'boss', [(z.min[0] + z.max[0]) / 2, 1.5, (z.min[2] + z.max[2]) / 2], { hp, maxHp: hp, r: 1.5, scale: 2.3, lvl: 1, damage: 28, slamT: 5, persistent: false });
    sim.mdata.boss = b;
  },
  thinkEntity(sim, e, dt) {
    if (e.kind === 'zombie') return thinkZombie(sim, e, dt);
    if (e.kind !== 'boss') return;
    const frac = e.hp / e.maxHp;
    e.lvl = frac < 0.33 ? 3 : frac < 0.66 ? 2 : 1;
    sim.mdata.phase = e.lvl;
    if (e.st === 'slam') {
      e.windup -= dt;
      if (e.windup <= 0) {
        e.st = '';
        e.slamT = 6 - e.lvl;
        sim.emit({ e: 'sfx', k: 'boom', pos: [e.pos[0], e.pos[1], e.pos[2]] });
        for (const p of sim.players.values()) {
          if (!p.alive) continue;
          const onFloor = p.root[1] < 2.1; // platforms and pillars are safe
          if (onFloor && distXZ(p.root, e.pos) < 7.5) hurtPlayer(sim, p, e.pos, e.damage + e.lvl * 4);
        }
      }
      return;
    }
    chase(sim, e, dt, 1.3 + e.lvl * 0.5);
    e.slamT -= dt;
    if (e.slamT <= 0) { e.st = 'slam'; e.windup = 1.3; msg(sim, 'GET OFF THE GROUND!'); }
  },
  onEntityDeath(sim, e, by) {
    if (e.kind === 'zombie') { if (by) sim.giveScore(by, 2, 'kill'); return; }
    for (const p of sim.alive()) sim.giveScore(p, 50, 'boss');
    sim.endMatch({ winners: sim.alive().map((p) => p.id), reason: 'boss defeated' });
  },
  onElim(sim) { if (!sim.alive().length) sim.endMatch({ winners: [], lost: true, reason: 'the boss won' }); },
  onFall(sim, p) { sim.respawn(p); },
  update(sim, dt) {
    thrownHits(sim, 9);
    const d = sim.mdata;
    d.minionT -= dt;
    if (d.minionT <= 0 && d.boss && d.boss.hp > 0) {
      d.minionT = 12 - d.phase * 2;
      for (let i = 0; i < d.phase + 1; i++) spawnZombie(sim, 2 + d.phase);
    }
    if (sim.items.size < 10 && sim.rng() < 0.01) scatter(sim, [...POOLS.found_weapons, 'bat', 'pipe', 'anvil'], 1, 40);
  },
  bot: null,
  pub(sim) { const b = sim.mdata.boss; return { bossHp: b ? Math.max(0, Math.round((b.hp / b.maxHp) * 100)) : 0, phase: sim.mdata.phase }; },
  finish(sim) { return { winners: [], reason: 'time ran out' }; },
};
