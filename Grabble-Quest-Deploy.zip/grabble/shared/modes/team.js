// Team and party modes: Hot Seat, Capture the Flag, Dodgeball, Hide and Seek.
import { dist, norm, sub, add, mul } from '../util.js';
import { POOLS } from '../items.js';
import { pointInBox } from '../collide.js';
import { scatter, assignTeams, isIt } from './common.js';

// ---- Hot Seat: pass the ticking bomb before it blows -------------------------------------------------
function giveBomb(sim, p) {
  const b = sim.mdata.bomb;
  if (!b || !p) return;
  for (const q of sim.list()) for (let i = 0; i < 2; i++) if (q.hold[i] === b.id) q.hold[i] = null;
  p.hold[0] = b.id;
  b.holder = { pid: p.id, hand: 0 };
  b.state.hands = 1;
  b.state.heat = 0;
  b.static = false;
  sim.emit({ e: 'it', id: p.id });
}

export const hotseat = {
  time: 240,
  steal: true,
  arena: () => ({ kind: 'courtyard', theme: 'night' }),
  init(sim) {
    sim.mdata = { bomb: null, acc: 0 };
    sim.mdata.bomb = sim.spawnItem('bomb', [0, 3, 0]);
    scatter(sim, ['pu_dash', 'pu_boots', 'pu_smoke', 'ball', 'duck'], 8, 24);
  },
  update(sim, dt) {
    const b = sim.mdata.bomb;
    if (!b || !sim.items.has(b.id)) { sim.mdata.bomb = sim.spawnItem('bomb', [0, 3, 0]); }
    const bb = sim.mdata.bomb;
    if (!bb.holder && sim.t > 2) { const p = sim.alive()[sim.rng.int(sim.alive().length || 1)]; if (p) giveBomb(sim, p); }
    sim.mdata.acc += dt;
    if (sim.mdata.acc >= 1) { sim.mdata.acc = 0; for (const p of sim.alive()) sim.giveScore(p, 1); }
  },
  onBomb(sim, it, holder) {
    if (holder) { sim.eliminate(holder, 'boom'); }
    const alive = sim.alive();
    if (sim.list().length > 1 && alive.length <= 1) return sim.endMatch({ winners: alive.map((p) => p.id), reason: 'last standing' });
    sim.removeItem(it);
    sim.mdata.bomb = sim.spawnItem('bomb', [0, 3, 0]);
    giveBomb(sim, alive[sim.rng.int(alive.length)]);
  },
  onFall(sim, p) { sim.respawn(p); },
  bot(sim, p) {
    const b = sim.mdata.bomb;
    if (b && b.holder && b.holder.pid === p.id) {
      const t = sim.nearestPlayer(sim.body(p), (q) => q !== p);
      if (t && dist(sim.body(t), sim.body(p)) < 1.3 && sim.rng() < 0.3) { b.holder = null; p.hold[0] = null; b.vel = mul(norm(sub(sim.body(t), sim.body(p))), 7); b.lastThrower = p.id; b.thrownT = sim.t; }
      return t ? { goal: sim.body(t), speed: 4.2 } : null;
    }
    return null;
  },
  pub(sim) { const b = sim.mdata.bomb; return { holder: b && b.holder ? b.holder.pid : '', heat: b ? b.state.heat : 0 }; },
  finish(sim) { return { winners: sim.alive().map((p) => p.id), reason: 'survivors' }; },
};

// ---- Capture the Flag ------------------------------------------------------------------------------------------
export const ctf = {
  time: 240,
  steal: true,
  arena: () => ({ kind: 'ctf', theme: 'toybox' }),
  init(sim) {
    assignTeams(sim, 2);
    sim.mdata = { score: [0, 0], flags: [null, null], back: [0, 0] };
    for (const t of [0, 1]) {
      const z = sim.zone(t ? 'baseB' : 'baseA');
      z.pub = true;
      sim.mdata.flags[t] = sim.spawnItem('flag', z.flag, { state: { team: t } });
    }
    scatter(sim, [...POOLS.runner, ...POOLS.general], 6, 24);
  },
  onJoin(sim, p) { const c = [0, 0]; for (const q of sim.list()) if (q !== p) c[q.team]++; p.team = c[0] <= c[1] ? 0 : 1; if (sim.phase !== 'lobby') sim.respawn(p, sim.arena.spawns[p.team * 5]); },
  update(sim) {
    const d = sim.mdata;
    for (const t of [0, 1]) {
      const f = d.flags[t];
      if (!f || !sim.items.has(f.id)) { const z = sim.zone(t ? 'baseB' : 'baseA'); d.flags[t] = sim.spawnItem('flag', z.flag, { state: { team: t } }); continue; }
      const home = sim.zone(t ? 'baseB' : 'baseA').flag;
      if (!f.holder && dist(f.pos, home) > 0.6) {
        d.back[t] += 1 / 60;
        if (d.back[t] > 8) { f.pos = [...home]; f.vel = [0, 0, 0]; d.back[t] = 0; sim.msg('Flag returned'); }
      } else d.back[t] = 0;
      if (f.holder) {
        const p = sim.players.get(f.holder.pid);
        if (p && p.team === t) { f.holder = null; p.hold = [null, null]; f.pos = [...home]; }
        else if (p && pointInBox(sim.body(p), sim.zone(p.team ? 'baseB' : 'baseA'))) {
          d.score[p.team]++;
          sim.giveScore(p, 10, 'capture');
          sim.stat(p, 'captures');
          p.hold = [p.hold[0] === f.id ? null : p.hold[0], p.hold[1] === f.id ? null : p.hold[1]];
          f.holder = null; f.pos = [...home]; f.vel = [0, 0, 0];
          sim.emit({ e: 'capture', team: p.team });
          if (d.score[p.team] >= 3) sim.endMatch({ winners: sim.list().filter((q) => q.team === p.team).map((q) => q.id), reason: 'captures' });
        }
      }
    }
  },
  canGrab: () => false,
  onFall(sim, p) { sim.respawn(p, sim.arena.spawns[p.team * 5 + (p.si % 5)]); },
  bot(sim, p) {
    const own = sim.mdata.flags[p.team], enemy = sim.mdata.flags[1 - p.team];
    if (enemy && enemy.holder && enemy.holder.pid === p.id) return { goal: sim.zone(p.team ? 'baseB' : 'baseA').flag, speed: 3.6 };
    return enemy ? { goal: enemy.pos, speed: 3.4 } : null;
  },
  pub(sim) { return { score: sim.mdata.score }; },
  finish(sim) {
    const s = sim.mdata.score;
    if (s[0] === s[1]) return { winners: [], reason: 'tie' };
    const t = s[0] > s[1] ? 0 : 1;
    return { winners: sim.list().filter((q) => q.team === t).map((q) => q.id), reason: 'captures' };
  },
};

// ---- Dodgeball ----------------------------------------------------------------------------------------------------------
export const dodgeball = {
  time: 150,
  steal: true,
  arena: () => ({ kind: 'dodge', theme: 'candy' }),
  init(sim) {
    assignTeams(sim, 2);
    sim.mdata = { n: 0 };
    for (let i = 0; i < 6; i++) sim.spawnItem('dodgeball', [(i % 2 ? 1 : -1) * (0.5 + (i >> 1)), 0.5, (i - 2.5) * 1.5]);
    for (const p of sim.list()) sim.respawn(p, sim.arena.spawns[p.team * 5 + (p.si % 5)]);
  },
  onJoin(sim, p) { const c = [0, 0]; for (const q of sim.list()) if (q !== p) c[q.team]++; p.team = c[0] <= c[1] ? 0 : 1; },
  onItemHit(sim, it, p, speed) {
    if (!it.def.flags.includes('dodge') || it.holder) return false;
    const th = it.lastThrower && sim.players.get(it.lastThrower);
    if (!th || th.team === p.team || sim.t - it.thrownT > 2.5) return false;
    sim.eliminate(p, 'hit');
    sim.giveScore(th, 3, 'hit');
    sim.stat(th, 'hits');
    it.lastThrower = null;
    it.vel = mul(it.vel, 0.3);
    return true;
  },
  onGrab(sim, p, it) {
    if (!it.def.flags.includes('dodge') || !it.lastThrower || sim.t - it.thrownT > 1.2) return;
    const th = sim.players.get(it.lastThrower);
    if (!th || th.team === p.team) return;
    const out = sim.list().find((q) => !q.alive && q.team === p.team);
    if (out) { sim.respawn(out, sim.arena.spawns[out.team * 5]); sim.giveScore(p, 4, 'catch'); sim.stat(p, 'catches'); sim.emit({ e: 'revive', id: out.id }); }
  },
  onElim(sim, p) {
    for (const t of [0, 1]) if (sim.list().length > 1 && !sim.list().some((q) => q.alive && q.team === t)) {
      sim.endMatch({ winners: sim.list().filter((q) => q.team === 1 - t).map((q) => q.id), reason: 'all out' });
    }
  },
  update(sim) {
    // eliminated players wait on the bench side; keep the balls in play
    if (sim.items.size < 5 && sim.rng() < 0.05) sim.spawnItem('dodgeball', [0, 1, sim.rng.range(-5, 5)]);
  },
  onFall(sim, p) { sim.respawn(p, sim.arena.spawns[p.team * 5]); },
  bot(sim, p) {
    const ball = [...sim.items.values()].find((i) => !i.holder && i.def.flags.includes('dodge') && Math.sign(i.pos[0] || 1) === (p.team ? 1 : -1));
    const goal = ball ? ball.pos : [(p.team ? 1 : -1) * 6, 0, sim.rng.range(-5, 5)];
    if (p.hold[0] && sim.rng() < 0.04) {
      const it = sim.items.get(p.hold[0]);
      const t = sim.nearestPlayer(sim.body(p), (q) => q.team !== p.team);
      if (it && t) { it.holder = null; p.hold[0] = null; it.vel = mul(norm(sub(sim.body(t), it.pos)), 9); it.lastThrower = p.id; it.thrownT = sim.t; }
    }
    return { goal: [Math.sign(sim.body(p)[0]) * Math.max(1.2, Math.abs(goal[0])), goal[1], goal[2]], speed: 3.2 };
  },
  pub(sim) { return { left: [0, 1].map((t) => sim.list().filter((q) => q.alive && q.team === t).length) }; },
  finish(sim) {
    const a = [0, 1].map((t) => sim.list().filter((q) => q.alive && q.team === t).length);
    if (a[0] === a[1]) return { winners: [], reason: 'tie' };
    const t = a[0] > a[1] ? 0 : 1;
    return { winners: sim.list().filter((q) => q.team === t).map((q) => q.id), reason: 'most left' };
  },
};

// ---- Hide and Seek ------------------------------------------------------------------------------------------------------------
export const hideseek = {
  time: 150,
  grabPlayers: true,
  arena: () => ({ kind: 'courtyard', theme: 'attic' }),
  init(sim) {
    sim.mdata = { acc: 0, hideT: 15 };
    const list = sim.list();
    const n = Math.max(1, Math.floor(list.length / 5));
    const order = sim.rng.shuffle(list);
    order.forEach((p, i) => { p.role = i < n ? 'it' : ''; });
  },
  canGrab(sim, p, t) { return isIt(p) && !isIt(t) && sim.phase === 'play' && sim.mdata.hideT <= 0; },
  update(sim, dt) {
    const d = sim.mdata;
    if (d.hideT > 0) {
      d.hideT -= dt;
      for (const p of sim.list()) {
        if (isIt(p)) sim.setFx(p, 'frozen', 0.1); // seekers count to 15 while hiders run and hide
        else sim.setFx(p, 'disguise', 0.2);
      }
      return;
    }
    d.acc += dt;
    if (d.acc >= 1) { d.acc = 0; for (const p of sim.alive()) if (!isIt(p)) sim.giveScore(p, 1); }
    for (const p of sim.list()) if (!isIt(p) && p.alive) sim.setFx(p, 'disguise', 0.2);
    const hiders = sim.list().filter((p) => p.alive && !isIt(p));
    if (!hiders.length && sim.list().length > 1) sim.endMatch({ winners: sim.list().filter(isIt).map((p) => p.id), reason: 'all found' });
  },
  onHold(sim, p, t, held) {
    if (!isIt(p) || held < 0.5) return;
    sim.eliminate(t, 'found');
    sim.giveScore(p, 10, 'found');
    sim.stat(p, 'found');
  },
  onFall(sim, p) { sim.respawn(p); },
  bot(sim, p) {
    if (isIt(p)) {
      if (sim.mdata.hideT > 0) return null;
      const t = sim.nearestPlayer(sim.body(p), (q) => !isIt(q));
      return t ? { goal: sim.body(t), speed: 3.6 } : null;
    }
    return { goal: [p.root[0] + (p.si % 2 ? 6 : -6), 0, p.root[2] + (p.si % 3 ? 6 : -6)], speed: 3.4 };
  },
  pub(sim) { return { hideT: Math.max(0, Math.round(sim.mdata.hideT)), left: sim.list().filter((p) => p.alive && !isIt(p)).length }; },
  finish(sim) { return { winners: sim.list().filter((p) => p.alive && !isIt(p)).map((p) => p.id), reason: 'hiders survived' }; },
};
