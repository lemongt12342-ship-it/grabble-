// Mode registry. Each mode is a plain object of hooks; see tag.js for the shape.
import { classic, infection, freeze, lavatag } from './tag.js';
import { sandbox, lava, rush, koth, hub } from './arcade.js';
import { hotseat, ctf, dodgeball, hideseek } from './team.js';
import { backrooms } from './backrooms.js';
import { heist, kitchen, conveyor, treasure, zombies, boss } from './extra.js';

export const MODES = {
  hub: { name: 'Spawn Plaza', desc: 'Your home base.', min: 1, ...hub },
  sandbox: { name: 'Physics Sandbox', desc: 'A free-play room. Stack, throw, break.', min: 1, ...sandbox },
  tag: { name: 'Classic Tag', desc: '"It" has glowing hands. Grab someone to pass it on.', min: 2, ...classic },
  infection: { name: 'Infection', desc: 'Tagged players join the chasers. Last survivor wins.', min: 3, ...infection },
  freeze: { name: 'Freeze Tag', desc: 'Frozen until a teammate grabs you free.', min: 3, ...freeze },
  lava: { name: 'Rising Lava', desc: 'The floor is lava, and it keeps climbing.', min: 1, ...lava },
  lavatag: { name: 'Lava Tag', desc: '"It" is lava proof. Runners are not.', min: 2, ...lavatag },
  rush: { name: 'Grab Rush', desc: 'Grab as much as you can. Chain grabs for combos.', min: 1, ...rush },
  koth: { name: 'King of the Hill', desc: 'Hold the orb on top of the tower.', min: 2, ...koth },
  hotseat: { name: 'Hot Seat', desc: 'Throw the ticking bomb to someone else.', min: 2, ...hotseat },
  ctf: { name: 'Capture the Flag', desc: 'Carry the enemy flag home with both hands.', min: 2, ...ctf },
  dodgeball: { name: 'Dodgeball', desc: 'Catch to bring a teammate back.', min: 2, ...dodgeball },
  backrooms: { name: 'Escape the Backrooms', desc: '9 levels. 2 monsters each. Find the way out.', min: 1, ...backrooms },
  heist: { name: 'Vault Heist', desc: 'Steal loot past the lasers and stash it at the exit.', min: 1, ...heist },
  kitchen: { name: 'Kitchen Rush', desc: 'Cook the orders together. Drop ingredients on the pass.', min: 1, ...kitchen },
  conveyor: { name: 'Conveyor Sort', desc: 'Two teams. Grab goods off the belts into your bin.', min: 2, ...conveyor },
  treasure: { name: 'Treasure Dive', desc: 'Swim down for treasure and bring it to the boat.', min: 1, ...treasure },
  zombies: { name: 'Zombie Survival', desc: '8 waves. Find weapons. Climb to stay safe.', min: 1, ...zombies },
  boss: { name: 'Boss Fight', desc: 'Hit the giant. Get off the ground when it slams.', min: 1, ...boss },
  hideseek: { name: 'Hide and Seek', desc: 'Hide as a prop. Seekers grab to check.', min: 2, ...hideseek },
};
export const MODE_IDS = Object.keys(MODES).filter((k) => !MODES[k].hidden);
