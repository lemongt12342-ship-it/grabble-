// Score-based and survival modes: sandbox, rising lava, Grab Rush, King of the Hill.
import { dist, norm, sub, add, mul } from '../util.js';
import { ITEMS, RARITY, POOLS } from '../items.js';
import { scatter, aliveCount } from './common.js';
import { pointInBox } from '../collide.js';

export const sandbox = {
  auto: true,
  time: 0,
  arena: () => ({ kind: 'sandbox', theme: 'hub' }),
  init(sim) {
    sim.mdata = { spawnT: 0 };
    scatter(sim, [...POOLS.toys, ...POOLS.general], 10, 50);
  },
  update(sim, dt) {
    // the spawner pedestal tops up toys so there is always something to throw
    sim.mdata.spawnT += dt;
    if (sim.mdata.spawnT > 3 && sim.items.size < 40) {
      sim.mdata.spawnT = 0;
      const t = POOLS.toys[sim.rng.int(POOLS.toys.length)];
      sim.spawnItem(t, [sim.rng.range(-0.4, 0.4), 2.4, sim.rng.range(-0.4, 0.4)], { vel: [sim.rng.range(-1, 1), 3, sim.rng.range(-1, 1)] });
    }
  },
  onFall(sim, p) { sim.respawn(p); },
};

// ---- Rising lava: stay above it, last one standing wins ----------------------------------------
export const lava = {
  time: 200,
  arena: () => ({ kind: 'lavapit', theme: 'volcano' }),
  init(sim) {
    sim.mdata = { tick: 0 };
    scatter(sim, ['pu_ice', 'pu_ice', 'pu_boots', 'pu_arms', 'pu_dash'], 8, 20);
  },
  onLava(sim, p) { sim.eliminate(p, 'lava'); sim.giveScore(p, 0); },
  onElim(sim, p) {
    const left = sim.alive();
    if (sim.list().length > 1 && left.length <= 1) sim.endMatch({ winners: left.map((q) => q.id), reason: 'last standing' });
  },
  onFall(sim, p) { sim.eliminate(p, 'fell'); },
  update(sim, dt) {
    sim.mdata.tick += dt;
    if (sim.mdata.tick >= 1) {
      sim.mdata.tick = 0;
      for (const p of sim.alive()) sim.giveScore(p, 1);
    }
    if (sim.items.size < 8 && sim.rng() < 0.02) scatter(sim, ['pu_ice', 'pu_boots', 'pu_arms'], 1, 20);
  },
  bot(sim, p) {
    const y = (sim.lava ? sim.lava.y : 0) + 3;
    let best = null, bd = 1e9;
    for (const c of sim.cols) {
      if (!c.on || c.max[1] < y || c.boundary) continue;
      const m = [(c.min[0] + c.max[0]) / 2, c.max[1] + 1, (c.min[2] + c.max[2]) / 2];
      const d = Math.abs(m[1] - y) + dist(m, sim.body(p)) * 0.1;
      if (d < bd) { bd = d; best = m; }
    }
    return best ? { goal: best, speed: 3 } : null;
  },
  pub(sim) { return { left: sim.alive().length }; },
  finish(sim) { return { winners: sim.alive().map((p) => p.id), reason: 'survivors' }; },
};

// ---- Grab Rush: collect as many items as possible, chain grabs for a multiplier -------------------
export const rush = {
  time: 90,
  steal: true,
  arena: (sim) => ({ kind: 'courtyard', theme: ['toybox', 'candy', 'space'][sim.seed % 3] }),
  init(sim) {
    sim.mdata = { combo: {} };
    scatter(sim, ['coin', 'coin', 'coin', 'gem', 'gem', 'goldbar', 'relic', ...POOLS.toys.slice(0, 6)], 24, 50);
  },
  onGrab(sim, p, it) {
    if (it.state.counted && it.state.counted.includes(p.id)) return;
    it.state.counted = (it.state.counted || []).concat(p.id);
    const c = sim.mdata.combo[p.id] || { n: 0, t: -9 };
    c.n = sim.t - c.t < 3 ? Math.min(6, c.n + 1) : 1;
    c.t = sim.t;
    sim.mdata.combo[p.id] = c;
    const pts = (RARITY[it.def.rar] || RARITY.common).pts * c.n;
    sim.giveScore(p, pts, c.n > 1 ? 'x' + c.n : '');
    sim.stat(p, 'items');
  },
  update(sim, dt) {
    if (sim.items.size < 22 && sim.rng() < 0.08) scatter(sim, ['coin', 'coin', 'gem', 'goldbar', 'relic', 'ball', 'duck', 'pu_boots'], 2, 50);
  },
  bot: null,
  pub(sim) { return { combo: Object.fromEntries(Object.entries(sim.mdata.combo).map(([k, v]) => [k, sim.t - v.t < 3 ? v.n : 0])) }; },
  finish() { return { reason: 'time' }; },
};

// ---- King of the Hill: hold the glowing orb inside the hill zone ------------------------------------------
export const koth = {
  time: 150,
  steal: true,
  arena: () => ({ kind: 'tower', theme: 'night' }),
  init(sim) {
    sim.mdata = { acc: 0 };
    const hill = { id: 'hill', kind: 'hill', min: [-3, 41, -3], max: [3, 46, 3], pub: true };
    sim.addZone(hill);
    sim.mdata.orb = sim.spawnItem('orb', [0, 42, 0]);
  },
  update(sim, dt) {
    const orb = sim.mdata.orb;
    if (!orb || !sim.items.has(orb.id)) { sim.mdata.orb = sim.spawnItem('orb', [0, 42, 0]); return; }
    sim.mdata.acc += dt;
    if (sim.mdata.acc < 1) return;
    sim.mdata.acc -= 1;
    const h = orb.holder && sim.players.get(orb.holder.pid);
    if (h && h.alive && pointInBox(orb.pos, sim.zone('hill'))) sim.giveScore(h, 1, 'hill');
  },
  onFall(sim, p) { sim.respawn(p); },
  pub(sim) {
    const o = sim.mdata.orb;
    return { holder: o && o.holder ? o.holder.pid : '' };
  },
  finish() { return { reason: 'time' }; },
};

// ---- Spawn plaza: the hub with the computer. Not a match, just a place to hang out. -----------------------
export const hub = {
  auto: true,
  time: 0,
  hidden: true,
  arena: () => ({ kind: 'hub', theme: 'hub' }),
  init(sim) {
    sim.mdata = { t: 0 };
    scatter(sim, ['ball', 'duck', 'balloon', 'dodgeball', 'coin', 'egg'], 7, 24);
  },
  update(sim, dt) {
    sim.mdata.t += dt;
    if (sim.mdata.t > 6 && sim.items.size < 12) { sim.mdata.t = 0; scatter(sim, ['ball', 'duck', 'balloon', 'dodgeball'], 1, 24); }
  },
  onFall(sim, p) { sim.respawn(p); },
};
