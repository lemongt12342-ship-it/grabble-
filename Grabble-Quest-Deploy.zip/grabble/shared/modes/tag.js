// Tag family: classic, infection, freeze, and Lava Tag. No safe zones: nobody can stall, the
// chase stays fast. "It" has glowing hands. Grab someone and hold on for a moment to tag them;
// they can shake their controllers to wiggle free before the tag lands.

import { dist, norm, sub, add, mul } from '../util.js';
import { POOLS } from '../items.js';
import { pickIt, scatter, isIt, runners, aliveCount } from './common.js';

const TAG_HOLD = 0.8;

function tagBase(extra) {
  return {
    grabPlayers: true,
    time: 150,
    steal: true,
    arena: (sim) => ({ kind: 'courtyard', theme: ['toybox', 'candy', 'night', 'attic'][sim.seed % 4] }),
    init(sim) {
      sim.mdata = { tickScore: 0, lastIt: null, itTime: {} };
      scatter(sim, [...POOLS.runner, ...POOLS.chaser, ...POOLS.general], 8, 28);
      pickIt(sim);
    },
    onJoin(sim, p) { if (sim.phase !== 'lobby' && !sim.list().some(isIt)) pickIt(sim); },
    onLeave(sim, p) { if (p.role === 'it' && sim.phase === 'play') pickIt(sim, p.id); },
    canGrab(sim, p, t) { return isIt(p) && !isIt(t) && !t.fx.frozen; },
    update(sim, dt) {
      sim.mdata.tickScore += dt;
      if (sim.mdata.tickScore >= 1) {
        sim.mdata.tickScore -= 1;
        for (const p of sim.list()) if (p.alive && !isIt(p)) sim.giveScore(p, 1);
      }
      if (sim.items.size < 10 && sim.rng() < 0.01) scatter(sim, [...POOLS.runner, ...POOLS.chaser, ...POOLS.general], 1, 28);
      if (extra && extra.update) extra.update(sim, dt);
    },
    onHold(sim, p, t, held) {
      if (held < TAG_HOLD || !isIt(p)) return;
      if (extra && extra.tag) extra.tag(sim, p, t);
    },
    bot(sim, p) {
      if (isIt(p)) {
        const t = sim.nearestPlayer(sim.body(p), (q) => q !== p && !isIt(q) && !q.fx.frozen);
        if (!t) return null;
        // reach out: grab when close
        if (dist(sim.body(t), sim.body(p)) < 0.9 && sim.rng() < 0.2) {
          p.grip[0] = 1;
          if (!p.grabbing[0] && !t.held) { p.grabbing[0] = t.id; t.held = { by: p.id, hand: 0, t: 0 }; }
        }
        return { goal: sub(sim.body(t), [0, 0, 0]), speed: sim.hasFx(p, 'boost') ? 5.4 : 3.9 };
      }
      const it = sim.nearestPlayer(sim.body(p), isIt, 12);
      if (it) return { goal: add(sim.body(p), mul(norm(sub(sim.body(p), sim.body(it))), 6)), speed: 4.1 };
      return null;
    },
    pub(sim) {
      return { its: sim.list().filter(isIt).map((p) => p.id), left: runners(sim).length };
    },
    finish(sim) {
      const alive = runners(sim);
      if (extra && extra.finish) return extra.finish(sim, alive);
      return { winners: [], reason: 'time' };
    },
    ...extra && extra.hooks,
  };
}

function swapIt(sim, p, t) {
  p.role = '';
  t.role = 'it';
  sim.setFx(p, 'immune', 2.2);
  sim.setFx(p, 'stun', 0.8);
  sim.setFx(t, 'immune', 1.0);
  sim.stat(p, 'tags');
  sim.giveScore(p, 5, 'tag');
  sim.emit({ e: 'tag', by: p.id, id: t.id });
  sim.knock(p, [0, 0.3, 0], 2, 0.6);
}

export const classic = tagBase({
  tag(sim, p, t) { swapIt(sim, p, t); },
  finish(sim) {
    // winner: lowest time as "it" is tracked by score (runners earn, "it" does not)
    return { winners: [], reason: 'time' };
  },
});

export const infection = tagBase({
  hooks: { time: 180 },
  tag(sim, p, t) {
    t.role = 'it';
    sim.setFx(p, 'stun', 0.5);
    sim.stat(p, 'tags');
    sim.giveScore(p, 4, 'infect');
    sim.emit({ e: 'tag', by: p.id, id: t.id });
    sim.setFx(t, 'boost', 4);
    if (runners(sim).length === 0) sim.endMatch({ reason: 'all infected', winners: sim.list().filter(isIt).map((q) => q.id).slice(0, 1) });
  },
  update(sim) {
    if (sim.phase === 'play' && runners(sim).length === 0 && sim.list().length > 1) sim.endMatch({ reason: 'all infected' });
  },
  finish(sim, alive) {
    return { winners: alive.map((p) => p.id), reason: alive.length ? 'survivors' : 'time' };
  },
});

export const freeze = tagBase({
  canGrab: null,
  hooks: {
    canGrab(sim, p, t) { return isIt(p) ? !isIt(t) && !t.fx.frozen && !sim.hasFx(t, 'frozen') : !isIt(t) && sim.hasFx(t, 'frozen'); },
  },
  tag(sim, p, t) {
    if (sim.hasFx(t, 'frozen')) return;
    sim.setFx(t, 'frozen', 999);
    t.vel = [0, 0, 0];
    sim.stat(p, 'tags');
    sim.giveScore(p, 3, 'freeze');
    sim.emit({ e: 'freeze', id: t.id, by: p.id });
    sim.setFx(p, 'stun', 0.3);
    if (runners(sim).every((q) => sim.hasFx(q, 'frozen'))) sim.endMatch({ reason: 'all frozen', winners: sim.list().filter(isIt).map((q) => q.id).slice(0, 1) });
  },
  finish(sim, alive) {
    const free = alive.filter((q) => !sim.hasFx(q, 'frozen'));
    return { winners: free.map((q) => q.id), reason: free.length ? 'free runners' : 'time' };
  },
  update(sim) {
    for (const p of sim.list()) if (sim.hasFx(p, 'frozen')) { p.vel = [0, 0, 0]; }
  },
});
// Teammates unfreeze by holding a frozen runner (the same hold that tags). Intercept it here.
const _hold = freeze.onHold;
freeze.onHold = function (sim, p, t, held) {
  if (!isIt(p) && sim.hasFx(t, 'frozen') && held > 0.5) {
    t.fx.frozen = 0;
    sim.setFx(t, 'immune', 2);
    sim.giveScore(p, 3, 'rescue');
    sim.stat(p, 'rescues');
    sim.emit({ e: 'unfreeze', id: t.id, by: p.id });
    return;
  }
  return _hold(sim, p, t, held);
};

// ---- Lava Tag: "it" is lava proof and chases while the floor rises --------------------------------
export const lavatag = {
  grabPlayers: true,
  time: 150,
  arena: (sim) => ({ kind: 'lavapit', theme: 'volcano' }),
  init(sim) {
    sim.mdata = { tickScore: 0 };
    scatter(sim, [...POOLS.runner, 'pu_ice', 'pu_ice', 'pu_dash'], 7, 28);
    pickIt(sim);
    sim.lavaSpeedMul = 0.8;
  },
  onJoin(sim) { if (sim.phase !== 'lobby' && !sim.list().some(isIt)) pickIt(sim); },
  onLeave(sim, p) { if (p.role === 'it' && sim.phase === 'play') pickIt(sim, p.id); },
  canGrab(sim, p, t) { return isIt(p) && !isIt(t); },
  update(sim, dt) {
    for (const p of sim.list()) if (isIt(p)) sim.setFx(p, 'lavaproof', 0.2);
    sim.mdata.tickScore += dt;
    if (sim.mdata.tickScore >= 1) { sim.mdata.tickScore -= 1; for (const p of sim.list()) if (p.alive && !isIt(p)) sim.giveScore(p, 1); }
    if (runners(sim).length === 0 && sim.list().length > 1) sim.endMatch({ reason: 'all runners burned', winners: sim.list().filter(isIt).map((q) => q.id).slice(0, 1) });
  },
  onHold(sim, p, t, held) {
    if (held < TAG_HOLD || !isIt(p)) return;
    swapIt(sim, p, t);
    sim.setFx(p, 'lavaproof', 3); // the new runner gets a short lava proof boost
  },
  onLava(sim, p) { sim.eliminate(p, 'lava'); },
  onElim(sim, p) { if (p.role === 'it') pickIt(sim, p.id); },
  bot(sim, p) {
    if (isIt(p)) {
      const t = sim.nearestPlayer(sim.body(p), (q) => !isIt(q));
      return t ? { goal: sim.body(t), speed: 3.8 } : null;
    }
    const up = sim.arena.itemSpots[0];
    return { goal: [0, Math.max(2, (sim.lava ? sim.lava.y : 0) + 3), 0], speed: 3 };
  },
  pub(sim) { return { its: sim.list().filter(isIt).map((p) => p.id), left: runners(sim).length }; },
  finish(sim) { return { winners: runners(sim).map((p) => p.id), reason: 'survivors' }; },
};
