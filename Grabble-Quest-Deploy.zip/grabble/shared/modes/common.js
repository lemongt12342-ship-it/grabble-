// Helpers shared by game modes.
import { ITEMS } from '../items.js';

export const isIt = (p) => p.role === 'it';
export const runners = (sim) => sim.list().filter((p) => p.alive && !p.spec && p.role !== 'it');
export const aliveCount = (sim) => sim.alive().length;

export function pickIt(sim, exceptId) {
  const pool = sim.list().filter((p) => p.alive && p.id !== exceptId);
  for (const p of sim.list()) p.role = '';
  if (!pool.length) return null;
  const it = pool[sim.rng.int(pool.length)];
  it.role = 'it';
  sim.setFx(it, 'immune', 1.5);
  sim.emit({ e: 'it', id: it.id });
  return it;
}

// Drop n random items from pool at random item spots.
export function scatter(sim, pool, n, maxItems = 60) {
  const spots = sim.arena.itemSpots;
  if (!spots.length) return;
  for (let i = 0; i < n && sim.items.size < maxItems; i++) {
    const s = spots[sim.rng.int(spots.length)];
    const type = pool[sim.rng.int(pool.length)];
    if (ITEMS[type]) sim.spawnItem(type, [s[0] + sim.rng.range(-0.8, 0.8), s[1] + 0.3, s[2] + sim.rng.range(-0.8, 0.8)]);
  }
}

export function teamOf(sim, p) { return p.team; }
export function assignTeams(sim, n = 2) {
  const list = sim.list();
  list.forEach((p, i) => { p.team = i % n; });
}
