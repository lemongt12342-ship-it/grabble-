// Escape the Backrooms. 1 to 4 players, 9 levels, 2 monsters per level that get stronger each level.
// You start with no weapon. Weapons can be found in the levels, and so can lights, power-ups and notes.
//
// Options (sim.opts): level (start level, 1 to 9), difficulty 'chill' | 'normal' | 'hard',
// seed (the daily seed gives every player the same maze), mods.

import { dist, len, clamp, r3, cleanName } from '../util.js';
import { head } from '../loco.js';
import { buildBackroomsLevel, levelInfo, cellOf } from '../backrooms/levels.js';
import { spawnMonsters } from '../backrooms/monsters.js';
import { pointInBox } from '../collide.js';

function applyArena(sim, a) {
  a.colliders.forEach((c, i) => { c.id = i; if (c.on === undefined) c.on = true; });
  sim.arena = a;
  sim.cols = a.colliders;
  sim.zones = a.zones.map((z) => ({ ...z }));
  sim.hazards = [];
  sim.env.waterY = a.waterY;
  sim.env.gravity = a.gravity;
  sim.arenaKind = 'backrooms';
  sim.themeId = a.themeId;
  sim.level = a.level;
}

function populate(sim) {
  const a = sim.arena;
  for (const it of sim.items.values()) it.dead = true;
  sim.items.clear();
  sim.ents.clear();
  sim.noises = [];
  for (const pl of a.plan) {
    const it = sim.spawnItem(pl.type, pl.pos, { state: { ...pl.state } });
    if (it && pl.type === 'flashlight') it.on = false;
  }
  if (sim.difficulty !== 'chill') spawnMonsters(sim, a.level, sim.difficulty === 'hard');
  const info = levelInfo(a.level);
  sim.mdata.need = { ...info.need };
  sim.mdata.have = {};
  for (const k in info.need) sim.mdata.have[k] = 0;
  sim.mdata.doorOpen = false;
  sim.mdata.levelStart = sim.t;
}

export function loadLevel(sim, n) {
  const a = buildBackroomsLevel(n, sim.seed, { hard: sim.difficulty === 'hard' });
  applyArena(sim, a);
  populate(sim);
  for (const p of sim.list()) {
    sim.respawn(p, a.spawns[p.si % a.spawns.length]);
    p.hp = p.maxHp;
    p.sanity = Math.max(p.sanity ?? 1, 0.6);
    p.struggle = 0;
  }
  sim.emit({ e: 'level', n, name: info(n).name });
}
const info = levelInfo;

const lit = (sim, p) => {
  if (!sim.arena.theme.dark) return true;
  for (let i = 0; i < 2; i++) { const it = p.hold[i] && sim.items.get(p.hold[i]); if (it && it.on) return true; }
  for (const it of sim.items.values()) if (it.type === 'glowstick' && dist(it.pos, sim.body(p)) < 3.5) return true;
  return false;
};

export const backrooms = {
  time: 0,
  steal: true,
  arena: () => ({ kind: 'backrooms', theme: 'bk1' }),
  buildArena(sim, opts) {
    const n = clamp((opts.level | 0) || 1, 1, 9);
    const a = buildBackroomsLevel(n, sim.seed, { hard: sim.difficulty === 'hard' });
    sim.level = n;
    sim.arenaKind = 'backrooms';
    return a;
  },
  init(sim) {
    sim.mdata = { need: {}, have: {}, doorOpen: false, levelStart: 0, levels: [], acc: 0, noiseT: 0 };
    sim.noises = [];
    loadLevel(sim, clamp((sim.opts.level | 0) || 1, 1, 9));
  },
  onJoin(sim, p) { if (sim.arena.spawns) sim.respawn(p, sim.arena.spawns[p.si % sim.arena.spawns.length]); },
  onFall(sim, p) { sim.respawn(p, sim.arena.spawns[0]); },
  onElim(sim, p) {
    if (sim.phase === 'play' && sim.alive().length === 0) {
      sim.endMatch({ winners: [], reason: 'caught on level ' + sim.level, level: sim.level, time: Math.round(sim.t) });
    }
  },
  update(sim, dt) {
    const d = sim.mdata;
    // ---- noise: fast movement and thrown things draw the monsters ----
    d.noiseT += dt;
    if (d.noiseT >= 0.5) {
      d.noiseT = 0;
      for (const p of sim.alive()) {
        const sp = len(p.vel);
        if (sp > 5) sim.noises.push({ pos: sim.body(p).slice(), r: 14, t: sim.t });
        else if (sp > 2.5) sim.noises.push({ pos: sim.body(p).slice(), r: 7, t: sim.t });
      }
      for (const it of sim.items.values()) if (!it.holder && len(it.vel) > 5) sim.noises.push({ pos: it.pos.slice(), r: 12, t: sim.t });
    }
    sim.noises = sim.noises.filter((n) => sim.t - n.t < 4);

    // ---- sockets: drop the right items into the glowing socket ----
    const sock = sim.zone('socket');
    for (const it of [...sim.items.values()]) {
      if (it.holder || !pointInBox(it.pos, sock)) continue;
      const need = d.need[it.type];
      if (need === undefined || d.have[it.type] >= need) continue;
      d.have[it.type]++;
      sim.removeItem(it);
      sim.emit({ e: 'socket', type: it.type, have: d.have[it.type], need });
      const by = it.lastThrower && sim.players.get(it.lastThrower) || it.lastHolder && sim.players.get(it.lastHolder);
      if (by) sim.giveScore(by, 10, 'socket');
    }
    if (!d.doorOpen && Object.keys(d.need).every((k) => d.have[k] >= d.need[k])) {
      d.doorOpen = true;
      for (const dr of sim.arena.doors) dr.on = false;
      sim.msg('The exit door unlocked');
      sim.emit({ e: 'sfx', k: 'door', pos: r3(sim.arena.exitPos) });
    }

    // ---- sanity ----
    for (const p of sim.alive()) {
      let rate = 0.02;
      if (!lit(sim, p)) rate = -0.014;
      for (const e of sim.ents.values()) if (e.st !== 'dead' && dist(e.pos, sim.body(p)) < 9) rate -= 0.03;
      p.sanity = clamp((p.sanity ?? 1) + rate * dt, 0, 1);
    }

    // ---- reaching the exit ----
    if (d.doorOpen) {
      const alive = sim.alive();
      const ex = sim.zone('exit');
      if (alive.length && alive.every((p) => pointInBox(sim.body(p), ex))) {
        const lvl = sim.level;
        d.levels.push({ n: lvl, time: Math.round(sim.t - d.levelStart) });
        for (const p of alive) { sim.giveScore(p, 100 * lvl, 'level'); sim.stat(p, 'levels'); }
        if (lvl >= 9) sim.endMatch({ winners: alive.map((p) => p.id), reason: 'escaped', level: 9, time: Math.round(sim.t), levels: d.levels });
        else { sim.emit({ e: 'sfx', k: 'descend' }); loadLevel(sim, lvl + 1); }
      }
    }
  },
  pub(sim) {
    const d = sim.mdata, hard = sim.difficulty === 'hard';
    return {
      level: sim.level, name: levelInfo(sim.level).name, note: levelInfo(sim.level).note,
      need: d.need, have: d.have, open: !!d.doorOpen, dark: !!sim.arena.theme.dark,
      exit: hard ? null : r3(sim.arena.exitPos), diff: sim.difficulty, run: Math.round(sim.t),
      monsters: [...sim.ents.values()].filter((e) => e.st !== 'dead').length,
    };
  },
  finish(sim) { return { winners: [], reason: 'time' }; },
};
