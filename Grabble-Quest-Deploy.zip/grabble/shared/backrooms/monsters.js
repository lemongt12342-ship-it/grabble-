// The two monsters that hunt every Backrooms level. They get stronger with every level.
//
//   stalker : hunts by sound and light. Heads for noise, loses you in smoke, remembers hiding spots.
//   lurker  : patrols slowly, then lunges when you are close and in view.
//
// "Learning AI": every time a monster loses a player it notes the cell the player was last seen in.
// Cells with several notes get patrolled first, so reusing the same hiding spot gets worse each time.

import { dist, norm, sub, add, mul, len, clamp, r3, distXZ } from '../util.js';
import { lineOfSight } from '../collide.js';
import { head, handVelocity } from '../loco.js';
import { spawnEntity } from '../simhaz.js';
import { bfs, cellOf, cellCenter, neighbors } from './levels.js';

export function monsterStats(n, kind, hard = false) {
  const h = hard ? 1.25 : 1;
  const stalker = kind === 'stalker';
  return {
    speed: ((stalker ? 1.9 : 1.6) + n * (stalker ? 0.3 : 0.27)) * h,
    lungeSpeed: (3.6 + n * 0.32) * h,
    hp: 80 + 28 * n,
    maxHp: 80 + 28 * n,
    sight: 8 + n * 0.8,
    sightLit: 15 + n * 1.0,
    hear: (stalker ? 1.0 : 0.5) + n * 0.07,
    catchTime: Math.max(1.0, 3.0 - n * 0.2),
    damage: (22 + n * 6) * h,
    resist: 1 + n * 0.1,
    armor: 1 + n * 0.08,
    r: stalker ? 0.55 : 0.5,
    scale: 1 + n * 0.03,
  };
}

export function spawnMonsters(sim, level, hard) {
  const spawns = sim.arena.monsterSpawns;
  ['stalker', 'lurker'].forEach((kind, i) => {
    const s = monsterStats(level, kind, hard);
    spawnEntity(sim, kind, spawns[i], {
      ...s, lvl: level, think, persistent: true, respawnIn: 18, mem: {}, st: 'patrol', stunUntil: 0, cooldown: 3, spawn: spawns[i],
      distFor: null, distMap: null, goal: null, goalT: 0,
    });
  });
}

function playerLit(sim, p) {
  if (!sim.arena.theme.dark) return true;
  for (let i = 0; i < 2; i++) {
    const it = p.hold[i] && sim.items.get(p.hold[i]);
    if (it && it.on) return true;
  }
  for (const it of sim.items.values()) if (it.type === 'glowstick' && dist(it.pos, sim.body(p)) < 3.5) return true;
  return false;
}

function hidden(sim, p) {
  for (const z of sim.zones) if (z.kind === 'smoke' && sim.inZone(sim.body(p), z)) return true;
  return false;
}

function stepToward(sim, e, goal, speed, dt) {
  const nav = sim.arena.nav;
  const c = cellOf(nav, e.pos), g = cellOf(nav, goal);
  let target = goal;
  if (c[0] !== g[0] || c[1] !== g[1]) {
    const key = g[0] * 100 + g[1];
    if (e.distFor !== key || sim.t - (e.distT || 0) > 1.5) { e.distMap = bfs(nav, g[0], g[1]); e.distFor = key; e.distT = sim.t; }
    let bd = e.distMap[c[0]][c[1]], nx = c[0], ny = c[1];
    for (const [ax, ay] of neighbors(nav, c[0], c[1])) if (e.distMap[ax][ay] >= 0 && e.distMap[ax][ay] < bd) { bd = e.distMap[ax][ay]; nx = ax; ny = ay; }
    target = cellCenter(nav, nx, ny, e.pos[1]);
  }
  const d = sub(target, e.pos);
  d[1] = 0;
  const l = len(d);
  if (l > 0.05) {
    const step = Math.min(l, speed * dt);
    e.pos = [e.pos[0] + (d[0] / l) * step, e.pos[1], e.pos[2] + (d[2] / l) * step];
    e.yaw = Math.atan2(d[2], d[0]);
  }
}

function think(sim, e, dt) {
  if (e.st === 'dead') return;
  const nav = sim.arena.nav;

  // ---- holding a player: they shake the controllers to break free ----
  if (e.catch) {
    const p = sim.players.get(e.catch.pid);
    if (!p || !p.alive) { e.catch = null; return; }
    e.st = 'catch';
    e.catch.t += dt;
    sim.setFx(p, 'hold', 0.12);
    p.loco.anchor = [null, null];
    p.root = add(p.root, [(e.pos[0] - sim.body(p)[0]) * 3 * dt, 0, (e.pos[2] - sim.body(p)[2]) * 3 * dt]);
    p.vel = [0, 0, 0];
    const sv = (len(handVelocity(p, 0, dt)) + len(handVelocity(p, 1, dt))) / 2;
    p.struggle = clamp(p.struggle + Math.max(0, sv - 1.6) * dt * 0.3 - dt * 0.1, 0, 1.2);
    if (p.struggle >= 1) {
      e.catch = null;
      p.struggle = 0;
      e.stunUntil = sim.t + 3 / e.resist;
      e.cooldown = 4;
      sim.setFx(p, 'immune', 2.5);
      sim.emit({ e: 'escape', id: p.id, by: 'monster' });
      sim.stat(p, 'escapes');
      return;
    }
    if (e.catch.t >= e.catchTime) {
      p.hp -= e.damage;
      p.struggle = 0;
      sim.emit({ e: 'sfx', k: 'chomp', pos: r3(e.pos) });
      sim.knock(p, norm(sub(sim.body(p), e.pos)), 5, 1.0);
      e.catch = null;
      e.cooldown = 3;
      sim.setFx(p, 'immune', 2);
      if (p.hp <= 0) { p.hp = 0; sim.eliminate(p, 'caught'); }
    }
    return;
  }
  e.cooldown = Math.max(0, e.cooldown - dt);

  // ---- perception ----
  let seen = null, sd = 1e9;
  for (const p of sim.players.values()) {
    if (!p.alive || p.spec || sim.hasFx(p, 'immune') || hidden(sim, p)) continue;
    const d = dist(sim.body(p), e.pos);
    const reach = playerLit(sim, p) ? e.sightLit : e.sight;
    if (d < reach && d < sd && lineOfSight(e.pos, head(p), sim.cols)) { seen = p; sd = d; }
  }
  if (seen) {
    if (e.target !== seen.id) sim.emit({ e: 'monster', id: e.id, k: 'spot' });
    e.target = seen.id;
    e.lastSeen = { pos: sim.body(seen).slice(), t: sim.t, cell: cellOf(nav, sim.body(seen)) };
    e.st = 'chase';
  } else if (e.target) {
    if (sim.t - e.lastSeen.t > 3.5) {
      const k = e.lastSeen.cell.join(',');
      e.mem[k] = (e.mem[k] || 0) + 1; // learn: this is where they hide
      e.target = null;
      e.st = 'search';
      e.goal = e.lastSeen.pos;
      e.goalT = sim.t + 5;
    }
  }

  // ---- noise ----
  if (!e.target) {
    for (const nz of sim.noises) {
      if (dist(nz.pos, e.pos) < nz.r * e.hear) { e.goal = nz.pos; e.goalT = sim.t + 6; e.st = 'investigate'; break; }
    }
  }

  // ---- act ----
  if (e.target) {
    const p = sim.players.get(e.target);
    if (!p || !p.alive) { e.target = null; return; }
    const d = dist(sim.body(p), e.pos);
    let speed = e.speed;
    if (e.kind === 'lurker') {
      if (e.lunge > sim.t) { speed = e.lungeSpeed; e.st = 'lunge'; }
      else if (d < 6 && e.cooldown <= 0 && lineOfSight(e.pos, head(p), sim.cols)) { e.lunge = sim.t + 1.2; e.cooldown = 5; sim.emit({ e: 'monster', id: e.id, k: 'lunge' }); }
    } else if (d < 5) speed *= 1.15; // stalkers speed up when they are on top of you
    if (lineOfSight(e.pos, head(p), sim.cols)) stepToward(sim, e, [sim.body(p)[0], e.pos[1], sim.body(p)[2]], speed, dt);
    else stepToward(sim, e, e.lastSeen.pos, speed, dt);
    if (d < 0.95 && e.cooldown <= 0 && !sim.hasFx(p, 'immune')) {
      e.catch = { pid: p.id, t: 0 };
      p.struggle = 0;
      sim.emit({ e: 'monster', id: e.id, k: 'grab' });
    }
    return;
  }
  if (e.goal && sim.t < e.goalT && dist(e.goal, e.pos) > 1.2) { stepToward(sim, e, e.goal, e.speed * (e.st === 'investigate' ? 0.9 : 0.7), dt); return; }
  e.st = 'patrol';
  // patrol. Learned hiding spots come first.
  if (!e.patrolGoal || dist(e.patrolGoal, e.pos) < 1.2) {
    const learned = Object.entries(e.mem).sort((a, b) => b[1] - a[1]);
    if (learned.length && learned[0][1] >= 2 && sim.rng() < 0.55) {
      const [cx, cy] = learned[0][0].split(',').map(Number);
      e.patrolGoal = cellCenter(nav, cx, cy, e.pos[1]);
    } else {
      e.patrolGoal = cellCenter(nav, sim.rng.int(nav.w), sim.rng.int(nav.h), e.pos[1]);
    }
  }
  stepToward(sim, e, e.patrolGoal, e.speed * 0.55, dt);
}
