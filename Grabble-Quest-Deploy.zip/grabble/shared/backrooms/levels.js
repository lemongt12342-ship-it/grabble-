// Escape the Backrooms: 9 levels, generated from (level, seed). Every client and the server build the
// same maze from those two numbers, so no geometry is sent over the network.
//
// Each level is a maze on a grid of 4 m cells. You find puzzle items (fuses, keycards, batteries),
// put them into the socket next to the exit door, and the door unlocks. Two monsters roam every level.

import { box, boxC } from '../collide.js';
import { rng, clamp } from '../util.js';

export const CS = 4; // cell size in metres
export const WALL_H = 3.4;
const T = 0.4;

export const LEVELS = [
  { n: 1, name: 'The Lobby', size: 8, need: { fuse: 2 }, dark: false, water: false, wall: '#d6c25a', floor: '#9a8a4e', fog: '#c9b95a', note: 'Moist carpet. Buzzing lights.' },
  { n: 2, name: 'Pipe Dreams', size: 9, need: { fuse: 1, keycard: 1 }, dark: false, water: false, wall: '#6b7a80', floor: '#3f484c', fog: '#4b575c', note: 'Hot pipes, distant clanging.' },
  { n: 3, name: 'The Poolrooms', size: 9, need: { battery: 2 }, dark: false, water: true, wall: '#9fe0e8', floor: '#5bb5c2', fog: '#8ad0da', note: 'Tile and still water.' },
  { n: 4, name: 'Parking Garage', size: 10, need: { keycard: 2 }, dark: true, water: false, wall: '#7d7d7d', floor: '#4f4f4f', fog: '#2b2b2b', note: 'Empty spaces. One car alarm.' },
  { n: 5, name: 'Office Floors', size: 11, need: { fuse: 2, battery: 1 }, dark: false, water: false, wall: '#b8b2a0', floor: '#6f6a5c', fog: '#9a9485', note: 'Cubicles with no names.' },
  { n: 6, name: 'The Warehouse', size: 12, need: { keycard: 2, fuse: 1 }, dark: false, water: false, wall: '#8c6b4a', floor: '#58442f', fog: '#6e5438', note: 'Crates stacked to the ceiling.' },
  { n: 7, name: 'Lights Out', size: 12, need: { battery: 3 }, dark: true, water: false, wall: '#5a5470', floor: '#34304a', fog: '#15121f', note: 'The power failed here.' },
  { n: 8, name: 'The Sewers', size: 13, need: { fuse: 2, keycard: 2 }, dark: true, water: true, wall: '#52684f', floor: '#2f3f2d', fog: '#162015', note: 'Knee deep. Something moves.' },
  { n: 9, name: 'The Void', size: 14, need: { fuse: 3, keycard: 2, battery: 2 }, dark: true, water: false, wall: '#2a2335', floor: '#171221', fog: '#07050c', note: 'No way out but through.' },
];

export const NOTES = [
  'Day 3. The hallway repeated. I counted the doors twice.',
  'It follows the noise. Do not throw things unless you mean to.',
  'The lights hum louder when it is close.',
  'I hid under the desk. It remembered the desk.',
  'Fuses glow a little. Keycards hum. Batteries are warm.',
  'Two of them. Always two. One hunts by sound, one waits.',
  'The deeper levels are darker. Bring a light and a friend.',
  'If it grabs you, shake free. Do not stop shaking.',
  'There was a bat in a locker. I did not need it. I wish I had taken it.',
  'Nine floors. I reached six. Tell my family the carpet was real.',
  'The exit door only opens when the sockets are full.',
  'It learns. Never hide in the same place twice.',
];

export function levelInfo(n) { return LEVELS[clamp(n | 0, 1, 9) - 1]; }

// ---- maze --------------------------------------------------------------------------------------------------------
function carve(w, h, r, braid) {
  const right = Array.from({ length: w }, () => Array(h).fill(false));
  const down = Array.from({ length: w }, () => Array(h).fill(false));
  const seen = Array.from({ length: w }, () => Array(h).fill(false));
  const sx = r.int(w), sy = r.int(h);
  seen[sx][sy] = true;
  const stack = [[sx, sy]];
  while (stack.length) {
    const [x, y] = stack[stack.length - 1];
    const nb = [];
    if (x > 0 && !seen[x - 1][y]) nb.push([x - 1, y, 'l']);
    if (x < w - 1 && !seen[x + 1][y]) nb.push([x + 1, y, 'r']);
    if (y > 0 && !seen[x][y - 1]) nb.push([x, y - 1, 'u']);
    if (y < h - 1 && !seen[x][y + 1]) nb.push([x, y + 1, 'd']);
    if (!nb.length) { stack.pop(); continue; }
    const [nx, ny, d] = nb[r.int(nb.length)];
    if (d === 'r') right[x][y] = true;
    else if (d === 'l') right[nx][ny] = true;
    else if (d === 'd') down[x][y] = true;
    else down[nx][ny] = true;
    seen[nx][ny] = true;
    stack.push([nx, ny]);
  }
  // knock out some walls so there are loops. Loops give you something to run around and hide in.
  for (let x = 0; x < w; x++) for (let y = 0; y < h; y++) {
    if (x < w - 1 && !right[x][y] && r() < braid) right[x][y] = true;
    if (y < h - 1 && !down[x][y] && r() < braid) down[x][y] = true;
  }
  return { w, h, right, down };
}

export function neighbors(nav, x, y) {
  const out = [];
  if (x < nav.w - 1 && nav.right[x][y]) out.push([x + 1, y]);
  if (x > 0 && nav.right[x - 1][y]) out.push([x - 1, y]);
  if (y < nav.h - 1 && nav.down[x][y]) out.push([x, y + 1]);
  if (y > 0 && nav.down[x][y - 1]) out.push([x, y - 1]);
  return out;
}

export function bfs(nav, sx, sy) {
  const dist = Array.from({ length: nav.w }, () => Array(nav.h).fill(-1));
  dist[sx][sy] = 0;
  const q = [[sx, sy]];
  for (let i = 0; i < q.length; i++) {
    const [x, y] = q[i];
    for (const [nx, ny] of neighbors(nav, x, y)) if (dist[nx][ny] < 0) { dist[nx][ny] = dist[x][y] + 1; q.push([nx, ny]); }
  }
  return dist;
}

export function cellOf(nav, pos) {
  return [clamp(Math.floor((pos[0] - nav.ox) / CS), 0, nav.w - 1), clamp(Math.floor((pos[2] - nav.oz) / CS), 0, nav.h - 1)];
}
export function cellCenter(nav, x, y, py = 0) { return [nav.ox + (x + 0.5) * CS, py, nav.oz + (y + 0.5) * CS]; }

// ---- level builder ------------------------------------------------------------------------------------------------
export function buildBackroomsLevel(n, seed, opts = {}) {
  const info = levelInfo(n);
  const r = rng((seed ^ (n * 0x9e3779b1)) >>> 0);
  const w = info.size, h = info.size;
  const nav = carve(w, h, r, 0.07 + n * 0.006);
  nav.ox = -(w * CS) / 2;
  nav.oz = -(h * CS) / 2;

  const a = {
    kind: 'backrooms', themeId: 'bk' + n, seed, level: n, size: [w * CS, h * CS],
    theme: { name: info.name, sky: info.fog, fog: info.fog, floor: info.floor, platform: info.wall, wall: info.wall, accent: '#ffd43b', gravity: 9.8, dark: info.dark, water: info.water },
    colliders: [], spawns: [], zones: [], props: [], hazards: [], itemSpots: [],
    bounds: { min: [nav.ox - 2, -6, nav.oz - 2], max: [nav.ox + w * CS + 2, 10, nav.oz + h * CS + 2] },
    lava: null, waterY: info.water ? 0.35 : undefined, gravity: 9.8, kidSafe: false, nav,
    lvl: info,
  };
  const C = a.colliders;
  C.push(box([nav.ox - 1, -4, nav.oz - 1], [nav.ox + w * CS + 1, 0, nav.oz + h * CS + 1], { c: 'floor' }));
  // outer walls
  const X0 = nav.ox, X1 = nav.ox + w * CS, Z0 = nav.oz, Z1 = nav.oz + h * CS;
  C.push(box([X0 - T, -4, Z0 - T], [X1 + T, WALL_H, Z0], { c: 'wall', boundary: true }), box([X0 - T, -4, Z1], [X1 + T, WALL_H, Z1 + T], { c: 'wall', boundary: true }),
    box([X0 - T, -4, Z0], [X0, WALL_H, Z1], { c: 'wall', boundary: true }), box([X1, -4, Z0], [X1 + T, WALL_H, Z1], { c: 'wall', boundary: true }));
  C.push(box([X0, WALL_H, Z0], [X1, WALL_H + 0.5, Z1], { c: 'wall', boundary: true, see: true })); // ceiling
  // inner walls
  const wall = (cx, cz, sx, sz, extra = {}) => boxC(cx, WALL_H / 2, cz, sx, WALL_H, sz, { c: 'wall', ...extra });
  const edgeV = (x, y, extra) => wall(nav.ox + (x + 1) * CS, nav.oz + (y + 0.5) * CS, T, CS + T, extra);
  const edgeH = (x, y, extra) => wall(nav.ox + (x + 0.5) * CS, nav.oz + (y + 1) * CS, CS + T, T, extra);
  for (let x = 0; x < w; x++) for (let y = 0; y < h; y++) {
    if (x < w - 1 && !nav.right[x][y]) C.push(edgeV(x, y));
    if (y < h - 1 && !nav.down[x][y]) C.push(edgeH(x, y));
  }

  // spawn, exit and socket cells
  const sx = r.int(2), sy = r.int(h);
  const d0 = bfs(nav, sx, sy);
  let ex = 0, ey = 0, best = -1;
  for (let x = 0; x < w; x++) for (let y = 0; y < h; y++) if (d0[x][y] > best) { best = d0[x][y]; ex = x; ey = y; }
  let kx = ex, ky = ey; // socket cell: the neighbour of the exit that is closer to spawn
  for (const [nx, ny] of neighbors(nav, ex, ey)) if (d0[nx][ny] < d0[kx][ky] || (kx === ex && ky === ey)) { kx = nx; ky = ny; }
  a.spawnCell = [sx, sy]; a.exitCell = [ex, ey]; a.socketCell = [kx, ky];
  a.maxDist = best;

  // door: seals every open side of the exit cell
  const doors = [];
  for (const [nx, ny] of neighbors(nav, ex, ey)) {
    let d;
    if (nx === ex + 1) d = edgeV(ex, ey, { c: 'door', dyn: true, mat: 'stone' });
    else if (nx === ex - 1) d = edgeV(ex - 1, ey, { c: 'door', dyn: true, mat: 'stone' });
    else if (ny === ey + 1) d = edgeH(ex, ey, { c: 'door', dyn: true, mat: 'stone' });
    else d = edgeH(ex, ey - 1, { c: 'door', dyn: true, mat: 'stone' });
    C.push(d); doors.push(d);
  }
  a.doors = doors;

  const ctr = (x, y, py = 0) => cellCenter(nav, x, y, py);
  const sc = ctr(kx, ky), ec = ctr(ex, ey);
  a.zones.push(
    { id: 'socket', kind: 'socket', min: [sc[0] - 1.2, 0, sc[2] - 1.2], max: [sc[0] + 1.2, 2.2, sc[2] + 1.2], pub: true },
    { id: 'exit', kind: 'exit', min: [ec[0] - 1.7, 0, ec[2] - 1.7], max: [ec[0] + 1.7, 3, ec[2] + 1.7], pub: true },
  );
  a.exitPos = ec; a.socketPos = sc;

  // spawn ring in the spawn cell
  const s0 = ctr(sx, sy);
  for (let i = 0; i < 6; i++) { const ang = (i / 6) * Math.PI * 2; a.spawns.push([s0[0] + Math.cos(ang) * 0.9, 0.2, s0[2] + Math.sin(ang) * 0.9]); }

  // candidate cells for stuff
  const cells = [];
  for (let x = 0; x < w; x++) for (let y = 0; y < h; y++) {
    if ((x === sx && y === sy) || (x === ex && y === ey) || (x === kx && y === ky)) continue;
    cells.push([x, y]);
  }
  const order = r.shuffle(cells);
  let ci = 0;
  const nextCell = () => order[ci++ % order.length];
  const place = (type, extra = {}) => {
    const [x, y] = nextCell();
    const c = ctr(x, y);
    return { type, pos: [c[0] + r.range(-1, 1), (extra.y ?? 0.3), c[2] + r.range(-1, 1)], state: extra.state || {}, cell: [x, y] };
  };
  const plan = [];
  for (const [type, count] of Object.entries(info.need)) for (let i = 0; i < count + 1; i++) plan.push(place(type));
  // light and tools at the start
  const startItem = (type, dx, dz, state) => plan.push({ type, pos: [s0[0] + dx, 0.3, s0[2] + dz], state: state || {}, cell: [sx, sy] });
  startItem('flashlight', 1.4, 0);
  if (info.dark) { startItem('glowstick', -1.2, 1); startItem('glowstick', -1.2, -1); }
  for (let i = 0; i < (info.dark ? 3 : 1); i++) plan.push(place('glowstick'));
  // notes
  for (let i = 0; i < 2; i++) { const it = place('note'); it.state.text = (n * 3 + i * 5 + r.int(NOTES.length)) % NOTES.length; plan.push(it); }
  // crates you can drag to block doors or reach shelves
  for (let i = 0; i < 3; i++) plan.push(place('crate'));
  // found weapons. You never start with one. Odds rise with depth; levels 3, 6 and 9 always have one.
  const weaponOdds = n % 3 === 0 ? 1 : 0.35 + n * 0.04;
  const weaponPool = n <= 3 ? ['bat', 'slingshot'] : n <= 6 ? ['bat', 'pipe', 'slingshot', 'baton'] : ['pipe', 'baton', 'flaregun', 'slingshot'];
  if (r() < weaponOdds) plan.push(place(weaponPool[r.int(weaponPool.length)]));
  if (n >= 5 && r() < 0.5) plan.push(place(weaponPool[r.int(weaponPool.length)]));
  // a few power-ups
  for (let i = 0; i < 2 + (n >> 2); i++) plan.push(place(r.pick(['pu_boots', 'pu_smoke', 'pu_decoy', 'pu_dash', 'pu_radar'])));
  a.plan = plan;
  a.itemSpots = plan.map((p) => p.pos);

  // monsters: exactly two per level, spawned far from the players
  const far = cells.filter(([x, y]) => d0[x][y] >= best * 0.45).sort(() => r() - 0.5);
  const pool = far.length >= 2 ? far : cells;
  a.monsterSpawns = [pool[0], pool[Math.min(pool.length - 1, 1 + Math.floor(pool.length / 2))]].map(([x, y]) => ctr(x, y, 1));

  // props for the look: ceiling lights and a few pillars (the client decides how to draw them)
  for (let x = 0; x < w; x++) for (let y = 0; y < h; y++) if ((x + y) % 2 === 0 && r() < 0.8) a.props.push({ k: 'light', pos: [nav.ox + (x + 0.5) * CS, WALL_H - 0.05, nav.oz + (y + 0.5) * CS], flick: r() });
  a.props.push({ k: 'socket', pos: [sc[0], 1.2, sc[2]] }, { k: 'exitdoor', pos: [ec[0], 1.5, ec[2]] });
  return a;
}
