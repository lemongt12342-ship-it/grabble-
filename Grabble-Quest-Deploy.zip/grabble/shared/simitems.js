// Items in the simulation: physics, grabbing, stealing, crafting, power-ups and weapons.
// Grabbing is driven by the grip value in the pose message, not by a separate "grab" message, so a
// client has no way to ask for an item it cannot reach: the server checks reach every time.

import { LOCO, LIMITS } from './constants.js';
import { ITEMS, hasFlag, findRecipe } from './items.js';
import { add, sub, mul, dot, len, dist, copy, clamp, limitLen, addScaled, norm, r3 } from './util.js';
import { handWorld, handVelocity, tryAnchor, head } from './loco.js';
import { deepestHit } from './collide.js';
import * as SH from './simhaz.js';

const fl = (it) => it.def.flags || [];

export function spawnItem(sim, type, pos, o = {}) {
  const def = ITEMS[type];
  if (!def || sim.items.size >= LIMITS.maxItems) return null;
  const it = {
    id: ++sim.nid, type, def, pos: copy(pos), vel: o.vel ? copy(o.vel) : [0, 0, 0], holder: null, state: {},
    age: 0, rest: 0, home: copy(pos), static: !!o.static, lastThrower: null, thrownT: -9, hop: 0,
  };
  if (hasFlag(type, 'hot')) it.state.heat = 0;
  if (hasFlag(type, 'light')) it.on = false;
  if (o.state) Object.assign(it.state, o.state);
  if (o.on !== undefined) it.on = o.on;
  sim.items.set(it.id, it);
  return it;
}

export function removeItem(sim, it) {
  if (!it) return;
  for (const p of sim.players.values()) for (let i = 0; i < 2; i++) if (p.hold[i] === it.id) p.hold[i] = null;
  sim.items.delete(it.id);
}

export function dropAll(sim, p) {
  for (let i = 0; i < 2; i++) {
    releaseHand(sim, p, i, { throw: false, force: true });
    if (p.grabbing[i]) releasePlayerGrab(sim, p, i);
  }
  p.loco.anchor = [null, null];
  if (p.held) {
    const g = sim.players.get(p.held.by);
    if (g && g.grabbing[p.held.hand] === p.id) g.grabbing[p.held.hand] = null;
    p.held = null;
  }
  for (const it of sim.items.values()) if (it.contest && it.contest.pid === p.id) it.contest = null;
}

// ---- gripping ------------------------------------------------------------------------------------
export function handleGrips(sim, p) {
  for (let i = 0; i < 2; i++) {
    const g = p.grip[i], pg = p.prevGrip[i];
    if (p.use[i] && !p.prevUse[i]) useTrigger(sim, p, i);
    if (g >= LOCO.gripOn && pg < LOCO.gripOn) tryGrab(sim, p, i);
    if (p.hold[i]) {
      const it = sim.items.get(p.hold[i]);
      if (!it) { p.hold[i] = null; continue; }
      const off = fl(it).includes('sticky') || (p.gear && p.gear.sticky) ? 0.12 : LOCO.gripOff;
      if (sim.hasFx(p, 'glue')) continue;
      if (g < off) releaseHand(sim, p, i, { throw: true });
      else squeeze(sim, p, i, it, g);
    }
    if (p.grabbing[i] && g < LOCO.gripOff) releasePlayerGrab(sim, p, i);
  }
}

function reachFor(p, i) {
  return 0.18 + 0.12 * (p.handScale[i] || 1) + (p.reach > 1 ? 0.15 : 0);
}

function tryGrab(sim, p, i) {
  if (sim.t < p.noGrip[i]) return;
  if (sim.hasFx(p, 'stun') || sim.hasFx(p, 'hold') || sim.hasFx(p, 'frozen')) return;
  if (sim.env.oneHand && i === 1) return;
  if (p.hold[i]) return;
  const hw = handWorld(p, i);
  const reach = reachFor(p, i);
  let best = null, bd = 1e9;
  for (const it of sim.items.values()) {
    if (it.static && !fl(it).includes('block')) continue;
    const d = dist(hw, it.pos) - it.def.r;
    if (d < reach && d < bd) { best = it; bd = d; }
  }
  if (best) {
    if (best.holder && best.holder.pid !== p.id) {
      if (sim.mode.steal === false || best.holder.pid === p.id) return;
      best.contest = { pid: p.id, hand: i, acc: 0 };
      return;
    }
    if (fl(best).includes('block') && !sim.mode.canPull) return;
    p.hold[i] = best.id;
    best.holder = { pid: p.id, hand: i };
    best.static = false;
    best.state.hands = (p.hold[0] === best.id ? 1 : 0) + (p.hold[1] === best.id ? 1 : 0);
    best.rest = 0;
    sim.emit({ e: 'sfx', k: 'grab', pos: r3(best.pos), id: p.id, hand: i });
    sim.stat(p, 'grabs');
    if (sim.mode.onGrab) sim.mode.onGrab(sim, p, best);
    return;
  }
  // another player (tag, hide and seek, rescues)
  if (sim.mode.grabPlayers) {
    let tgt = null, td = 1e9;
    for (const o of sim.players.values()) {
      if (o === p || !o.alive || o.spec) continue;
      const d = Math.min(dist(hw, head(o)) - 0.18, dist(hw, sim.body(o)) - 0.22);
      if (d < reach + 0.08 && d < td) { tgt = o; td = d; }
    }
    if (tgt && (!sim.mode.canGrab || sim.mode.canGrab(sim, p, tgt)) && !sim.hasFx(tgt, 'immune') && !tgt.held) {
      p.grabbing[i] = tgt.id;
      tgt.held = { by: p.id, hand: i, t: 0 };
      tgt.struggle = 0;
      sim.emit({ e: 'sfx', k: 'grabp', pos: r3(sim.body(tgt)), id: p.id });
      if (sim.mode.onGrabPlayer) sim.mode.onGrabPlayer(sim, p, tgt);
      return;
    }
  }
  tryAnchor(p, i, sim.cols);
}

export function releaseHand(sim, p, i, o = {}) {
  const id = p.hold[i];
  if (!id) return;
  p.hold[i] = null;
  const it = sim.items.get(id);
  if (!it) return;
  if (p.hold[1 - i] === id) { it.state.hands = 1; return; }
  it.holder = null;
  it.lastHolder = p.id;
  it.state.hands = 0;
  it.contest = null;
  if (o.throw) {
    let v = handVelocity(p, i, sim.dt || 1 / 60);
    v = limitLen(mul(v, sim.env.massSwap && sim.env.heavyNow ? 0.6 : 1), 14);
    if (fl(it).includes('sticky') || (p.gear && p.gear.sticky)) v = mul(v, 0.5);
    it.vel = v;
    it.lastThrower = p.id;
    it.thrownT = sim.t;
    sim.emit({ e: 'sfx', k: 'throw', pos: r3(it.pos), id: p.id });
  } else it.vel = copy(p.vel);
  it.rest = 0;
  if (sim.mode.onRelease && !o.force) sim.mode.onRelease(sim, p, it);
}

function squeeze(sim, p, i, it, g) {
  const f = fl(it);
  if (f.includes('fragile') && g > 0.97) return breakItem(sim, it, p);
  if (f.includes('slippery') && g < 0.92 && sim.rng() < 0.025 && !(p.gear && p.gear.sticky)) {
    sim.emit({ e: 'sfx', k: 'slip', pos: r3(it.pos) });
    return releaseHand(sim, p, i, { throw: true });
  }
  if (f.includes('living') && g < 0.8 && sim.rng() < 0.04) return releaseHand(sim, p, i, { throw: true });
}

export function breakItem(sim, it, p) {
  sim.emit({ e: 'sfx', k: 'shatter', pos: r3(it.pos) });
  if (p) sim.stat(p, 'broke');
  if (sim.mode.onBreak) sim.mode.onBreak(sim, it, p);
  removeItem(sim, it);
}

// ---- held items follow the hand --------------------------------------------------------------------
export function stepHeld(sim, dt) {
  const slowed = new Set();
  for (const p of sim.players.values()) {
    for (let i = 0; i < 2; i++) {
      const id = p.hold[i];
      if (!id) continue;
      const it = sim.items.get(id);
      if (!it) { p.hold[i] = null; continue; }
      if (!p.alive) { releaseHand(sim, p, i, { throw: false, force: true }); continue; }
      let pos = handWorld(p, i);
      if (p.hold[0] === id && p.hold[1] === id) pos = mul(add(handWorld(p, 0), handWorld(p, 1)), 0.5);
      it.pos = pos;
      it.vel = handVelocity(p, i, sim.dt || 1 / 60);
      it.holder = { pid: p.id, hand: i };
      if (fl(it).includes('twohand') && it.state.hands < 2) slowed.add(p);
      const mass = it.def.m * (sim.env.massSwap ? (sim.env.heavyNow ? 2.5 : 0.4) : 1);
      if (mass > 3) slowed.add(p);
    }
  }
  for (const p of slowed) sim.setFx(p, 'slow', 0.1);
  // slow-mo bubble owners slow everyone nearby
  for (const p of sim.players.values()) {
    if (!sim.hasFx(p, 'slowmo')) continue;
    for (const o of sim.players.values()) if (o !== p && dist(sim.body(o), sim.body(p)) < 3.5) sim.setFx(o, 'slow', 0.15);
  }
}

// ---- grabbing other players ---------------------------------------------------------------------
export function releasePlayerGrab(sim, p, i) {
  const tid = p.grabbing[i];
  p.grabbing[i] = null;
  const t = sim.players.get(tid);
  if (t && t.held && t.held.by === p.id) { t.held = null; t.struggle = 0; }
}

export function stepPlayerGrabs(sim, dt) {
  for (const p of sim.players.values()) {
    for (let i = 0; i < 2; i++) {
      const tid = p.grabbing[i];
      if (!tid) continue;
      const t = sim.players.get(tid);
      const hw = handWorld(p, i);
      if (!t || !t.alive || !p.alive || p.grip[i] < LOCO.gripOff || dist(hw, sim.body(t)) > 1.7 || sim.hasFx(p, 'stun')) {
        releasePlayerGrab(sim, p, i);
        continue;
      }
      t.held.t += dt;
      sim.setFx(t, 'hold', 0.12);
      t.loco.anchor = [null, null];
      const d = sub(hw, sim.body(t));
      t.root = add(t.root, limitLen(mul(d, Math.min(1, 7 * dt)), 0.22));
      t.vel = mul(p.vel, 0.9);
      // shaking free
      const sv = t.bot ? 3 * sim.rng() : (len(handVelocity(t, 0, dt)) + len(handVelocity(t, 1, dt))) / 2;
      t.struggle = clamp(t.struggle + Math.max(0, sv - 1.8) * dt * 0.28 - dt * 0.1, 0, 1.2);
      if (t.struggle >= 1) {
        releasePlayerGrab(sim, p, i);
        sim.setFx(p, 'stun', 0.9);
        sim.setFx(t, 'immune', 1.6);
        t.struggle = 0;
        sim.emit({ e: 'escape', id: t.id, by: p.id });
        sim.stat(t, 'escapes');
        continue;
      }
      if (sim.mode.onHold) sim.mode.onHold(sim, p, t, t.held ? t.held.t : 0);
    }
  }
}

// ---- stealing a held item (a tug of war) ----------------------------------------------------------
export function stepContests(sim, dt) {
  for (const it of sim.items.values()) {
    const c = it.contest;
    if (!c) continue;
    const ch = sim.players.get(c.pid), ho = it.holder ? sim.players.get(it.holder.pid) : null;
    if (!ch || !ho || !ch.alive || ch.grip[c.hand] < LOCO.gripOff || ch.hold[c.hand] || dist(handWorld(ch, c.hand), it.pos) > it.def.r + 0.55) { it.contest = null; continue; }
    const str = (p, h) => p.stamina * (p.gear ? p.gear.grip : 1) * (1 + Math.min(6, len(handVelocity(p, h, dt))) * 0.15) * (sim.hasFx(p, 'glue') ? 2 : 1);
    c.acc += (str(ch, c.hand) - str(ho, it.holder.hand)) * dt * 2;
    if (c.acc >= 0.5) {
      releaseHand(sim, ho, it.holder.hand, { throw: false, force: true });
      ho.noGrip[0] = ho.noGrip[1] = sim.t + 0.4;
      ch.hold[c.hand] = it.id;
      it.holder = { pid: ch.id, hand: c.hand };
      it.state.hands = 1;
      it.contest = null;
      sim.emit({ e: 'sfx', k: 'steal', pos: r3(it.pos) });
      sim.stat(ch, 'steals');
      if (sim.mode.onGrab) sim.mode.onGrab(sim, ch, it);
    } else if (c.acc <= -0.5) {
      ch.noGrip[c.hand] = sim.t + 0.6;
      it.contest = null;
    }
  }
}

// ---- trigger button ---------------------------------------------------------------------------------
function useTrigger(sim, p, i) {
  if (sim.hasFx(p, 'stun')) return;
  if (p.hold[0] && p.hold[1] && p.use[0] && p.use[1] && p.hold[0] !== p.hold[1] && dist(handWorld(p, 0), handWorld(p, 1)) < 0.35) {
    if (craft(sim, p)) return;
  }
  const id = p.hold[i];
  const it = id && sim.items.get(id);
  if (it) {
    const f = fl(it);
    if (f.includes('light')) { it.on = !it.on; sim.emit({ e: 'sfx', k: 'click', pos: r3(it.pos) }); return; }
    if (f.includes('weapon') && it.def.wp.kind === 'ranged') return fire(sim, p, i, it);
    if (f.includes('prank')) {
      sim.emit({ e: 'confetti', pos: r3(it.pos) });
      for (const o of sim.players.values()) if (o !== p && dist(sim.body(o), it.pos) < 2.5) sim.setFx(o, 'stun', 0.8);
      return removeItem(sim, it);
    }
    return;
  }
  if (p.inv) {
    const type = p.inv;
    p.inv = null;
    usePower(sim, p, type, i);
  }
}

function craft(sim, p) {
  const a = sim.items.get(p.hold[0]), b = sim.items.get(p.hold[1]);
  if (!a || !b) return false;
  const r = findRecipe(a.type, b.type);
  if (!r) return false;
  const pos = mul(add(a.pos, b.pos), 0.5);
  removeItem(sim, a);
  removeItem(sim, b);
  const out = spawnItem(sim, r.out, pos);
  if (out) {
    out.lastThrower = p.id;
    p.hold[0] = out.id;
    out.holder = { pid: p.id, hand: 0 };
    out.state.hands = 1;
  }
  sim.emit({ e: 'craft', pos: r3(pos), out: r.out });
  sim.stat(p, 'crafts');
  return true;
}

function fire(sim, p, i, it) {
  const wp = it.def.wp;
  if (it.state.ammo === undefined) it.state.ammo = wp.ammo;
  if (it.state.ammo <= 0 || sim.t - (it.state.shot || -9) < 0.5) return;
  it.state.shot = sim.t;
  it.state.ammo--;
  const o = handWorld(p, i);
  const dir = norm(sub(o, head(p)));
  SH.shoot(sim, p, o, dir, wp);
}

// ---- power-ups -----------------------------------------------------------------------------------------
function stepPickups(sim) {
  for (const it of sim.items.values()) {
    if (!fl(it).includes('pu') || it.holder) continue;
    for (const p of sim.players.values()) {
      if (!p.alive || p.spec) continue;
      const near = dist(sim.body(p), it.pos) < 0.55 || dist(handWorld(p, 0), it.pos) < 0.28 || dist(handWorld(p, 1), it.pos) < 0.28;
      if (!near) continue;
      const use = fl(it).includes('use');
      if (use && p.inv) continue;
      collect(sim, p, it, use);
      break;
    }
  }
}

function collect(sim, p, it, use) {
  removeItem(sim, it);
  sim.emit({ e: 'sfx', k: 'pickup', pos: r3(it.pos), id: p.id });
  sim.stat(p, 'powerups');
  if (sim.mode.onPickup && sim.mode.onPickup(sim, p, it.type) === false) return;
  if (use) { p.inv = it.type; return; }
  const dur = it.def.pu.dur;
  const map = { pu_arms: 'arms', pu_glue: 'glue', pu_clone: 'clone', pu_slowmo: 'slowmo', pu_boots: 'boost', pu_magnet: 'magnet' };
  if (map[it.type]) sim.setFx(p, map[it.type], dur);
}

function usePower(sim, p, type, hand) {
  const def = ITEMS[type];
  const dur = def.pu.dur;
  const o = handWorld(p, hand), dir = norm(sub(o, head(p)));
  sim.emit({ e: 'sfx', k: 'power', id: p.id, pos: r3(sim.body(p)) });
  if (type === 'pu_dash') {
    const d = norm([dir[0], Math.max(dir[1], 0.15), dir[2]]);
    p.vel = mul(d, 9);
    p.loco.inContact = false;
    p.loco.hist = [];
    sim.setFx(p, 'boost', 0.6);
  } else if (type === 'pu_smoke') {
    const c = sim.body(p);
    sim.addZone({ id: 'smoke' + (++sim.nid), kind: 'smoke', min: [c[0] - 2.2, c[1] - 1.8, c[2] - 2.2], max: [c[0] + 2.2, c[1] + 2.2, c[2] + 2.2], until: sim.t + dur, pub: true });
  } else if (type === 'pu_decoy') {
    SH.spawnEntity(sim, 'decoy', sim.body(p), { owner: p.id, until: sim.t + dur, yaw: p.yaw, hp: 1 });
  } else if (type === 'pu_radar') {
    sim.setFx(p, 'radar', dur);
    sim.emit({ e: 'radar', id: p.id });
  } else if (type === 'pu_ice') {
    const c = [p.root[0] + p.rel.h[0], 0, p.root[2] + p.rel.h[2]];
    const y = sim.lava ? sim.lava.y : Math.min(p.root[1] + 0.2, sim.body(p)[1] - 1.3);
    const col = { min: [c[0] - 1.6, y - 0.3, c[2] - 1.6], max: [c[0] + 1.6, y + 0.15, c[2] + 1.6], on: true, mat: 'ice', c: 'accent', dyn: true, temp: sim.t + dur, id: sim.cols.length };
    sim.cols.push(col);
    sim.emit({ e: 'sfx', k: 'ice', pos: r3(c) });
    sim.setFx(p, 'lavaproof', dur);
  }
}

// ---- weapons held in the hand -----------------------------------------------------------------------------
export function stepWeapons(sim, dt) {
  if (!sim.ents.size) return;
  for (const p of sim.players.values()) {
    for (let i = 0; i < 2; i++) {
      const it = p.hold[i] && sim.items.get(p.hold[i]);
      if (!it || !fl(it).includes('weapon') || it.def.wp.kind !== 'melee') continue;
      const v = len(handVelocity(p, i, dt));
      if (v < 3 || sim.t - (it.state.hit || -9) < 0.45) continue;
      for (const e of sim.ents.values()) {
        if (!SH.hittable(e)) continue;
        if (dist(it.pos, e.pos) < e.r + 0.5) {
          it.state.hit = sim.t;
          SH.damageEntity(sim, e, it.def.wp.dmg * Math.min(1, v / 6), p, it.def.wp.stun);
          sim.emit({ e: 'sfx', k: 'whack', pos: r3(e.pos) });
          break;
        }
      }
    }
  }
}

// ---- free item physics ----------------------------------------------------------------------------------------
export function stepItems(sim, dt) {
  stepPickups(sim);
  const g = sim.env.gravity ?? 9.8;
  const water = sim.env.waterY;
  const magnets = [];
  for (const p of sim.players.values()) if (p.alive && (sim.hasFx(p, 'magnet') || (p.gear && p.gear.magnet))) magnets.push(p);
  const vac = [];
  for (const p of sim.players.values()) if (p.alive && sim.hasFx(p, 'clone')) vac.push(p);

  for (const it of [...sim.items.values()]) {
    const f = fl(it);
    it.age += dt;
    if (it.holder) {
      if (f.includes('hot')) {
        it.state.heat += dt / 4.5;
        if (it.state.heat >= 1) explode(sim, it);
      }
      continue;
    }
    if (f.includes('hot') && it.state.heat > 0) it.state.heat = Math.max(0, it.state.heat - dt * 0.1);
    if (it.static) continue;
    if (it.rest > 30 && !magnets.length && !vac.length && !f.includes('living') && !sim.zones.some((z) => z.kind === 'belt' || z.kind === 'wind')) continue;

    it.vel[1] -= g * (it.def.gScale ?? 1) * dt;
    if (water !== undefined && it.pos[1] < water) {
      it.vel = mul(it.vel, Math.max(0, 1 - 3 * dt));
      it.vel[1] += (f.includes('float') || it.def.gScale < 0 ? 16 : it.state.sink ? -1 : 1.5) * dt;
    }
    SH.zoneForces(sim, it, dt);
    if (f.includes('magnet')) for (const o of sim.items.values()) if (o !== it && !o.holder && fl(o).includes('metal') && dist(o.pos, it.pos) < 1.6) o.vel = addScaled(o.vel, norm(sub(it.pos, o.pos)), 22 * dt);
    if (f.includes('metal')) for (const p of magnets) {
      const hw = handWorld(p, dist(handWorld(p, 0), it.pos) < dist(handWorld(p, 1), it.pos) ? 0 : 1);
      if (dist(hw, it.pos) < 2.6) { it.vel = addScaled(it.vel, norm(sub(hw, it.pos)), 26 * dt); it.rest = 0; }
    }
    for (const p of vac) if (!f.includes('hazard') && dist(sim.body(p), it.pos) < 3.5) { it.vel = addScaled(it.vel, norm(sub(sim.body(p), it.pos)), 18 * dt); it.rest = 0; }
    for (const p of sim.players.values()) if (sim.hasFx(p, 'slowmo') && dist(sim.body(p), it.pos) < 3.5) it.vel = mul(it.vel, 1 - 4 * dt);
    if (f.includes('homing') && sim.t - it.thrownT < 3 && len(it.vel) > 2) {
      const t = sim.nearestPlayer(it.pos, (q) => q.id !== it.lastThrower, 8);
      if (t) { it.vel = addScaled(it.vel, norm(sub(sim.body(t), it.pos)), 20 * dt); it.vel = limitLen(it.vel, 10); }
    }
    if (f.includes('living') && it.rest > 8) { it.hop -= dt; if (it.hop <= 0) { it.hop = 0.8 + sim.rng() * 1.2; it.vel = [(sim.rng() - 0.5) * 3, 2.4, (sim.rng() - 0.5) * 3]; it.rest = 0; } }

    const speed = len(it.vel);
    it.pos = addScaled(it.pos, it.vel, dt);
    let hit = deepestHit(it.pos, it.def.r, sim.cols), grounded = false;
    for (let k = 0; k < 3 && hit; k++) {
      it.pos = addScaled(it.pos, hit.n, hit.depth);
      const vn = dot(it.vel, hit.n);
      if (vn < 0) {
        if (f.includes('fragile') && -vn > 4.5) { breakItem(sim, it, it.lastThrower ? sim.players.get(it.lastThrower) : null); break; }
        const b = (hit.col.mat === 'bouncy' || sim.env.bounceAll ? 1.3 : it.def.b) * (-vn > 0.9 ? 1 : 0);
        it.vel = addScaled(it.vel, hit.n, -vn * (1 + b));
        let fr = (it.def.f ?? 0.4) * 10 * dt;
        if (hit.col.mat === 'ice' || sim.env.iceAll) fr *= 0.08;
        if (f.includes('slippery')) fr *= 0.05;
        if (f.includes('sticky')) fr *= 3;
        const t = 1 - clamp(fr, 0, 0.9);
        it.vel[0] *= t; it.vel[2] *= t;
        if (hit.n[1] > 0.7) grounded = true;
        if (-vn > 2) sim.emit({ e: 'sfx', k: 'thud', pos: r3(it.pos), v: Math.min(1, -vn / 8) });
      }
      hit = deepestHit(it.pos, it.def.r, sim.cols);
    }
    if (!sim.items.has(it.id)) continue;
    it.rest = grounded && len(it.vel) < 0.14 ? it.rest + 1 : 0;
    if (sim.lava && it.pos[1] < sim.lava.y) {
      if (sim.mode.onItemBurn) sim.mode.onItemBurn(sim, it);
      sim.emit({ e: 'sfx', k: 'burn', pos: r3(it.pos) });
      removeItem(sim, it);
      continue;
    }
    const bb = sim.arena.bounds;
    if (it.pos[1] < bb.min[1] - 15 || Math.abs(it.pos[0]) > 80 || Math.abs(it.pos[2]) > 80) {
      if (it.home && !f.includes('hazard')) { it.pos = copy(it.home); it.vel = [0, 0, 0]; } else removeItem(sim, it);
      continue;
    }
    if (speed > 3.5 && !it.holder) hitPlayers(sim, it, speed);
    if (speed > 3.5 && sim.ents.size) SH.itemHitsEntity(sim, it, speed);
  }
}

function hitPlayers(sim, it, speed) {
  for (const p of sim.players.values()) {
    if (!p.alive || p.spec || (it.lastThrower === p.id && sim.t - it.thrownT < 0.4)) continue;
    const r = it.def.r + 0.22;
    if (dist(it.pos, sim.body(p)) < r + 0.1 || dist(it.pos, head(p)) < r) {
      if (sim.mode.onItemHit && sim.mode.onItemHit(sim, it, p, speed) === true) continue;
      if (fl(it).includes('hazard')) sim.knock(p, norm(it.vel), 5, 0.7);
    }
  }
}

function explode(sim, it) {
  const holder = it.holder ? sim.players.get(it.holder.pid) : null;
  sim.emit({ e: 'boom', pos: r3(it.pos) });
  it.state.heat = 0;
  if (sim.mode.onBomb) return sim.mode.onBomb(sim, it, holder);
  if (holder) sim.knock(holder, [0, 1, 0], 5, 1.2);
  removeItem(sim, it);
}
