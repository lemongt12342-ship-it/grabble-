// Gorilla Tag style locomotion.
//
// There is no thumbstick. The rig (your play space) moves only because your hands push against
// surfaces. A hand that touches a surface stays pinned to it, so when you move the hand, the rig moves
// the opposite way. When the last hand leaves a surface you keep the velocity you built up.
//
// This runs identically in the browser (prediction) and on the server (authority).

import { LOCO } from './constants.js';
import { add, addScaled, sub, mul, dot, len, limitLen, copy, clamp, vec, num } from './util.js';
import { deepestHit } from './collide.js';

export function newLoco() {
  return {
    prevRel: [[0, 1, 0], [0, 1, 0]],
    hist: [],
    inContact: false,
    wasAnchored: false,
    anchor: [null, null],
    handHist: [[], []],
    cool: 0,
    touch: [null, null], // collider each hand is touching this tick
    air: 0,
  };
}

export function newPoseState() {
  return {
    rel: { h: [0, 1.6, 0], l: [-0.25, 1.0, 0.3], r: [0.25, 1.0, 0.3] },
    target: { h: [0, 1.6, 0], l: [-0.25, 1.0, 0.3], r: [0.25, 1.0, 0.3], g: [0, 0], u: [0, 0] },
  };
}

// ---- pose input -------------------------------------------------------------------------------
// Poses come from a client (untrusted). Everything is clamped here, so a hacked client cannot report
// an impossible head offset, arm length or grip value.
export function setPoseTarget(p, pose, reach = 1) {
  if (!pose || typeof pose !== 'object') return;
  const hb = LOCO.headBox;
  const h = vec(pose.h, 4, [0, 1.6, 0]);
  h[0] = clamp(h[0], -hb, hb); h[1] = clamp(h[1], 0.2, 2.2); h[2] = clamp(h[2], -hb, hb);
  const hand = (arr, fallback) => {
    let v = vec(arr, 5, fallback);
    v[0] = clamp(v[0], -2.8, 2.8); v[1] = clamp(v[1], -0.6, 2.8); v[2] = clamp(v[2], -2.8, 2.8);
    let d = sub(v, h);
    d = limitLen(d, LOCO.armMax);
    d = mul(d, reach); // stretchy arms power-up, applied after the arm-length clamp
    return add(h, d);
  };
  const l = pose.l, r = pose.r;
  p.target = {
    h,
    l: hand(l, p.rel.l),
    r: hand(r, p.rel.r),
    g: [num(l && l[3], 0, 1, 0), num(r && r[3], 0, 1, 0)],
    u: [num(l && l[4], 0, 1, 0) > 0.5 ? 1 : 0, num(r && r[4], 0, 1, 0) > 0.5 ? 1 : 0],
  };
  if (typeof pose.y === 'number' && Number.isFinite(pose.y)) p.yaw = pose.y % (Math.PI * 2);
}

// Move the simulated pose toward the reported one at a limited speed. Smooths network jitter and caps
// how fast a hand can move (so reporting a hand teleporting cannot generate extra launch speed).
export function approachPose(p, dt) {
  const t = p.target;
  for (const k of ['h', 'l', 'r']) {
    const cap = (k === 'h' ? 8 : LOCO.maxHandSpeed) * dt;
    const d = limitLen(mul(sub(t[k], p.rel[k]), 0.8), cap);
    p.rel[k] = add(p.rel[k], d);
  }
  p.grip = t.g;
  p.use = t.u;
}

// ---- main step --------------------------------------------------------------------------------
function slipOf(col, env) {
  if (env.iceAll || col.mat === 'ice') return LOCO.iceSlip;
  if (col.mat === 'slime') return LOCO.slimeSlip;
  return 0;
}

function pushHist(L, v) {
  L.hist.push(v);
  if (L.hist.length > LOCO.histLen) L.hist.shift();
}
function avgHist(L) {
  if (!L.hist.length) return [0, 0, 0];
  let s = [0, 0, 0];
  for (const v of L.hist) s = add(s, v);
  return mul(s, 1 / L.hist.length);
}

export function stepLoco(p, dt, cols, env = {}) {
  const L = p.loco;
  const g = env.gravity ?? LOCO.gravity;
  const maxSpeed = env.maxSpeed ?? LOCO.maxSpeed;
  const mult = env.velMult ?? LOCO.velMult;
  const handOK = env.handMask || [true, true];
  const handR = [LOCO.handR * (p.handScale ? p.handScale[0] : 1), LOCO.handR * (p.handScale ? p.handScale[1] : 1)];
  const rel = [p.rel.l, p.rel.r];
  const start = copy(p.root);
  if (L.cool > 0) L.cool -= dt;

  // ---- anchors (gripping a grab surface): the hand is pinned, the rig follows ----
  let anchorRoot = null, na = 0;
  for (let i = 0; i < 2; i++) {
    if (!L.anchor[i]) continue;
    if (p.grip[i] < LOCO.gripOff || !handOK[i] || p.stamina <= 0 || env.noAnchor) {
      L.anchor[i] = null;
      if (p.stamina <= 0) L.cool = 1.0;
    } else {
      const d = sub(L.anchor[i], rel[i]);
      anchorRoot = anchorRoot ? add(anchorRoot, d) : d;
      na++;
    }
  }
  if (L.wasAnchored && na === 0) {
    // let go: keep the swing as a fling
    p.vel = limitLen(mul(avgHist(L), 1.15), maxSpeed * 1.3);
    L.hist = [];
    L.inContact = false;
  }
  L.wasAnchored = na > 0;

  if (na > 0) {
    anchorRoot = mul(anchorRoot, 1 / na);
    const step = limitLen(sub(anchorRoot, p.root), LOCO.anchorMaxSpeed * dt);
    p.root = add(p.root, step);
    headPush(p, cols);
    pushHist(L, mul(sub(p.root, start), 1 / dt));
    p.vel = [0, 0, 0];
    p.stamina = Math.max(0, p.stamina - dt * 0.07 * na);
    L.inContact = true;
    L.air = 0;
    L.touch = [null, null];
    recordHands(p, dt);
    return;
  }

  // ---- free movement: gravity, drag, integrate ----
  let drag = env.drag ?? LOCO.airDrag;
  let grav = g;
  if (env.waterY !== undefined && p.root[1] + p.rel.h[1] < env.waterY) {
    drag = env.waterDrag ?? 2.2;
    grav = env.waterGravity ?? 1.2;
  }
  // While a hand is on a surface the hands decide how the rig moves, not inertia. Dropping the carried
  // velocity here also stops sliding from accumulating tick after tick.
  if (L.inContact) p.vel = [0, 0, 0];
  p.vel = [p.vel[0], p.vel[1] - grav * dt, p.vel[2]];
  p.vel = mul(p.vel, Math.max(0, 1 - drag * dt));
  if (p.vel[1] < -22) p.vel[1] = -22;
  p.root = addScaled(p.root, p.vel, dt);

  // ---- hand contact ----
  const hit = [null, null];
  for (let i = 0; i < 2; i++) {
    if (!handOK[i]) continue;
    hit[i] = deepestHit(add(p.root, rel[i]), handR[i] + LOCO.skin, cols);
  }
  let tang = [0, 0, 0], tc = 0;
  for (let i = 0; i < 2; i++) {
    const c = hit[i];
    if (!c) continue;
    let d = mul(sub(rel[i], L.prevRel[i]), env.reverse ? 1 : -1); // rig displacement if the hand stays pinned
    d = sub(d, mul(c.n, dot(d, c.n)));
    tang = add(tang, mul(d, 1 - slipOf(c.col, env)));
    tc++;
  }
  if (tc) p.root = add(p.root, mul(tang, 1 / tc));

  const touching = [false, false];
  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < 2; i++) {
      if (!handOK[i]) continue;
      const c = deepestHit(add(p.root, rel[i]), handR[i] + LOCO.skin, cols);
      if (!c) continue;
      touching[i] = true;
      L.touch[i] = c.col;
      p.root = addScaled(p.root, c.n, c.depth);
      const vn = dot(p.vel, c.n);
      if (vn < 0) p.vel = addScaled(p.vel, c.n, -vn * (c.col.mat === 'bouncy' || env.bounceAll ? 1.7 : 1));
    }
  }
  if (!touching[0]) L.touch[0] = null;
  if (!touching[1]) L.touch[1] = null;

  headPush(p, cols);

  // ---- velocity bookkeeping ----
  const net = mul(sub(p.root, start), 1 / dt);
  const contact = touching[0] || touching[1];
  if (contact) {
    pushHist(L, net);
    p.vel = copy(net);
    L.air = 0;
  } else {
    L.air += dt;
    if (L.inContact) {
      p.vel = mul(avgHist(L), mult);
      L.hist = [];
    }
  }
  L.inContact = contact;
  const sp = len(p.vel);
  if (sp > maxSpeed) p.vel = mul(p.vel, maxSpeed / sp);

  if (contact || L.cool > 0) p.stamina = Math.min(1, p.stamina + dt * 0.35);
  else p.stamina = Math.min(1, p.stamina + dt * 0.2);
  recordHands(p, dt);
}

function headPush(p, cols) {
  const hh = add(p.root, p.rel.h);
  const c = deepestHit(hh, LOCO.headR, cols);
  if (!c) return;
  p.root = addScaled(p.root, c.n, c.depth);
  const vn = dot(p.vel, c.n);
  if (vn < 0) p.vel = addScaled(p.vel, c.n, -vn);
  if (c.n[1] > 0.6) { p.vel[0] *= 0.85; p.vel[2] *= 0.85; }
}

function recordHands(p, dt) {
  const L = p.loco;
  for (let i = 0; i < 2; i++) {
    const hw = add(p.root, i ? p.rel.r : p.rel.l);
    L.handHist[i].push(hw);
    if (L.handHist[i].length > 5) L.handHist[i].shift();
    L.prevRel[i] = copy(i ? p.rel.r : p.rel.l);
  }
}

export function handWorld(p, i) {
  return add(p.root, i ? p.rel.r : p.rel.l);
}

// World velocity of a hand over the last few ticks. Used for throwing, so a client cannot choose it.
export function handVelocity(p, i, dt) {
  const h = p.loco.handHist[i];
  if (h.length < 2) return [0, 0, 0];
  return mul(sub(h[h.length - 1], h[0]), 1 / ((h.length - 1) * dt));
}

// Try to grab a surface with hand i. Returns true if the hand is now anchored.
export function tryAnchor(p, i, cols) {
  const L = p.loco;
  if (L.cool > 0 || p.stamina <= 0.05) return false;
  const hw = handWorld(p, i);
  const c = deepestHit(hw, LOCO.handR * (p.handScale ? p.handScale[i] : 1) + 0.07, cols);
  if (!c || !c.col.grab) return false;
  L.anchor[i] = hw;
  return true;
}

export function head(p) {
  return add(p.root, p.rel.h);
}
