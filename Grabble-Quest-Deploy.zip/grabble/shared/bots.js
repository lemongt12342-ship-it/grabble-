// Simple bot brain. Bots move kinematically (not through the arm-swing loco) so they can fill rooms
// and play every mode without needing a controller. A mode can steer them with mode.bot(sim, p, dt),
// which returns { goal: [x,y,z], speed }. If a mode gives no hint, bots wander and pick up items.

import { add, sub, mul, norm, dist, distXZ, len, clamp, copy } from './util.js';
import { groundAt } from './collide.js';

export function stepBot(sim, p, dt) {
  const ai = p.ai;
  p.use = [0, 0];
  p.grip = [0, 0];
  if (!p.alive || sim.phase === 'countdown' || sim.hasFx(p, 'stun') || sim.hasFx(p, 'frozen')) { p.vel = [0, 0, 0]; return; }
  ai.t -= dt;
  let hint = sim.mode.bot ? sim.mode.bot(sim, p, dt) : null;
  if (!hint && ai.t <= 0) {
    ai.t = 1.5 + sim.rng() * 2.5;
    const spots = sim.arena.itemSpots;
    ai.goal = spots.length ? copy(spots[sim.rng.int(spots.length)]) : [sim.rng.range(-8, 8), 0, sim.rng.range(-8, 8)];
  }
  const goal = hint ? hint.goal : ai.goal;
  let speed = (hint && hint.speed) || 3.4;
  if (sim.hasFx(p, 'slow')) speed *= 0.5;
  if (sim.hasFx(p, 'boost')) speed *= 1.5;
  if (goal) {
    const d = sub(goal, add(p.root, p.rel.h));
    d[1] = 0;
    if (len(d) > 0.4) {
      const dir = norm(d);
      p.root = [p.root[0] + dir[0] * speed * dt, p.root[1], p.root[2] + dir[2] * speed * dt];
      p.yaw = Math.atan2(dir[2], dir[0]);
    }
  }
  // gravity and ground snap (hands rest about 0.92 below the rig origin)
  p.vel[1] -= (sim.env.gravity ?? 9.8) * dt;
  p.root[1] += p.vel[1] * dt;
  const hx = p.root[0] + p.rel.h[0], hz = p.root[2] + p.rel.h[2];
  const gy = groundAt(hx, hz, p.root[1] + 1.3, sim.cols);
  if (gy > -Infinity && p.root[1] <= gy - 0.92) { p.root[1] = gy - 0.92; p.vel[1] = 0; }
  // clamp inside the arena
  const b = sim.arena.bounds;
  p.root[0] = clamp(p.root[0], b.min[0] + 1, b.max[0] - 1);
  p.root[2] = clamp(p.root[2], b.min[2] + 1, b.max[2] - 1);
  // grab a nearby item now and then so bots score and carry things
  for (const it of sim.items.values()) {
    if (it.holder || it.static) continue;
    if (dist(add(p.root, p.rel.l), it.pos) < 0.7 && !p.hold[0] && sim.rng() < 0.05) {
      p.hold[0] = it.id;
      it.holder = { pid: p.id, hand: 0 };
      it.state.hands = 1;
      break;
    }
  }
  if (p.hold[0] && sim.rng() < 0.012) {
    const it = sim.items.get(p.hold[0]);
    if (it) { it.holder = null; it.vel = [sim.rng.range(-4, 4), 2.5, sim.rng.range(-4, 4)]; it.lastThrower = p.id; it.thrownT = sim.t; }
    p.hold[0] = null;
  }
  if (p.alive && p.root[1] < sim.arena.bounds.min[1] - 6) sim.fell(p);
}
