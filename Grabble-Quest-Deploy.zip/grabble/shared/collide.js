import { clamp } from './util.js';

// Collider: { min:[x,y,z], max:[x,y,z], on:true, mat:'stone'|'ice'|'slime'|'bouncy'|'wood'|'carpet',
//             grab:false, dyn:false, crumble:false }
// Axis aligned boxes only. Everything in Grabble's world is built from them.

export function sphereVsBox(c, r, b) {
  const cx = clamp(c[0], b.min[0], b.max[0]);
  const cy = clamp(c[1], b.min[1], b.max[1]);
  const cz = clamp(c[2], b.min[2], b.max[2]);
  const dx = c[0] - cx, dy = c[1] - cy, dz = c[2] - cz;
  const d2 = dx * dx + dy * dy + dz * dz;
  if (d2 > r * r) return null;
  if (d2 > 1e-10) {
    const d = Math.sqrt(d2);
    return { n: [dx / d, dy / d, dz / d], depth: r - d };
  }
  // centre is inside the box: leave through the nearest face
  const faces = [
    [c[0] - b.min[0], [-1, 0, 0]], [b.max[0] - c[0], [1, 0, 0]],
    [c[1] - b.min[1], [0, -1, 0]], [b.max[1] - c[1], [0, 1, 0]],
    [c[2] - b.min[2], [0, 0, -1]], [b.max[2] - c[2], [0, 0, 1]],
  ];
  let best = Infinity, n = [0, 1, 0];
  for (const [d, nn] of faces) if (d < best) { best = d; n = nn; }
  return { n, depth: best + r };
}

// Deepest overlap of a sphere against all active colliders, or null.
export function deepestHit(c, r, cols) {
  let best = null;
  for (let i = 0; i < cols.length; i++) {
    const b = cols[i];
    if (b.on === false) continue;
    const h = sphereVsBox(c, r, b);
    if (h && (!best || h.depth > best.depth)) { best = h; best.col = b; }
  }
  return best;
}

export function anyHit(c, r, cols) {
  for (let i = 0; i < cols.length; i++) {
    const b = cols[i];
    if (b.on === false) continue;
    if (sphereVsBox(c, r, b)) return b;
  }
  return null;
}

// Ray against one box (slab method). Returns distance t in [0, maxT] or -1.
export function rayBox(o, d, b, maxT) {
  let t0 = 0, t1 = maxT;
  for (let a = 0; a < 3; a++) {
    if (Math.abs(d[a]) < 1e-9) {
      if (o[a] < b.min[a] || o[a] > b.max[a]) return -1;
    } else {
      let ta = (b.min[a] - o[a]) / d[a], tb = (b.max[a] - o[a]) / d[a];
      if (ta > tb) { const t = ta; ta = tb; tb = t; }
      if (ta > t0) t0 = ta;
      if (tb < t1) t1 = tb;
      if (t0 > t1) return -1;
    }
  }
  return t0;
}

export function raycast(o, dir, maxT, cols) {
  let best = -1, hit = null;
  for (let i = 0; i < cols.length; i++) {
    const b = cols[i];
    if (b.on === false) continue;
    const t = rayBox(o, dir, b, best < 0 ? maxT : best);
    if (t >= 0 && (best < 0 || t < best)) { best = t; hit = b; }
  }
  return best < 0 ? null : { t: best, col: hit };
}

export function lineOfSight(a, b, cols) {
  const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const l = Math.hypot(d[0], d[1], d[2]);
  if (l < 1e-6) return true;
  const u = [d[0] / l, d[1] / l, d[2] / l];
  for (let i = 0; i < cols.length; i++) {
    const c = cols[i];
    if (c.on === false || c.see === false) continue;
    const t = rayBox(a, u, c, l);
    if (t >= 0 && t < l - 0.01) return false;
  }
  return true;
}

// Highest solid surface at or below y at (x, z). Returns -Infinity if none.
export function groundAt(x, z, y, cols) {
  let best = -Infinity;
  for (let i = 0; i < cols.length; i++) {
    const b = cols[i];
    if (b.on === false) continue;
    if (x >= b.min[0] && x <= b.max[0] && z >= b.min[2] && z <= b.max[2] && b.max[1] <= y + 0.01 && b.max[1] > best) best = b.max[1];
  }
  return best;
}

export function pointInBox(p, b) {
  return p[0] >= b.min[0] && p[0] <= b.max[0] && p[1] >= b.min[1] && p[1] <= b.max[1] && p[2] >= b.min[2] && p[2] <= b.max[2];
}

export function box(min, max, extra = {}) {
  return { min, max, on: true, mat: 'stone', ...extra };
}
// Convenience: a box from centre and size.
export function boxC(cx, cy, cz, sx, sy, sz, extra = {}) {
  return box([cx - sx / 2, cy - sy / 2, cz - sz / 2], [cx + sx / 2, cy + sy / 2, cz + sz / 2], extra);
}
