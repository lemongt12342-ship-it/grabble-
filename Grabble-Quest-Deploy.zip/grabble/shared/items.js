// Item catalog. Everything you can pick up, throw, craft, wear into battle or collect.
// r = radius (m), m = mass (kg), b = bounce, f = friction, rar = rarity, flags = special behaviours.

export const RARITY = {
  common: { pts: 1, w: 70, color: '#cfd8dc' },
  rare: { pts: 3, w: 25, color: '#4dabf7' },
  golden: { pts: 10, w: 5, color: '#ffd43b' },
};

export const ITEMS = {
  // toys and physics props
  ball: { name: 'Ball', r: 0.11, m: 0.3, b: 0.75, rar: 'common', col: '#ff6b6b' },
  brick: { name: 'Brick', r: 0.1, m: 1.2, b: 0.1, rar: 'common', col: '#c2703d' },
  duck: { name: 'Rubber duck', r: 0.1, m: 0.15, b: 0.5, rar: 'common', col: '#ffd43b', flags: ['float'] },
  anvil: { name: 'Anvil', r: 0.14, m: 4, b: 0.02, rar: 'common', col: '#495057', flags: ['heavy', 'metal'] },
  egg: { name: 'Egg', r: 0.07, m: 0.1, b: 0.1, rar: 'rare', col: '#fff3bf', flags: ['fragile'] },
  glass: { name: 'Glass orb', r: 0.1, m: 0.2, b: 0.2, rar: 'rare', col: '#a5d8ff', flags: ['fragile'] },
  honey: { name: 'Honey jar', r: 0.1, m: 0.5, b: 0.05, rar: 'common', col: '#f59f00', flags: ['sticky'] },
  soap: { name: 'Soap bar', r: 0.09, m: 0.15, b: 0.1, f: 0.0, rar: 'common', col: '#99e9f2', flags: ['slippery'] },
  octopus: { name: 'Octopus', r: 0.12, m: 0.4, b: 0.3, rar: 'rare', col: '#e64980', flags: ['living'] },
  cat: { name: 'Grumpy cat', r: 0.13, m: 0.6, b: 0.2, rar: 'rare', col: '#adb5bd', flags: ['living'] },
  fish: { name: 'Slippery fish', r: 0.1, m: 0.3, b: 0.2, rar: 'common', col: '#3bc9db', flags: ['living', 'slippery'] },
  balloon: { name: 'Balloon', r: 0.15, m: 0.02, b: 0.8, rar: 'common', col: '#f783ac', gScale: -0.12 },
  magnet: { name: 'Magnet', r: 0.09, m: 0.5, b: 0.1, rar: 'rare', col: '#e03131', flags: ['magnet'] },
  metalball: { name: 'Steel ball', r: 0.09, m: 1.5, b: 0.4, rar: 'common', col: '#868e96', flags: ['metal'] },
  homing: { name: 'Magnet ball', r: 0.1, m: 1.2, b: 0.5, rar: 'rare', col: '#e8590c', flags: ['metal', 'homing'] },
  bomb: { name: 'Hot bomb', r: 0.12, m: 0.8, b: 0.3, rar: 'common', col: '#212529', flags: ['hot'] },
  potato: { name: 'Hot potato', r: 0.11, m: 0.4, b: 0.2, rar: 'common', col: '#d9a066', flags: ['hot'] },
  confetti: { name: 'Prank box', r: 0.1, m: 0.2, b: 0.2, rar: 'common', col: '#da77f2', flags: ['prank'] },
  // loot
  coin: { name: 'Coin', r: 0.06, m: 0.1, b: 0.4, rar: 'common', col: '#ffd43b', flags: ['loot'] },
  gem: { name: 'Gem', r: 0.07, m: 0.2, b: 0.2, rar: 'rare', col: '#22b8cf', flags: ['loot'] },
  goldbar: { name: 'Gold bar', r: 0.1, m: 2, b: 0.05, rar: 'golden', col: '#fab005', flags: ['loot', 'metal'] },
  relic: { name: 'Relic', r: 0.12, m: 1, b: 0.1, rar: 'golden', col: '#f1c40f', flags: ['loot'] },
  trophy: { name: 'Trophy', r: 0.12, m: 1, b: 0.1, rar: 'golden', col: '#ffd43b', flags: ['loot'] },
  fakegem: { name: 'Shiny gem', r: 0.07, m: 0.2, b: 0.2, rar: 'golden', col: '#22b8cf', flags: ['decoy'] },
  // team and game objects
  dodgeball: { name: 'Dodgeball', r: 0.13, m: 0.25, b: 0.8, rar: 'common', col: '#fa5252', flags: ['dodge'] },
  flag: { name: 'Flag', r: 0.14, m: 1, b: 0.0, rar: 'common', col: '#ffffff', flags: ['twohand'] },
  orb: { name: 'Hill orb', r: 0.14, m: 0.8, b: 0.3, rar: 'golden', col: '#74c0fc', flags: ['orb'] },
  block: { name: 'Block', r: 0.2, m: 1, b: 0.0, rar: 'common', col: '#d0a370', flags: ['block'] },
  crate: { name: 'Crate', r: 0.16, m: 1, b: 0.1, rar: 'common', col: '#a9774a' },
  rock: { name: 'Falling rock', r: 0.22, m: 6, b: 0.1, rar: 'common', col: '#6c757d', flags: ['hazard'] },
  // kitchen
  bun: { name: 'Bun', r: 0.1, m: 0.1, b: 0.1, rar: 'common', col: '#e6b17e', flags: ['food'] },
  patty: { name: 'Patty', r: 0.09, m: 0.1, b: 0.1, rar: 'common', col: '#7b4a2d', flags: ['food'] },
  lettuce: { name: 'Lettuce', r: 0.09, m: 0.05, b: 0.1, rar: 'common', col: '#69db7c', flags: ['food'] },
  tomato: { name: 'Tomato', r: 0.08, m: 0.08, b: 0.2, rar: 'common', col: '#e03131', flags: ['food'] },
  cheese: { name: 'Cheese', r: 0.08, m: 0.08, b: 0.1, rar: 'common', col: '#fcc419', flags: ['food'] },
  rice: { name: 'Rice bowl', r: 0.1, m: 0.2, b: 0.1, rar: 'common', col: '#f8f9fa', flags: ['food'] },
  fishfillet: { name: 'Fish', r: 0.09, m: 0.1, b: 0.1, rar: 'common', col: '#ffa8a8', flags: ['food'] },
  burger: { name: 'Burger', r: 0.12, m: 0.3, b: 0.1, rar: 'rare', col: '#e8590c', flags: ['food', 'dish'] },
  sushi: { name: 'Sushi', r: 0.1, m: 0.2, b: 0.1, rar: 'rare', col: '#ff8787', flags: ['food', 'dish'] },
  // weapons: never given, only found. dmg = damage on a solid hit, kind = how it is used.
  bat: { name: 'Bat', r: 0.12, m: 1.1, b: 0.1, rar: 'rare', col: '#a9774a', flags: ['weapon'], wp: { kind: 'melee', dmg: 40, stun: 2.5 } },
  pipe: { name: 'Pipe', r: 0.11, m: 1.5, b: 0.1, rar: 'rare', col: '#868e96', flags: ['weapon', 'metal'], wp: { kind: 'melee', dmg: 55, stun: 3 } },
  baton: { name: 'Stun baton', r: 0.11, m: 0.7, b: 0.1, rar: 'golden', col: '#4dabf7', flags: ['weapon'], wp: { kind: 'melee', dmg: 25, stun: 6 } },
  flaregun: { name: 'Flare gun', r: 0.1, m: 0.5, b: 0.1, rar: 'golden', col: '#ff6b6b', flags: ['weapon'], wp: { kind: 'ranged', dmg: 30, stun: 4, ammo: 3 } },
  slingshot: { name: 'Slingshot', r: 0.1, m: 0.3, b: 0.1, rar: 'rare', col: '#c2703d', flags: ['weapon'], wp: { kind: 'ranged', dmg: 20, stun: 1.5, ammo: 8 } },
  // backrooms puzzle items
  fuse: { name: 'Fuse', r: 0.06, m: 0.1, b: 0.1, rar: 'common', col: '#fab005', flags: ['puzzle'] },
  keycard: { name: 'Keycard', r: 0.06, m: 0.05, b: 0.1, rar: 'common', col: '#4dabf7', flags: ['puzzle'] },
  battery: { name: 'Battery', r: 0.06, m: 0.15, b: 0.1, rar: 'common', col: '#69db7c', flags: ['puzzle'] },
  flashlight: { name: 'Flashlight', r: 0.08, m: 0.3, b: 0.1, rar: 'common', col: '#ffe066', flags: ['light'] },
  glowstick: { name: 'Glowstick', r: 0.06, m: 0.05, b: 0.2, rar: 'common', col: '#a9e34b', flags: ['light'] },
  note: { name: 'Found note', r: 0.06, m: 0.01, b: 0.0, rar: 'common', col: '#fff9db', flags: ['note'] },
  // power-ups. timed ones trigger on pickup, "use" ones trigger with the trigger button.
  pu_arms: { name: 'Long arms', r: 0.1, m: 0.05, b: 0.3, rar: 'rare', col: '#ffa94d', flags: ['pu'], pu: { dur: 10 } },
  pu_glue: { name: 'Super glue', r: 0.1, m: 0.05, b: 0.3, rar: 'rare', col: '#e9ecef', flags: ['pu'], pu: { dur: 8 } },
  pu_clone: { name: 'Clone hands', r: 0.1, m: 0.05, b: 0.3, rar: 'rare', col: '#da77f2', flags: ['pu'], pu: { dur: 8 } },
  pu_slowmo: { name: 'Slow-mo bubble', r: 0.1, m: 0.05, b: 0.3, rar: 'rare', col: '#74c0fc', flags: ['pu'], pu: { dur: 7 } },
  pu_boots: { name: 'Speed boots', r: 0.1, m: 0.05, b: 0.3, rar: 'common', col: '#ffd43b', flags: ['pu'], pu: { dur: 7 } },
  pu_smoke: { name: 'Smoke bomb', r: 0.1, m: 0.05, b: 0.3, rar: 'common', col: '#adb5bd', flags: ['pu', 'use'], pu: { dur: 5 } },
  pu_decoy: { name: 'Decoy clone', r: 0.1, m: 0.05, b: 0.3, rar: 'common', col: '#f783ac', flags: ['pu', 'use'], pu: { dur: 8 } },
  pu_dash: { name: 'Dash', r: 0.1, m: 0.05, b: 0.3, rar: 'common', col: '#ff8787', flags: ['pu', 'use'], pu: { dur: 0 } },
  pu_radar: { name: 'Radar pulse', r: 0.1, m: 0.05, b: 0.3, rar: 'rare', col: '#63e6be', flags: ['pu', 'use'], pu: { dur: 4 } },
  pu_ice: { name: 'Ice crystal', r: 0.1, m: 0.05, b: 0.3, rar: 'rare', col: '#a5d8ff', flags: ['pu', 'use'], pu: { dur: 5 } },
  pu_magnet: { name: 'Magnet glove', r: 0.1, m: 0.05, b: 0.3, rar: 'rare', col: '#e03131', flags: ['pu'], pu: { dur: 10 } },
};

export const ITEM_IDS = Object.keys(ITEMS);
export const hasFlag = (type, f) => !!(ITEMS[type] && ITEMS[type].flags && ITEMS[type].flags.includes(f));

// Crafting: hold one item in each hand, bring the hands together and squeeze both triggers.
export const RECIPES = [
  { a: 'magnet', b: 'metalball', out: 'homing' },
  { a: 'bun', b: 'patty', out: 'burger' },
  { a: 'rice', b: 'fishfillet', out: 'sushi' },
  { a: 'battery', b: 'flashlight', out: 'flashlight', note: 'recharge' },
  { a: 'brick', b: 'brick', out: 'anvil' },
  { a: 'duck', b: 'balloon', out: 'balloon' },
  { a: 'glass', b: 'honey', out: 'confetti' },
  { a: 'coin', b: 'coin', out: 'goldbar' },
];

export function findRecipe(a, b) {
  return RECIPES.find((r) => (r.a === a && r.b === b) || (r.a === b && r.b === a)) || null;
}

// Pools used by modes to scatter items.
export const POOLS = {
  toys: ['ball', 'brick', 'duck', 'egg', 'glass', 'honey', 'soap', 'octopus', 'cat', 'fish', 'balloon', 'magnet', 'metalball', 'confetti', 'anvil'],
  loot: ['coin', 'coin', 'coin', 'gem', 'gem', 'goldbar', 'relic'],
  chaser: ['pu_dash', 'pu_radar', 'pu_arms'],
  runner: ['pu_boots', 'pu_smoke', 'pu_decoy'],
  general: ['pu_arms', 'pu_glue', 'pu_clone', 'pu_slowmo', 'pu_magnet'],
  found_weapons: ['bat', 'pipe', 'baton', 'flaregun', 'slingshot'],
  kitchen: ['bun', 'patty', 'lettuce', 'tomato', 'cheese', 'rice', 'fishfillet'],
};

export const ORDERS = [
  { id: 'burger', need: ['bun', 'patty', 'lettuce'], pts: 6 },
  { id: 'cheeseburger', need: ['bun', 'patty', 'cheese'], pts: 7 },
  { id: 'salad', need: ['lettuce', 'tomato', 'cheese'], pts: 5 },
  { id: 'sushi', need: ['rice', 'fishfillet'], pts: 5 },
  { id: 'deluxe', need: ['bun', 'patty', 'lettuce', 'tomato'], pts: 9 },
];

// Gloves change how your hands behave. Cosmetic skins live in progression.js.
export const GLOVES = {
  none: { name: 'Bare hands', reach: 1, scale: 1, grip: 1 },
  sticky: { name: 'Sticky gloves', reach: 1, scale: 1.1, grip: 1.6, sticky: true },
  magnetic: { name: 'Magnetic gloves', reach: 1, scale: 1.1, grip: 1, magnet: true },
  giant: { name: 'Giant gloves', reach: 1.1, scale: 1.9, grip: 1.2 },
  spring: { name: 'Spring gloves', reach: 1.5, scale: 1, grip: 0.9 },
};
