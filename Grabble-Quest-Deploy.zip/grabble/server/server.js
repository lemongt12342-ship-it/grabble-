// Grabble server: static files + WebSocket multiplayer on one port. No dependencies.
//
//   PORT=8080 HOST=0.0.0.0 node server/server.js
//   TLS_KEY=key.pem TLS_CERT=cert.pem   serve https/wss (needed for WebXR on a headset over the network)
//   ALLOWED_ORIGINS=play.example.com    extra origins allowed to open a WebSocket
//   TRUST_PROXY=1                       read the client IP from X-Forwarded-For (only behind your own proxy)

import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { upgrade } from './ws.js';
import { Bucket, originAllowed, clientIp, headers, safeResolve, MIME } from './security.js';
import { Hub, CODE_RE, sanitizeCreate } from './rooms.js';
import { cleanName } from '../shared/util.js';
import { LIMITS, VERSION } from '../shared/constants.js';
import { COSMETIC_KEYS } from '../shared/sim.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(here, '..');
const ALLOWED_EXT = new Set(Object.keys(MIME));

const rid = () => crypto.randomBytes(6).toString('hex');

export function createServer(cfg = {}) {
  const port = cfg.port ?? Number(process.env.PORT || 8080);
  const host = cfg.host ?? process.env.HOST ?? '127.0.0.1';
  const tls = cfg.tls ?? (process.env.TLS_KEY && process.env.TLS_CERT ? { key: fs.readFileSync(process.env.TLS_KEY), cert: fs.readFileSync(process.env.TLS_CERT) } : null);
  const allow = (cfg.allowedOrigins ?? (process.env.ALLOWED_ORIGINS || '').split(',')).map((s) => s.trim().toLowerCase()).filter(Boolean);
  const trustProxy = cfg.trustProxy ?? process.env.TRUST_PROXY === '1';
  const allowNoOrigin = cfg.allowNoOrigin ?? process.env.ALLOW_NO_ORIGIN === '1';
  const maxPerIp = cfg.maxPerIp ?? 8;
  const hub = new Hub(cfg.hub);
  const perIp = new Map(); // ip -> { n, bucket }

  // ---- static files ---------------------------------------------------------------------------
  function serveStatic(req, res) {
    const h = headers(req.headers.host, !!tls);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { ...h, Allow: 'GET, HEAD' }); return res.end(); }
    const url = req.url || '/';
    if (url === '/healthz') { res.writeHead(200, { ...h, 'Content-Type': 'text/plain' }); return res.end('ok'); }
    let p = url.split('?')[0];
    if (p === '/') p = '/index.html';
    // two served roots: public/ at the top, shared/ read-only for the browser game code
    let file = null;
    if (p.startsWith('/shared/')) file = safeResolve(path.join(ROOT, 'shared'), p.slice('/shared'.length));
    else file = safeResolve(path.join(ROOT, 'public'), p);
    const ext = file ? path.extname(file).toLowerCase() : '';
    if (!file || !ALLOWED_EXT.has(ext)) { res.writeHead(404, { ...h, 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    fs.stat(file, (err, st) => {
      if (err || !st.isFile()) { res.writeHead(404, { ...h, 'Content-Type': 'text/plain' }); return res.end('Not found'); }
      const etag = `"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"`;
      const base = { ...h, 'Content-Type': MIME[ext], ETag: etag, 'Cache-Control': 'no-cache' };
      if (req.headers['if-none-match'] === etag) { res.writeHead(304, base); return res.end(); }
      res.writeHead(200, { ...base, 'Content-Length': st.size });
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
    });
  }

  const handler = (req, res) => { try { serveStatic(req, res); } catch { res.writeHead(500); res.end(); } };
  const server = tls ? https.createServer(tls, handler) : http.createServer(handler);
  server.headersTimeout = 15_000;
  server.requestTimeout = 20_000;
  server.maxHeadersCount = 40;

  // ---- websocket -----------------------------------------------------------------------------------
  server.on('upgrade', (req, socket) => {
    socket.on('error', () => {});
    const ip = clientIp(req, trustProxy);
    if (!(req.url || '').startsWith('/ws')) { socket.write('HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n'); return socket.destroy(); }
    if (!originAllowed(req, allow, allowNoOrigin)) { socket.write('HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n'); return socket.destroy(); }
    let rec = perIp.get(ip);
    if (!rec) { rec = { n: 0, bucket: new Bucket(cfg.connPerSec ?? 0.5, cfg.connBurst ?? 10) }; perIp.set(ip, rec); }
    if (rec.n >= maxPerIp || !rec.bucket.take()) { socket.write('HTTP/1.1 429 Too Many Requests\r\nContent-Length: 0\r\n\r\n'); return socket.destroy(); }
    const conn = upgrade(req, socket, { maxPayload: LIMITS.msgBytes });
    if (!conn) return;
    rec.n++;
    const c = {
      id: rid(), conn, ip, name: 'Player', cos: {}, room: null, hello: false,
      msgs: new Bucket(200, 300), poses: new Bucket(LIMITS.poseHz, 40), creates: new Bucket(0.2, 3), strikes: 0, joined: Date.now(),
    };
    const send = (o) => conn.send(JSON.stringify(o));
    const err = (code, msg) => send({ t: 'err', code, msg });
    const strike = (why) => { if (++c.strikes >= 8) conn.close(1008, 'too many bad messages'); else err('bad', why); };

    conn.on('message', (text) => {
      if (!c.msgs.take()) return conn.close(1008, 'rate limit');
      let m;
      try { m = JSON.parse(text); } catch { return strike('bad json'); }
      if (!m || typeof m !== 'object' || Array.isArray(m) || typeof m.t !== 'string') return strike('bad message');
      switch (m.t) {
        case 'ping': return send({ t: 'pong', n: typeof m.n === 'number' ? m.n : 0 });
        case 'hello': {
          if (c.hello) return strike('already said hello');
          c.hello = true;
          c.name = cleanName(m.name, 'Player');
          c.cos = {};
          if (m.cos && typeof m.cos === 'object') for (const k of COSMETIC_KEYS) if (typeof m.cos[k] === 'string' && m.cos[k].length < 25) c.cos[k] = m.cos[k];
          return send({ t: 'welcome', id: c.id, v: VERSION, name: c.name });
        }
      }
      if (!c.hello) return strike('say hello first');
      switch (m.t) {
        case 'pose': {
          if (!c.room || !c.poses.take()) return;
          return c.room.sim.setPose(c.id, m.p, m.q);
        }
        case 'act': {
          if (!c.room) return;
          if (m.a && m.a.a === 'name') { c.name = cleanName(m.a.name, c.name); }
          if (m.a && m.a.a === 'cos' && m.a.cos) for (const k of COSMETIC_KEYS) if (typeof m.a.cos[k] === 'string' && m.a.cos[k].length < 25) c.cos[k] = m.a.cos[k];
          c.room.sim.action(c.id, m.a);
          if (m.a && (m.a.a === 'ready' || m.a.a === 'name' || m.a.a === 'cos')) c.room.broadcast(c.room.info());
          return;
        }
        case 'create': {
          if (c.room) return err('state', 'leave your room first');
          const o = sanitizeCreate(m);
          if (typeof o === 'string') return err('bad', o);
          if (!c.creates.take()) return err('rate', 'slow down');
          const r = hub.create(c, o);
          if (r.err) return err('full', r.err);
          return r.room.broadcast(r.room.info());
        }
        case 'join': {
          if (c.room) return err('state', 'leave your room first');
          const code = typeof m.code === 'string' ? m.code.trim().toUpperCase() : '';
          if (!CODE_RE.test(code)) return err('bad', 'room codes are 5 letters or numbers');
          if (!c.creates.take()) return err('rate', 'slow down');
          const r = hub.join(c, code);
          if (r.err) return err('join', r.err);
          return r.room.broadcast(r.room.info());
        }
        case 'leave': {
          const r = c.room;
          if (r) { r.remove(c); r.broadcast(r.info()); }
          return send({ t: 'left', id: c.id, self: true });
        }
        case 'start': {
          if (!c.room || c.room.host !== c.id) return err('perm', 'only the host can start');
          if (!c.room.start()) return err('state', 'already started');
          return;
        }
        case 'kick': {
          const r = c.room;
          if (!r || r.host !== c.id || typeof m.id !== 'string') return err('perm', 'only the host can kick');
          const t = r.clients.get(m.id);
          if (t && t !== c) { r.remove(t); t.conn.send(JSON.stringify({ t: 'kicked' })); r.broadcast(r.info()); }
          return;
        }
        default: return strike('unknown message type');
      }
    });

    const hb = setInterval(() => {
      if (!conn.alive) return conn.close(1001, 'timeout');
      conn.alive = false;
      conn.ping();
    }, 20_000);
    hb.unref();
    conn.on('close', () => {
      clearInterval(hb);
      rec.n = Math.max(0, rec.n - 1);
      if (c.room) { const r = c.room; r.remove(c); r.broadcast(r.info()); }
    });
  });

  // forget idle per-IP records
  const sweep = setInterval(() => { for (const [ip, r] of perIp) if (!r.n && r.bucket.tokens >= r.bucket.burst - 0.5) perIp.delete(ip); }, 60_000);
  sweep.unref();

  return {
    server, hub,
    listen: () => new Promise((resolve) => server.listen(port, host, () => resolve(server.address()))),
    close: () => new Promise((resolve) => { hub.stop(); clearInterval(sweep); server.closeAllConnections?.(); server.close(() => resolve()); }),
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const app = createServer();
  app.listen().then((a) => {
    const scheme = process.env.TLS_KEY ? 'https' : 'http';
    console.log(`Grabble listening on ${scheme}://${a.address === '::' ? '0.0.0.0' : a.address}:${a.port}`);
    if (a.address === '127.0.0.1') console.log('Bound to localhost only. Set HOST=0.0.0.0 to accept connections from other devices.');
  });
  const stop = () => app.close().then(() => process.exit(0));
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}
