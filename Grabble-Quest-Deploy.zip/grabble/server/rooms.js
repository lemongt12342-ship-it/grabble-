// Rooms and the hub. A Room owns one Sim. Clients only ever send poses and button states; the Sim
// decides everything else, so there is nothing for a modified client to "win" by lying.

import crypto from 'node:crypto';
import { Sim } from '../shared/sim.js';
import { MODES } from '../shared/modes/index.js';
import { MODIFIER_IDS } from '../shared/modifiers.js';
import { ARENA_KINDS, THEME_IDS } from '../shared/arenas.js';
import { DT, LIMITS } from '../shared/constants.js';
import { todaySeed } from '../shared/util.js';

const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I so codes are easy to read aloud
export const CODE_RE = /^[A-HJ-NP-Z2-9]{5}$/;
const DIFFS = ['chill', 'normal', 'hard'];

export function randomCode() {
  const b = crypto.randomBytes(LIMITS.roomCodeLen);
  let s = '';
  for (let i = 0; i < LIMITS.roomCodeLen; i++) s += CODE_ALPHABET[b[i] % CODE_ALPHABET.length];
  return s;
}
const rid = () => crypto.randomBytes(6).toString('hex');

// Turn untrusted create options into a safe options object, or an error string.
export function sanitizeCreate(m) {
  const mode = typeof m.mode === 'string' ? m.mode : 'sandbox';
  if (!Object.prototype.hasOwnProperty.call(MODES, mode)) return 'unknown mode';
  const o = { mode };
  const diff = typeof m.difficulty === 'string' && DIFFS.includes(m.difficulty) ? m.difficulty : 'normal';
  o.difficulty = diff;
  if (Number.isInteger(m.level) && m.level >= 1 && m.level <= 9) o.level = m.level;
  const mods = Array.isArray(m.mods) ? m.mods.filter((x) => typeof x === 'string' && MODIFIER_IDS.includes(x)) : [];
  o.mods = [...new Set(mods)].slice(0, 2);
  o.kidSafe = m.kid === true;
  o.priv = m.priv === true;
  o.bots = Number.isInteger(m.bots) ? Math.max(0, Math.min(6, m.bots)) : 0;
  o.daily = m.daily === true;
  o.seed = o.daily ? todaySeed() : crypto.randomBytes(4).readUInt32BE(0);
  if (typeof m.arena === 'string' && ARENA_KINDS.includes(m.arena) && mode !== 'backrooms') o.arenaKind = m.arena;
  if (typeof m.theme === 'string' && THEME_IDS.includes(m.theme)) o.theme = m.theme;
  return o;
}

export class Room {
  constructor(code, opts, hub) {
    this.code = code;
    this.opts = opts;
    this.hub = hub;
    this.sim = new Sim(opts);
    this.clients = new Map(); // id -> client
    this.host = null;
    this.created = Date.now();
    this.lastActive = Date.now();
    this.acc = 0;
    this.last = performance.now();
    this.n = 0;
    this.overAt = 0;
    this.board = null;
  }

  get humans() { return this.clients.size; }
  get full() { return this.clients.size >= LIMITS.maxPlayers; }

  add(c) {
    const p = this.sim.addPlayer(c.id, { name: c.name, cos: c.cos });
    if (!p) return false;
    this.clients.set(c.id, c);
    c.room = this;
    if (!this.host) this.host = c.id;
    this.lastActive = Date.now();
    this.broadcast({ t: 'joined', id: c.id, name: p.name });
    return true;
  }

  remove(c) {
    if (!this.clients.delete(c.id)) return;
    this.sim.removePlayer(c.id);
    c.room = null;
    if (this.host === c.id) this.host = this.clients.keys().next().value || null;
    this.broadcast({ t: 'left', id: c.id });
    this.lastActive = Date.now();
  }

  info() {
    return {
      t: 'room', code: this.code, host: this.host, ...this.sim.info(), phase: this.sim.phase, priv: !!this.opts.priv,
      players: [...this.sim.players.values()].map((p) => ({ id: p.id, name: p.name, bot: p.bot, ready: p.ready, team: p.team, cos: p.cos })),
    };
  }

  broadcast(obj, droppable = false) {
    const s = JSON.stringify(obj);
    for (const c of this.clients.values()) c.conn.send(s, droppable);
  }

  start() {
    const want = this.opts.bots || 0;
    if (want) this.sim.fillBots(Math.min(LIMITS.maxPlayers, this.clients.size + want));
    const ok = this.sim.start();
    this.broadcast(this.info());
    return ok;
  }

  step(now) {
    this.acc += Math.min(0.1, (now - this.last) / 1000);
    this.last = now;
    let steps = 0;
    while (this.acc >= DT && steps < 6) {
      this.sim.dt = DT;
      this.sim.tick(DT);
      this.acc -= DT;
      steps++;
      this.n++;
      if (this.n % 3 === 0) this.sendSnap();
    }
    if (this.sim.phase === 'over' && !this.overAt) this.overAt = Date.now();
    // a finished match returns to the lobby after a short pause
    if (this.overAt && Date.now() - this.overAt > 12_000) this.reset();
  }

  sendSnap() {
    const snap = this.sim.snapshot();
    snap.t = 'snap';
    const ev = this.sim.drainEvents();
    if (ev.length) snap.ev = ev;
    this.broadcast(snap, true);
  }

  reset() {
    const humans = [...this.clients.values()];
    for (const c of humans) this.sim.removePlayer(c.id);
    for (const p of [...this.sim.players.values()]) this.sim.removePlayer(p.id);
    const o = { ...this.opts, seed: this.opts.daily ? todaySeed() : crypto.randomBytes(4).readUInt32BE(0) };
    this.sim = new Sim(o);
    this.overAt = 0;
    for (const c of humans) this.sim.addPlayer(c.id, { name: c.name, cos: c.cos });
    this.broadcast(this.info());
  }
}

export class Hub {
  constructor(cfg = {}) {
    this.rooms = new Map();
    this.maxRooms = cfg.maxRooms || 200;
    this.perIpRooms = cfg.perIpRooms || 3;
    this.timer = setInterval(() => this.loop(), 8);
    this.timer.unref();
    this.cleaner = setInterval(() => this.clean(), 15_000);
    this.cleaner.unref();
  }

  loop() {
    const now = performance.now();
    for (const r of this.rooms.values()) if (r.clients.size) r.step(now);
  }

  clean() {
    const now = Date.now();
    for (const [code, r] of this.rooms) if (!r.clients.size && now - r.lastActive > 30_000) this.rooms.delete(code);
  }

  create(c, opts) {
    if (this.rooms.size >= this.maxRooms) return { err: 'server is full' };
    const mine = [...this.rooms.values()].filter((r) => r.owner === c.ip && r.clients.size > 0).length;
    if (mine >= this.perIpRooms) return { err: 'too many rooms from your address' };
    let code;
    do code = randomCode(); while (this.rooms.has(code));
    const r = new Room(code, opts, this);
    r.owner = c.ip;
    this.rooms.set(code, r);
    if (!r.add(c)) return { err: 'could not join' };
    return { room: r };
  }

  join(c, code) {
    const r = this.rooms.get(code);
    if (!r) return { err: 'no such room' };
    if (r.full) return { err: 'room is full' };
    if (!r.add(c)) return { err: 'could not join' };
    return { room: r };
  }

  stop() { clearInterval(this.timer); clearInterval(this.cleaner); }
}
