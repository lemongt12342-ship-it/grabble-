// Security helpers: rate limiting, origin checks, response headers, safe path resolution.

import path from 'node:path';

// Token bucket. take() returns false when the caller is over its rate.
export class Bucket {
  constructor(perSec, burst) { this.rate = perSec; this.burst = burst; this.tokens = burst; this.t = Date.now(); }
  take(n = 1, now = Date.now()) {
    this.tokens = Math.min(this.burst, this.tokens + ((now - this.t) / 1000) * this.rate);
    this.t = now;
    if (this.tokens < n) return false;
    this.tokens -= n;
    return true;
  }
}

const HOST_RE = /^[a-z0-9.\-]+(:\d{1,5})?$|^\[[0-9a-f:]+\](:\d{1,5})?$/i;
export const safeHost = (h) => (typeof h === 'string' && h.length < 256 && HOST_RE.test(h) ? h : 'localhost');

// WebSocket origin check. Browsers always send Origin. An attacker's page on another site cannot
// forge it, so a mismatch means a cross-site WebSocket hijack attempt.
export function originAllowed(req, allowList, allowNoOrigin) {
  const o = req.headers.origin;
  if (!o) return !!allowNoOrigin;
  let u;
  try { u = new URL(o); } catch { return false; }
  const host = u.host.toLowerCase();
  if (host === String(req.headers.host || '').toLowerCase()) return true;
  return allowList.includes(host) || allowList.includes(u.origin.toLowerCase());
}

export function clientIp(req, trustProxy) {
  if (trustProxy) {
    const x = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (x && x.length < 64) return x;
  }
  return req.socket.remoteAddress || 'unknown';
}

export function headers(host, tls, extra = {}) {
  const h = safeHost(host);
  const csp = [
    "default-src 'self'",
    "script-src 'self' https://cdn.jsdelivr.net",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "media-src 'self' blob: data:",
    "font-src 'self'",
    `connect-src 'self' ws://${h} wss://${h} https://cdn.jsdelivr.net`,
    "worker-src 'self' blob:",
    "object-src 'none'",
    "base-uri 'none'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ].join('; ');
  const out = {
    'Content-Security-Policy': csp,
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'X-Frame-Options': 'DENY',
    'Cross-Origin-Opener-Policy': 'same-origin',
    'Cross-Origin-Resource-Policy': 'same-origin',
    'Permissions-Policy': 'xr-spatial-tracking=(self), microphone=(self), camera=(), geolocation=(), payment=(), usb=()',
    ...extra,
  };
  if (tls) out['Strict-Transport-Security'] = 'max-age=31536000';
  return out;
}

// Resolve a request path inside root. Returns null for anything that could escape it.
export function safeResolve(root, urlPath) {
  let p;
  try { p = decodeURIComponent(urlPath.split('?')[0].split('#')[0]); } catch { return null; }
  if (p.includes('\0') || p.includes('\\') || p.length > 300) return null;
  const parts = p.split('/').filter(Boolean);
  if (parts.some((s) => s === '..' || s.startsWith('.'))) return null;
  const full = path.join(root, ...parts);
  const rel = path.relative(root, full);
  if (rel.startsWith('..') || path.isAbsolute(rel)) return null;
  return full;
}

export const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.jpg': 'image/jpeg', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav',
};
