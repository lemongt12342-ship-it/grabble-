// A small, strict WebSocket (RFC 6455) server layer with no dependencies.
//
// Strictness is the point. It rejects anything a browser would never send:
//   unmasked client frames, fragmented messages, reserved bits, binary frames, oversized payloads,
//   control frames longer than 125 bytes, and text that is not valid UTF-8.

import crypto from 'node:crypto';
import { EventEmitter } from 'node:events';

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const DEC = new TextDecoder('utf-8', { fatal: true });

export class WSConn extends EventEmitter {
  constructor(socket, { maxPayload = 4096 } = {}) {
    super();
    this.socket = socket;
    this.max = maxPayload;
    this.buf = Buffer.alloc(0);
    this.closed = false;
    this.alive = true;
    socket.setNoDelay(true);
    socket.setTimeout(75_000);
    socket.on('timeout', () => this.fail(1001));
    socket.on('data', (d) => this.onData(d));
    // Node's http server keeps sockets half-open after the peer sends FIN. Without this a closed
    // tab would never be noticed and the player would stay in their room.
    socket.on('end', () => this.end());
    socket.on('error', () => this.end());
    socket.on('close', () => this.end());
  }

  end() {
    if (this.closed) return;
    this.closed = true;
    this.socket.destroy();
    this.emit('close');
  }

  fail(code) {
    if (this.closed) return;
    this.close(code);
  }

  frame(op, payload) {
    const n = payload.length;
    let head;
    if (n < 126) head = Buffer.from([0x80 | op, n]);
    else if (n < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | op; head[1] = 126; head.writeUInt16BE(n, 2); }
    else { head = Buffer.alloc(10); head[0] = 0x80 | op; head[1] = 127; head.writeUInt32BE(0, 2); head.writeUInt32BE(n, 6); }
    return Buffer.concat([head, payload]);
  }

  // Returns false when the message was dropped because the client is not keeping up.
  send(str, droppable = false) {
    if (this.closed) return false;
    if (droppable && this.socket.writableLength > 256 * 1024) return false;
    if (this.socket.writableLength > 2 * 1024 * 1024) { this.fail(1013); return false; }
    this.socket.write(this.frame(0x1, Buffer.from(str, 'utf8')));
    return true;
  }

  ping() { if (!this.closed) this.socket.write(this.frame(0x9, Buffer.alloc(0))); }

  close(code = 1000, reason = '') {
    if (this.closed) return;
    const r = Buffer.from(String(reason).slice(0, 100), 'utf8');
    const p = Buffer.alloc(2 + r.length);
    p.writeUInt16BE(code, 0);
    r.copy(p, 2);
    try { this.socket.write(this.frame(0x8, p)); } catch { /* socket already gone */ }
    this.closed = true;
    setTimeout(() => this.socket.destroy(), 200).unref();
    this.emit('close');
  }

  onData(chunk) {
    if (this.closed) return;
    this.buf = this.buf.length ? Buffer.concat([this.buf, chunk]) : chunk;
    while (!this.closed && this.buf.length >= 2) {
      const b0 = this.buf[0], b1 = this.buf[1];
      const fin = (b0 & 0x80) !== 0, rsv = b0 & 0x70, op = b0 & 0x0f, masked = (b1 & 0x80) !== 0;
      let len = b1 & 0x7f, off = 2;
      if (rsv || !masked || !fin) return this.fail(1002);
      if (len === 126) {
        if (this.buf.length < 4) break;
        len = this.buf.readUInt16BE(2); off = 4;
      } else if (len === 127) {
        if (this.buf.length < 10) break;
        if (this.buf.readUInt32BE(2) !== 0) return this.fail(1009);
        len = this.buf.readUInt32BE(6); off = 10;
      }
      if (op >= 0x8 && len > 125) return this.fail(1002);
      if (len > this.max) return this.fail(1009);
      if (this.buf.length < off + 4 + len) break;
      const mask = this.buf.subarray(off, off + 4);
      const payload = Buffer.allocUnsafe(len);
      for (let i = 0; i < len; i++) payload[i] = this.buf[off + 4 + i] ^ mask[i & 3];
      this.buf = this.buf.subarray(off + 4 + len);
      if (op === 0x1) {
        let text;
        try { text = DEC.decode(payload); } catch { return this.fail(1007); }
        this.emit('message', text);
      } else if (op === 0x8) {
        return this.close(1000);
      } else if (op === 0x9) {
        if (!this.closed) this.socket.write(this.frame(0xa, payload));
      } else if (op === 0xa) {
        this.alive = true;
      } else {
        return this.fail(1003); // binary, continuation and unknown opcodes are not accepted
      }
    }
    // what is left is at most one incomplete frame, which can never legitimately exceed this
    if (!this.closed && this.buf.length > this.max + 20) this.fail(1009);
  }
}

// Performs the handshake. Returns a WSConn, or null after answering with an HTTP error.
export function upgrade(req, socket, opts = {}) {
  const reject = (code, msg) => {
    socket.write(`HTTP/1.1 ${code} ${msg}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
    socket.destroy();
    return null;
  };
  if (req.method !== 'GET') return reject(405, 'Method Not Allowed');
  const up = String(req.headers.upgrade || '').toLowerCase();
  const conn = String(req.headers.connection || '').toLowerCase();
  const key = req.headers['sec-websocket-key'];
  if (up !== 'websocket' || !conn.includes('upgrade')) return reject(400, 'Bad Request');
  if (req.headers['sec-websocket-version'] !== '13') return reject(426, 'Upgrade Required');
  if (typeof key !== 'string' || key.length !== 24 || Buffer.from(key, 'base64').length !== 16) return reject(400, 'Bad Request');
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
  return new WSConn(socket, opts);
}
