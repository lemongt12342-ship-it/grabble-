// The one place that decides where Three.js comes from.
//
// Default: a pinned version from jsDelivr, which the server's Content-Security-Policy allows.
// To self-host instead (recommended for a public release):
//   npm install three@0.160.0
//   copy node_modules/three/build/three.module.js to public/vendor/three.module.js
//   then change the line below to:  export * from '../vendor/three.module.js';
export * from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
