// Grabble client entry point: wires the renderer, the headset (or keyboard and mouse), the game session,
// the world, the HUD, sound and the spawn computer together.

import * as THREE from './three.js';
import { World } from './world.js';
import { buildAvatar } from './avatar.js';
import { Input } from './input.js';
import { Hud } from './hud.js';
import { hudModel } from './hudmodel.js';
import { Terminal, W as TW, H as TH } from './terminal.js';
import { Audio } from './audio.js';
import { loadProfile, saveProfile, sanitizeCos } from './store.js';
import { LocalSession, NetSession, infoSig } from './session.js';

const $ = (id) => document.getElementById(id);
// show any crash on screen so it can be reported
function showErr(t) { const n = $('vr-note'); if (n) { n.style.color = '#ff8a8a'; n.textContent = 'Error: ' + t; } }
addEventListener('error', (e) => showErr(`${e.message} (${(e.filename || '').split('/').pop()}:${e.lineno})`));
addEventListener('unhandledrejection', (e) => showErr(String(e.reason && e.reason.message || e.reason)));
const profile = loadProfile();
const audio = new Audio();
audio.vol = profile.settings.volume;

// ---------------------------------------------------------------------------------------------------
// renderer, scene, rig
const app = $('app');
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.xr.enabled = true;
renderer.xr.setReferenceSpaceType('local-floor');
try { renderer.xr.setFoveation(0.6); } catch { /* not supported on this device */ }
app.appendChild(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.05, 220);
const rig = new THREE.Group();
rig.add(camera);
scene.add(rig);
addEventListener('resize', () => { renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); });

const world = new World(scene);
const input = new Input(renderer, camera, rig, renderer.domElement);
const hud = new Hud(camera);
if (input.touchError) showErr('touch controls: ' + input.touchError);

// a small crosshair for on-screen play
const cross = document.createElement('div');
cross.style.cssText = 'position:fixed;left:50%;top:50%;width:8px;height:8px;margin:-4px;border-radius:50%;background:#fff9;pointer-events:none;z-index:4';
document.body.appendChild(cross);

// ---------------------------------------------------------------------------------------------------
// your own avatar: only the arms and hands are shown, so the camera never sits inside a head
let me = null;
function buildMe() {
  if (me) { scene.remove(me.root); me.dispose(); }
  me = buildAvatar(profile.cos);
  me.head.visible = false;
  me.torso.visible = false;
  scene.add(me.root);
}
buildMe();

// ---------------------------------------------------------------------------------------------------
// the computer: one screen drawn on a canvas, shown on the plaza desk and as a floating panel
const screenCanvas = document.createElement('canvas');
screenCanvas.width = TW; screenCanvas.height = TH;
const term = new Terminal({ profile, connected: location.protocol.startsWith('http'), onAction: onTerminal });
term.attach(screenCanvas);
const screenTex = new THREE.CanvasTexture(screenCanvas);
screenTex.colorSpace = THREE.SRGBColorSpace;
screenTex.anisotropy = 4;
term.texture = screenTex;
const screenMat = new THREE.MeshBasicMaterial({ map: screenTex, toneMapped: false });
const panel = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.0), screenMat);
panel.visible = false;
scene.add(panel);
let deskScreen = null;
const dot = new THREE.Mesh(new THREE.SphereGeometry(0.012, 8, 6), new THREE.MeshBasicMaterial({ color: '#ffffff', depthTest: false }));
dot.renderOrder = 1000;
dot.visible = false;
scene.add(dot);

function openPanel(on) {
  panel.visible = on;
  input.uiMode = on;
  if (on) {
    const f = new THREE.Vector3(); camera.getWorldDirection(f); f.y = 0; f.normalize();
    const p = new THREE.Vector3(); camera.getWorldPosition(p);
    panel.position.set(p.x + f.x * 1.1, Math.max(0.9, p.y - 0.1), p.z + f.z * 1.1);
    panel.lookAt(p.x, panel.position.y, p.z); // a plane's front is +z, so lookAt turns it to face the player
    if (document.pointerLockElement) document.exitPointerLock();
  }
  audio.sfx('ui');
}

// ---------------------------------------------------------------------------------------------------
// sessions
let sess = null;
let net = null;
let loadedSig = '';
let backTimer = 0;

function setSession(s) {
  sess = s;
  loadedSig = '';
  backTimer = 0;
}
function goHub() { setSession(new LocalSession({ mode: 'hub', name: profile.name, cos: profile.cos })); term.setRoom(null); term.go('home'); }

function wsUrl() { return `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`; }

async function ensureNet() {
  if (net && !net.closed) return net;
  net = new NetSession({ url: wsUrl(), name: profile.name, cos: profile.cos });
  net.on('room', (r) => {
    sess = net;
    loadedSig = '';
    term.setRoom({ code: r.code, host: net.host, hostId: r.host, players: r.players, mode: r.mode, phase: r.phase });
    term.go('lobby');
    closePanelSoon();
  });
  net.on('error', (m) => { term.setMessage(m.msg); audio.sfx('no'); });
  net.on('left', () => { if (sess === net) goHub(); });
  net.on('kicked', () => { hud.toast('You were removed from the room'); goHub(); });
  net.on('close', () => { if (sess === net) { hud.toast('Lost connection to the server'); goHub(); } });
  await net.opened;
  return net;
}

let closeAt = 0;
function closePanelSoon() { closeAt = performance.now() + 900; }

async function onTerminal(a) {
  audio.sfx('click');
  try {
    if (a.a === 'solo') {
      const { a: _a, bots, ...opts } = a;
      setSession(new LocalSession({ mode: a.mode, opts, name: profile.name, cos: profile.cos, bots }));
      term.setRoom(null);
      openPanel(false);
    } else if (a.a === 'create') {
      term.setMessage('Creating...');
      const n = await ensureNet();
      const { a: _a, ...opts } = a;
      n.create(opts);
    } else if (a.a === 'join') {
      const n = await ensureNet();
      n.join(a.code);
    } else if (a.a === 'leave') {
      if (sess === net && net) net.leave(); else goHub();
    } else if (a.a === 'start') {
      if (sess === net && net) net.start();
    } else if (a.a === 'ready') {
      if (sess === net && net) { const cur = net.roster.get(net.id); net.act({ a: 'ready', v: !(cur && cur.ready) }); }
    } else if (a.a === 'cos') {
      profile.cos = sanitizeCos(a.cos);
      saveProfile(profile);
      buildMe();
      if (sess) sess.act({ a: 'cos', cos: profile.cos });
      if (net && net !== sess) net.act({ a: 'cos', cos: profile.cos });
    } else if (a.a === 'name') {
      saveProfile(profile);
      if (sess) sess.act({ a: 'name', name: profile.name });
    } else if (a.a === 'settings') {
      saveProfile(profile);
      audio.setVolume(profile.settings.volume);
    }
  } catch (e) {
    term.setMessage(e && e.message ? e.message : 'Something went wrong');
  }
}

// ---------------------------------------------------------------------------------------------------
// start screen
const overlay = $('overlay');
const vrBtn = $('enter-vr');
const note = $('vr-note');
let started = false;

function begin() {
  if (started) return;
  started = true;
  audio.start();
  overlay.classList.add('hidden');
  goHub();
  renderer.setAnimationLoop(frame);
}

$('play-desktop').addEventListener('click', () => { begin(); });

(async () => {
  const xr = navigator.xr;
  const framed = window.top !== window.self;
  const diag = `[secure:${window.isSecureContext ? 'yes' : 'NO'} framed:${framed ? 'YES' : 'no'} webxr:${xr ? 'yes' : 'NO'}]`;
  let supported = false;
  if (xr) { try { supported = await xr.isSessionSupported('immersive-vr'); } catch { supported = false; } }
  vrBtn.disabled = false;
  vrBtn.textContent = supported ? 'Enter VR' : 'Try Enter VR anyway';
  note.textContent = supported ? '' : `VR check failed ${diag}. ${framed ? 'This page is inside a frame, which blocks VR: open the link directly. ' : ''}${!window.isSecureContext ? 'VR needs https. ' : ''}`;
  vrBtn.addEventListener('click', async () => {
    if (!xr) { note.textContent = `This browser has no WebXR ${diag}. Use the Meta Quest Browser.`; return; }
    try {
      const s = await xr.requestSession('immersive-vr', { optionalFeatures: ['local-floor', 'bounded-floor', 'hand-tracking'] });
      s.addEventListener('end', () => { input.setVR(false); overlay.classList.remove('hidden'); cross.style.display = ''; });
      await renderer.xr.setSession(s);
      input.setVR(true);
      cross.style.display = 'none';
      begin();
      overlay.classList.add('hidden');
    } catch (e) { note.textContent = `Could not start VR ${diag}: ${e && e.name ? e.name + ': ' : ''}${e && e.message ? e.message : e}`; }
  });
})();

// ---------------------------------------------------------------------------------------------------
// per-frame
const raycaster = new THREE.Raycaster();
const tmpV = new THREE.Vector3();
let prevPressed = false;

function uiRay(ray) {
  const targets = [];
  if (panel.visible) targets.push(panel);
  if (deskScreen) targets.push(deskScreen);
  if (!targets.length) { dot.visible = false; return; }
  if (ray.o) raycaster.set(ray.o, ray.d); // VR ray is already in world space
  else raycaster.setFromCamera({ x: ray.cursor ? ray.cursor[0] : 0, y: ray.cursor ? ray.cursor[1] : 0 }, camera);
  raycaster.far = deskScreen && !panel.visible ? 6 : 4;
  const hit = raycaster.intersectObjects(targets, false)[0];
  if (!hit || !hit.uv) { dot.visible = false; return; }
  dot.visible = true;
  dot.position.copy(hit.point);
  term.hover(hit.uv.x, 1 - hit.uv.y);
  if (ray.pressed) { term.clickUV(hit.uv.x, 1 - hit.uv.y); audio.sfx('ui'); }
}

addEventListener('keydown', (e) => {
  if (!started || !(panel.visible || term.screen === 'join' || term.screen === 'name')) return;
  if (!panel.visible) return;
  if (e.key.length === 1 || e.key === 'Backspace' || e.key === 'Enter') { term.key(e.key); }
  if (e.key === 'Escape') openPanel(false);
});

let last = performance.now();
function frame(now) {
  const dt = Math.min(0.1, Math.max(0.001, (now - last) / 1000));
  last = now;
  if (!sess) return;

  if (input.consumeEdge('menu')) openPanel(!panel.visible);
  if (closeAt && now > closeAt) { closeAt = 0; openPanel(false); }
  const polled = input.poll(dt, profile.settings);
  const pose = polled.pose;

  const out = sess.update(dt, pose);
  if (!out) { renderer.render(scene, camera); return; }
  const { snap, events, me: pl } = out;

  // (re)build the world when the arena or level changes
  const info = sess.info;
  const sig = infoSig(info);
  if (sig !== loadedSig && info) {
    world.load(info);
    loadedSig = sig;
    if (deskScreen) { scene.remove(deskScreen); deskScreen = null; }
    if (world.arena && world.arena.terminal) {
      const t = world.arena.terminal;
      deskScreen = new THREE.Mesh(new THREE.PlaneGeometry(t.size[0], t.size[1]), screenMat);
      deskScreen.position.set(t.pos[0] + t.normal[0] * 0.07, t.pos[1] + t.normal[1] * 0.07, t.pos[2] + t.normal[2] * 0.07);
      scene.add(deskScreen);
    }
    const amb = info.mode === 'backrooms' ? 'backrooms' : info.mode === 'lava' || info.mode === 'lavatag' ? 'lava' : info.theme === 'night' ? 'night' : 'default';
    audio.setAmbient(amb);
  }

  // the rig sits at the predicted body position; tracked poses are offsets from it
  const root = pl.root;
  rig.position.set(root[0], root[1], root[2]);
  rig.updateMatrixWorld(true);
  const wp = (r) => [root[0] + r[0], root[1] + r[1], root[2] + r[2]];
  const head = wp(pose.h), lh = wp(pose.l), rh = wp(pose.r);
  me.update(head, lh, rh, pose.y);

  // items that are in your hands follow your hands immediately
  const mine = snap.pl.find((p) => p.i === sess.id);
  const held = new Map();
  if (mine && mine.hd) { if (mine.hd[0]) held.set(mine.hd[0], lh); if (mine.hd[1]) held.set(mine.hd[1], rh); }

  world.roster = sess.roster;
  world.update(snap, dt, head, held);
  world.updatePlayers(snap, sess.id, dt, profile.settings.names);

  // events: sound, effects and short messages
  for (const ev of events) handleEvent(ev, snap);

  // audio listener and monster danger
  audio.setListener(head, pose.y);
  if (snap.en && snap.en.length) {
    let d = 99;
    for (const e of snap.en) if (e.s !== 'dead') d = Math.min(d, Math.hypot(e.p[0] - root[0], e.p[2] - root[2]));
    audio.setDanger(1 - Math.min(1, d / 18));
  }

  // computer screen: close it when it is far away, redraw when needed
  if (term.dirty) term.draw();
  uiRay(polled.ray);
  const rt = input.consumeEdge('ready');
  if (rt && sess === net && net) onTerminal({ a: 'ready' });

  hud.update(dt, hudModel(snap, sess.id, info, sess.roster), Math.hypot(...(pl.vel || [0, 0, 0])), profile.settings.vignette);

  // solo matches return to the plaza a few seconds after they end
  if (sess.kind === 'local' && snap.ph === 'over') { backTimer += dt; if (backTimer > 8) goHub(); }

  renderer.render(scene, camera);
}

function nameOf(id) { const r = sess && sess.roster.get(id); return r ? r.name : 'Someone'; }

function handleEvent(ev, snap) {
  world.event(ev);
  switch (ev.e) {
    case 'sfx': audio.sfx(ev.k, ev.pos, ev.v); break;
    case 'boom': audio.sfx('boom', ev.pos); break;
    case 'craft': audio.sfx('ok', ev.pos); hud.toast('Crafted!'); break;
    case 'confetti': audio.sfx('win'); break;
    case 'level': audio.sfx('descend'); hud.toast(`Level ${ev.n}: ${ev.name}`, 4); break;
    case 'msg': hud.toast(ev.text); break;
    case 'tag': hud.toast(`${nameOf(ev.by)} tagged ${nameOf(ev.id)}`); audio.sfx('bonk'); break;
    case 'it': hud.toast(`${nameOf(ev.id)} is it`); break;
    case 'freeze': hud.toast(`${nameOf(ev.id)} was frozen`); audio.sfx('ice'); break;
    case 'unfreeze': hud.toast(`${nameOf(ev.id)} is free`); break;
    case 'elim': hud.toast(`${nameOf(ev.id)} is out`); break;
    case 'escape': if (ev.by === 'monster') hud.toast(`${nameOf(ev.id)} escaped the monster`); break;
    case 'monster': if (ev.k === 'spot') audio.sfx('no'); break;
    case 'socket': hud.toast(`Part placed: ${ev.have}/${ev.need}`); audio.sfx('ok'); break;
    case 'capture': hud.toast('Flag captured!'); audio.sfx('win'); break;
    case 'join': hud.toast(`${ev.name} joined`); break;
    case 'leave': hud.toast(`${nameOf(ev.id)} left`); break;
    case 'end': {
      const won = ev.res && !ev.res.lost && ev.res.winners && ev.res.winners.includes(sess.id);
      hud.toast(won ? 'You win!' : 'Round over', 5);
      audio.sfx(won ? 'win' : 'lose');
      break;
    }
    default: break;
  }
}
