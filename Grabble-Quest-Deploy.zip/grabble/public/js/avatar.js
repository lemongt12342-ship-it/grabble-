// Grabble's own player avatar: a chunky, low-poly knuckle-walker, designed for this game.
// Big mitt hands, long arms, a swept-back crest, a visor-style face with its own markings, and no tail.
// Colours come from the player's customisation (set at the spawn computer).
//
// The avatar is driven by the tracked pose: the head follows the headset, and each arm is a stretched
// capsule from the shoulder to the hand, so it always reaches wherever your controller is.

import * as THREE from './three.js';

const flat = (hex, rough = 0.85) => new THREE.MeshStandardMaterial({ color: new THREE.Color(hex), roughness: rough, metalness: 0.0, flatShading: true });
const glow = (hex) => new THREE.MeshBasicMaterial({ color: new THREE.Color(hex) });
const HEX = /^#[0-9a-fA-F]{6}$/;
const col = (v, d) => (typeof v === 'string' && HEX.test(v) ? v : d);

import { DEFAULT_COS } from '../../shared/cosmetics.js';
export { DEFAULT_COS };

export function buildAvatar(cos = {}) {
  const root = new THREE.Group();
  const m = {
    fur: flat(col(cos.fur, DEFAULT_COS.fur)),
    dark: flat('#241f4d'),
    face: flat(col(cos.accent, DEFAULT_COS.accent), 0.9),
    pad: flat(col(cos.pad, DEFAULT_COS.pad), 0.6),
    eye: glow(col(cos.eyes, DEFAULT_COS.eyes)),
    black: glow('#111018'),
  };

  // ---- head: a slightly squashed low-poly ball with a cream visor-shaped face ----
  const head = new THREE.Group();
  const skull = new THREE.Mesh(new THREE.IcosahedronGeometry(0.19, 1), m.fur);
  skull.scale.set(1, 0.92, 1.02);
  head.add(skull);
  const face = new THREE.Mesh(new THREE.IcosahedronGeometry(0.15, 1), m.face);
  face.scale.set(1.0, 0.72, 0.5);
  face.position.set(0, -0.02, 0.13);
  head.add(face);
  // brow ridge in fur colour, so the face reads as a visor
  const brow = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.05, 0.08), m.fur);
  brow.position.set(0, 0.075, 0.2);
  brow.rotation.x = 0.18;
  head.add(brow);
  // large oval eyes with a slit pupil: sleepy, not googly
  for (const s of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.044, 10, 8), m.eye);
    eye.scale.set(1, 1.25, 0.5);
    eye.position.set(s * 0.075, 0.028, 0.222);
    head.add(eye);
    const pupil = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.055, 0.01), m.black);
    pupil.position.set(s * 0.075, 0.028, 0.243);
    head.add(pupil);
  }
  const muzzle = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), m.face);
  muzzle.scale.set(1.15, 0.7, 0.8);
  muzzle.position.set(0, -0.07, 0.235);
  head.add(muzzle);
  const nose = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.022, 0.02), m.dark);
  nose.position.set(0, -0.052, 0.285);
  head.add(nose);
  // ears: small rounded discs set low on the sides
  for (const s of [-1, 1]) {
    const ear = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.03, 10), m.fur);
    ear.rotation.z = Math.PI / 2;
    ear.position.set(s * 0.2, 0.0, 0.0);
    head.add(ear);
    const inner = new THREE.Mesh(new THREE.CylinderGeometry(0.036, 0.036, 0.034, 8), m.pad);
    inner.rotation.z = Math.PI / 2;
    inner.position.set(s * 0.205, 0.0, 0.0);
    head.add(inner);
  }
  // swept-back crest: three cones leaning backwards
  for (let i = 0; i < 3; i++) {
    const c = new THREE.Mesh(new THREE.ConeGeometry(0.045 - i * 0.008, 0.2 - i * 0.03, 5), m.fur);
    c.position.set(0, 0.17 - i * 0.02, -0.03 - i * 0.07);
    c.rotation.x = -1.0 - i * 0.15;
    head.add(c);
  }
  root.add(head);

  // ---- hat, if one is chosen ----
  const hat = hatMesh(cos.hat, m);
  if (hat) { hat.position.set(0, 0.2, 0); head.add(hat); }

  // ---- torso: chunky, belly patch in the accent colour ----
  const torso = new THREE.Group();
  const chest = new THREE.Mesh(new THREE.IcosahedronGeometry(0.22, 1), m.fur);
  chest.scale.set(1.15, 1.05, 0.8);
  torso.add(chest);
  const belly = new THREE.Mesh(new THREE.SphereGeometry(0.17, 8, 6), m.face);
  belly.scale.set(0.85, 1.05, 0.4);
  belly.position.set(0, -0.03, 0.15);
  torso.add(belly);
  const hips = new THREE.Mesh(new THREE.IcosahedronGeometry(0.17, 1), m.fur);
  hips.position.set(0, -0.26, 0);
  hips.scale.set(1.1, 0.9, 0.85);
  torso.add(hips);
  // a glowing chest light that shows team or role colour
  const core = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6), glow('#7be0c3'));
  core.position.set(0, 0.05, 0.19);
  torso.add(core);
  root.add(torso);

  // ---- arms and mitts ----
  const arms = [];
  const hands = [];
  for (let i = 0; i < 2; i++) {
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.075, 1, 8), m.fur);
    arm.geometry.translate(0, 0.5, 0); // origin at the shoulder end
    root.add(arm);
    arms.push(arm);
    const hand = new THREE.Group();
    const palm = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.07, 0.17), m.fur);
    hand.add(palm);
    const pad = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.03, 0.12), m.pad);
    pad.position.set(0, -0.045, 0.01);
    hand.add(pad);
    for (let f = 0; f < 3; f++) {
      const fing = new THREE.Mesh(new THREE.BoxGeometry(0.036, 0.04, 0.1), m.fur);
      fing.position.set(-0.048 + f * 0.048, -0.01, 0.13);
      hand.add(fing);
    }
    const thumb = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.04, 0.07), m.fur);
    thumb.position.set(i ? 0.09 : -0.09, -0.005, 0.04);
    hand.add(thumb);
    root.add(hand);
    hands.push(hand);
  }
  const glowRing = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.012, 6, 16), glow('#ff4d4d'));
  glowRing.visible = false;
  root.add(glowRing);

  const av = {
    root, head, torso, arms, hands, mats: m, hat, itGlow: [],
    // pose in world space: head, left hand, right hand (arrays of 3), yaw
    update(h, l, r, yaw) {
      head.position.set(h[0], h[1], h[2]);
      head.rotation.set(0, yaw, 0);
      // torso hangs under the head, leaning toward the hands
      const lean = Math.min(0.5, Math.max(0, (h[1] - (l[1] + r[1]) / 2 - 0.7) * 0.5));
      torso.position.set(h[0] - Math.sin(yaw) * 0.04, h[1] - 0.42, h[2] - Math.cos(yaw) * 0.04);
      torso.rotation.set(0, yaw, 0);
      torso.rotateX(lean);
      const sh = [[-0.2, -0.22], [0.2, -0.22]];
      [l, r].forEach((hp, i) => {
        const sx = sh[i][0], sy = sh[i][1];
        const cy = Math.cos(yaw), sy2 = Math.sin(yaw);
        const sp = new THREE.Vector3(h[0] + sx * cy, h[1] + sy, h[2] - sx * sy2);
        const hv = new THREE.Vector3(hp[0], hp[1], hp[2]);
        const d = hv.clone().sub(sp);
        const len = Math.max(0.05, d.length());
        arms[i].position.copy(sp);
        arms[i].scale.set(1, len, 1);
        arms[i].quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().normalize());
        hands[i].position.copy(hv);
        hands[i].rotation.set(0, yaw, 0);
      });
    },
    setCoreColor(hex) { core.material.color.set(hex); },
    setGlow(on, hex) { glowRing.visible = on; if (hex) glowRing.material.color.set(hex); },
    dispose() { root.traverse((o) => { if (o.geometry) o.geometry.dispose(); }); },
  };
  return av;
}

function hatMesh(kind, m) {
  if (!kind || kind === 'none') return null;
  const g = new THREE.Group();
  if (kind === 'party') { const c = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.25, 8), flat('#ff4fa3')); c.position.y = 0.1; g.add(c); }
  else if (kind === 'crown') { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.09, 0.09, 7), flat('#ffd43b', 0.3)); c.position.y = 0.04; g.add(c); }
  else if (kind === 'tophat') { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.02, 12), flat('#222')); const t = new THREE.Mesh(new THREE.CylinderGeometry(0.095, 0.095, 0.17, 12), flat('#222')); t.position.y = 0.09; g.add(b, t); }
  else if (kind === 'halo') { const t = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.014, 6, 18), glow('#fff3a0')); t.rotation.x = Math.PI / 2; t.position.y = 0.16; g.add(t); }
  else if (kind === 'cap') { const c = new THREE.Mesh(new THREE.SphereGeometry(0.19, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), flat('#e03131')); const v = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.015, 0.12), flat('#e03131')); v.position.set(0, 0.0, 0.2); g.add(c, v); }
  else return null;
  return g;
}

