// Turns the headset, controllers (or the keyboard and mouse) into the pose the game needs:
//   { h: head [x,y,z], l: left [x,y,z,grip,use], r: right [x,y,z,grip,use], y: yaw }
// Positions are in "rig space": the world-aligned play space. The rig itself is moved by the physics.
//
// VR:      move your arms to push off surfaces. Grip buttons hold on, triggers use.
// Screen:  mouse to look, W/A/S/D to swing along, Space to leap, Q/E to grip with the left/right hand,
//          click to use, Tab for the computer menu.

import * as THREE from './three.js';

const V = new THREE.Vector3();
const Q = new THREE.Quaternion();

export class Input {
  constructor(renderer, camera, rig, dom) {
    this.renderer = renderer;
    this.camera = camera;
    this.rig = rig;
    this.dom = dom;
    this.vr = false;
    this.keys = new Set();
    this.yaw = 0;
    this.pitch = 0;
    this.phase = 0;
    this.jump = 0;
    this.mouseDown = false;
    this.edges = { menu: false, emote: false, ready: false };
    this.prevBtn = { menu: false, emote: false, ready: false };
    this.sources = [null, null]; // XRInputSource for left, right
    this.ctrl = [renderer.xr.getController(0), renderer.xr.getController(1)];
    this.grip = [renderer.xr.getControllerGrip(0), renderer.xr.getControllerGrip(1)];
    this.hand = [renderer.xr.getHand(0), renderer.xr.getHand(1)];
    this.handed = ['', ''];
    for (let i = 0; i < 2; i++) {
      rig.add(this.ctrl[i], this.grip[i], this.hand[i]);
      this.ctrl[i].addEventListener('connected', (e) => { this.handed[i] = e.data.handedness; this.sources[i] = e.data; });
      this.ctrl[i].addEventListener('disconnected', () => { this.handed[i] = ''; this.sources[i] = null; });
    }
    this.joy = [0, 0];
    this.tGrip = [0, 0];
    this.tUse = 0;
    this.isTouch = typeof matchMedia === 'function' && (matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window);
    this.bindDesktop();
    if (this.isTouch) { try { this.bindTouch(); } catch (e) { this.touchError = String(e); } }
  }

  bindDesktop() {
    const d = this.dom;
    addEventListener('keydown', (e) => {
      if (e.repeat) return;
      this.keys.add(e.code);
      if (e.code === 'Tab') { e.preventDefault(); this.edges.menu = true; }
      if (e.code === 'Space') { e.preventDefault(); this.jump = 0.28; }
      if (e.code === 'KeyG') this.edges.emote = true;
      if (e.code === 'KeyR') this.edges.ready = true;
    });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    d.addEventListener('mousedown', (e) => {
      if (this.vr || this.isTouch) return;
      if (document.pointerLockElement !== d && !this.uiMode) { try { d.requestPointerLock(); } catch { /* not allowed here */ } }
      this.mouseDown = true;
      this.clicked = true;
    });
    addEventListener('mouseup', () => { this.mouseDown = false; });
    addEventListener('mousemove', (e) => {
      if (this.vr) return;
      if (document.pointerLockElement === d) {
        this.yaw -= e.movementX * 0.0024;
        this.pitch = Math.max(-1.4, Math.min(1.4, this.pitch - e.movementY * 0.0024));
      } else if (this.uiMode) {
        const r = d.getBoundingClientRect();
        this.cursor = [((e.clientX - r.left) / r.width) * 2 - 1, -(((e.clientY - r.top) / r.height) * 2 - 1)];
      }
    });
  }


  // On-screen controls for phones and flat browsers: joystick (left), look by dragging, buttons (right).
  bindTouch() {
    const mk = (css, text) => { const e = document.createElement('div'); e.style.cssText = 'position:fixed;z-index:8;user-select:none;touch-action:none;-webkit-user-select:none;font:bold 15px system-ui,sans-serif;color:#fff;display:grid;place-items:center;' + css; if (text) e.textContent = text; document.body.appendChild(e); return e; };
    this.dom.style.touchAction = 'none';
    const base = mk('left:4vmin;bottom:5vmin;width:30vmin;height:30vmin;border-radius:50%;background:#ffffff22;border:2px solid #ffffff55');
    const knob = mk('width:12vmin;height:12vmin;border-radius:50%;background:#ffffff88;pointer-events:none');
    base.appendChild(knob); knob.style.position = 'relative'; knob.style.left = '0'; knob.style.bottom = '0';
    let jid = null;
    const setJoy = (e) => {
      const r = base.getBoundingClientRect(), R = r.width / 2;
      let dx = e.clientX - (r.left + R), dy = e.clientY - (r.top + R);
      const l = Math.hypot(dx, dy); if (l > R) { dx *= R / l; dy *= R / l; }
      this.joy = [dx / R, dy / R];
      knob.style.transform = `translate(${dx}px,${dy}px)`;
    };
    base.addEventListener('pointerdown', (e) => { jid = e.pointerId; base.setPointerCapture(jid); setJoy(e); });
    base.addEventListener('pointermove', (e) => { if (e.pointerId === jid) setJoy(e); });
    const endJoy = (e) => { if (e.pointerId === jid) { jid = null; this.joy = [0, 0]; knob.style.transform = ''; } };
    base.addEventListener('pointerup', endJoy); base.addEventListener('pointercancel', endJoy);
    const hold = (css, text, on, off) => {
      const b = mk(css + ';width:15vmin;height:15vmin;border-radius:50%;background:#7b6bff99;border:2px solid #ffffff66', text);
      b.addEventListener('pointerdown', (e) => { b.setPointerCapture(e.pointerId); on(); });
      const up = () => off(); b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up);
    };
    hold('right:4vmin;bottom:5vmin', 'LEAP', () => { this.jump = 0.28; }, () => {});
    hold('right:21vmin;bottom:5vmin', 'GRAB R', () => { this.tGrip[1] = 1; }, () => { this.tGrip[1] = 0; });
    hold('right:21vmin;bottom:22vmin', 'GRAB L', () => { this.tGrip[0] = 1; }, () => { this.tGrip[0] = 0; });
    hold('right:4vmin;bottom:22vmin', 'USE', () => { this.tUse = 1; }, () => { this.tUse = 0; });
    hold('right:4vmin;top:4vmin;width:12vmin', 'MENU', () => { this.edges.menu = true; }, () => {});
    // drag anywhere else to look; when the computer panel is open a tap is a click on it
    let lid = null, lx = 0, ly = 0;
    this.dom.addEventListener('pointerdown', (e) => {
      if (this.vr || e.pointerType === 'mouse') return;
      if (this.uiMode) { const r = this.dom.getBoundingClientRect(); this.cursor = [((e.clientX - r.left) / r.width) * 2 - 1, -(((e.clientY - r.top) / r.height) * 2 - 1)]; this.clicked = true; return; }
      lid = e.pointerId; lx = e.clientX; ly = e.clientY; this.dom.setPointerCapture(lid);
    });
    this.dom.addEventListener('pointermove', (e) => {
      if (e.pointerId !== lid) return;
      this.yaw -= (e.clientX - lx) * 0.006; this.pitch = Math.max(-1.4, Math.min(1.4, this.pitch - (e.clientY - ly) * 0.006));
      lx = e.clientX; ly = e.clientY;
    });
    const endLook = (e) => { if (e.pointerId === lid) lid = null; };
    this.dom.addEventListener('pointerup', endLook); this.dom.addEventListener('pointercancel', endLook);
  }

  setVR(on) { this.vr = on; }

  hasKey(c) { return this.keys.has(c); }

  btn(i, idx) {
    const s = this.sources[i];
    const b = s && s.gamepad && s.gamepad.buttons[idx];
    return b ? Math.max(b.value || 0, b.pressed ? 1 : 0) : 0;
  }

  pinch(i) {
    const h = this.hand[i];
    if (!h || !h.joints) return null;
    const t = h.joints['thumb-tip'], f = h.joints['index-finger-tip'], w = h.joints.wrist;
    if (!t || !f || !w || !t.position || w.position.lengthSq() === 0) return null;
    const d = t.position.distanceTo(f.position);
    return { pos: w.position.clone(), val: d < 0.03 ? 1 : d < 0.05 ? 0.5 : 0 };
  }

  // ---- called every frame --------------------------------------------------------------------------------
  poll(dt, settings = {}) {
    this.edges.menu = this.edges.menu && !this.vr ? true : false;
    let out;
    if (this.vr) out = this.pollVR(settings);
    else out = this.pollDesktop(dt);
    return out;
  }

  pollVR(settings) {
    this.camera.getWorldDirection(V);
    const yaw = Math.atan2(V.x, V.z);
    const hd = this.camera.position;
    const pose = { h: [hd.x, hd.y, hd.z], l: [-0.25, 1.0, 0.3, 0, 0], r: [0.25, 1.0, 0.3, 0, 0], y: yaw };
    const slotOf = (hand) => (this.handed[0] === hand ? 0 : this.handed[1] === hand ? 1 : hand === 'left' ? 0 : 1);
    const out = {};
    for (const [key, name] of [['l', 'left'], ['r', 'right']]) {
      const i = slotOf(name);
      const g = this.grip[i], c = this.ctrl[i];
      const p = this.pinch(i);
      const src = g.position.lengthSq() > 0 ? g.position : c.position;
      let grip = this.btn(i, 1), use = this.btn(i, 0);
      let pos = src;
      if (this.sources[i] && this.sources[i].hand && p) { pos = p.pos; grip = p.val; use = p.val > 0.9 ? 1 : 0; }
      pose[key] = [pos.x, pos.y, pos.z, grip, use];
      out[key] = i;
    }
    // buttons: left X/Y opens the computer, right A waves, right B toggles ready
    const li = slotOf('left'), ri = slotOf('right');
    const now = { menu: this.btn(li, 4) > 0.5 || this.btn(li, 5) > 0.5, emote: this.btn(ri, 4) > 0.5, ready: this.btn(ri, 5) > 0.5 };
    for (const k of ['menu', 'emote', 'ready']) { this.edges[k] = now[k] && !this.prevBtn[k]; this.prevBtn[k] = now[k]; }
    // UI ray from the dominant hand's controller
    const di = slotOf(settings.handed === 'left' ? 'left' : 'right');
    const c = this.ctrl[di];
    c.updateMatrixWorld(true);
    const o = new THREE.Vector3().setFromMatrixPosition(c.matrixWorld);
    const dir = new THREE.Vector3(0, 0, -1).transformDirection(c.matrixWorld);
    const trig = this.btn(di, 0) > 0.6;
    this.rayDown = trig;
    return { pose, ray: { o, d: dir, down: trig, pressed: trig && !this.prevTrig }, ui: this.afterRay(trig) };
  }

  afterRay(trig) { this.prevTrig = trig; return true; }

  pollDesktop(dt) {
    const k = this.keys;
    // camera follows mouse look
    const head = [0, 1.6, 0];
    this.camera.position.set(head[0], head[1], head[2]);
    this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
    const fwd = [-Math.sin(this.yaw), 0, -Math.cos(this.yaw)];
    const right = [Math.cos(this.yaw), 0, -Math.sin(this.yaw)];
    let mx = 0, mz = 0;
    if (k.has('KeyW')) { mx += fwd[0]; mz += fwd[2]; }
    if (k.has('KeyS')) { mx -= fwd[0]; mz -= fwd[2]; }
    if (k.has('KeyD')) { mx += right[0]; mz += right[2]; }
    if (k.has('KeyA')) { mx -= right[0]; mz -= right[2]; }
    if (this.joy[0] || this.joy[1]) { mx += fwd[0] * -this.joy[1] + right[0] * this.joy[0]; mz += fwd[2] * -this.joy[1] + right[2] * this.joy[0]; }
    const ml = Math.hypot(mx, mz);
    const moving = ml > 0.01;
    if (moving) { mx /= ml; mz /= ml; this.phase += dt * 6.5; }
    else this.phase = Math.round(this.phase / Math.PI) * Math.PI; // settle with both hands down
    if (this.jump > 0) this.jump -= dt;
    // each hand: pinned to the floor and dragged back (push), then lifted and swung forward
    const hand = (side, ph) => {
      const t = (((ph / (Math.PI * 2)) % 1) + 1) % 1;
      let along, lift;
      if (t < 0.5) { along = 0.3 - 0.6 * (t * 2); lift = 0; } else { along = -0.3 + 0.6 * ((t - 0.5) * 2); lift = 0.26 * Math.sin(Math.PI * (t - 0.5) * 2); }
      let y = 1.0 + lift;
      if (this.jump > 0) y = 1.0 - 0.3 * Math.sin((1 - this.jump / 0.28) * Math.PI); // both hands slam down: a leap
      const dx = moving ? mx : 0, dz = moving ? mz : 0;
      return [side * 0.24 * right[0] + dx * along, y, side * 0.24 * right[2] + dz * along];
    };
    let l = hand(-1, this.phase), r = hand(1, this.phase + Math.PI);
    const gripL = k.has('KeyQ') || this.tGrip[0] ? 1 : 0, gripR = k.has('KeyE') || this.tGrip[1] ? 1 : 0;
    // holding a grip reaches that hand out in front so you can pick things up
    const reach = (side, rel) => [head[0] + fwd[0] * 0.75 * Math.cos(this.pitch) + side * 0.12 * right[0], head[1] - 0.15 + Math.sin(this.pitch) * 0.75, head[2] + fwd[2] * 0.75 * Math.cos(this.pitch) + side * 0.12 * right[2]];
    if (gripL) l = reach(-1);
    if (gripR) r = reach(1);
    const use = this.mouseDown || this.tUse ? 1 : 0;
    const pose = { h: head, l: [...l, gripL, k.has('KeyF') ? 1 : 0], r: [...r, gripR, use], y: Math.atan2(fwd[0], fwd[2]) };
    // ray for the computer screen: straight out of the camera, or the mouse when the pointer is free
    const ray = this.cursor && document.pointerLockElement !== this.dom
      ? { cursor: this.cursor, down: this.mouseDown, pressed: this.clicked }
      : { centre: true, down: this.mouseDown, pressed: this.clicked };
    this.clicked = false;
    for (const key of ['menu', 'emote', 'ready']) { /* edges are set by keydown and consumed by main */ }
    return { pose, ray, ui: false };
  }

  consumeEdge(name) { const v = this.edges[name]; this.edges[name] = false; return v; }
}
