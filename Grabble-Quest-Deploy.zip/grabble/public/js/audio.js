// All sound is synthesised with the Web Audio API, so the game ships no audio files.
// Sounds are positional: each one is panned and attenuated relative to the listener.

export class Audio {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.vol = 0.7;
    this.silent = false;
    this.ambient = null;
    this.lis = { p: [0, 0, 0], yaw: 0 };
  }

  start() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.vol;
    this.master.connect(this.ctx.destination);
    const len = this.ctx.sampleRate;
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  }

  setVolume(v) { this.vol = v; if (this.master) this.master.gain.value = v; }
  setListener(p, yaw) { this.lis.p = p; this.lis.yaw = yaw; }

  // gain and pan from a world position
  spatial(pos, ref = 6) {
    if (!pos) return { g: 1, pan: 0 };
    const dx = pos[0] - this.lis.p[0], dz = pos[2] - this.lis.p[2], dy = pos[1] - this.lis.p[1];
    const d = Math.hypot(dx, dy, dz);
    const g = 1 / (1 + (d / ref) * (d / ref) * 1.6);
    const ang = Math.atan2(dx, dz) - this.lis.yaw;
    return { g, pan: Math.max(-1, Math.min(1, Math.sin(ang))) };
  }

  tone({ f = 440, f2 = null, t = 0.15, type = 'sine', g = 0.3, pos = null, attack = 0.005 }) {
    if (!this.ctx || this.silent) return;
    const s = this.spatial(pos);
    if (s.g < 0.01) return;
    const c = this.ctx, now = c.currentTime;
    const o = c.createOscillator(), a = c.createGain(), p = c.createStereoPanner ? c.createStereoPanner() : null;
    o.type = type;
    o.frequency.setValueAtTime(f, now);
    if (f2) o.frequency.exponentialRampToValueAtTime(Math.max(1, f2), now + t);
    a.gain.setValueAtTime(0, now);
    a.gain.linearRampToValueAtTime(g * s.g, now + attack);
    a.gain.exponentialRampToValueAtTime(0.0001, now + t);
    o.connect(a);
    if (p) { p.pan.value = s.pan; a.connect(p); p.connect(this.master); } else a.connect(this.master);
    o.start(now);
    o.stop(now + t + 0.05);
  }

  noise({ t = 0.2, g = 0.25, f = 1200, q = 0.7, type = 'bandpass', pos = null, f2 = null }) {
    if (!this.ctx || this.silent) return;
    const s = this.spatial(pos);
    if (s.g < 0.01) return;
    const c = this.ctx, now = c.currentTime;
    const src = c.createBufferSource(), flt = c.createBiquadFilter(), a = c.createGain();
    src.buffer = this.noiseBuf;
    flt.type = type;
    flt.Q.value = q;
    flt.frequency.setValueAtTime(f, now);
    if (f2) flt.frequency.exponentialRampToValueAtTime(Math.max(20, f2), now + t);
    a.gain.setValueAtTime(g * s.g, now);
    a.gain.exponentialRampToValueAtTime(0.0001, now + t);
    src.connect(flt); flt.connect(a); a.connect(this.master);
    src.start(now);
    src.stop(now + t + 0.05);
  }

  // Named effects. The game sends the same names the Sim emits.
  sfx(k, pos, v = 1) {
    switch (k) {
      case 'grab': this.tone({ f: 320, f2: 520, t: 0.09, type: 'triangle', g: 0.25, pos }); break;
      case 'grabp': this.tone({ f: 200, f2: 120, t: 0.2, type: 'sawtooth', g: 0.25, pos }); break;
      case 'throw': this.noise({ t: 0.18, g: 0.2, f: 700, f2: 2500, pos }); break;
      case 'thud': this.noise({ t: 0.12, g: 0.4 * v, f: 220, q: 1.2, type: 'lowpass', pos }); break;
      case 'bonk': this.tone({ f: 160, f2: 70, t: 0.18, type: 'square', g: 0.3, pos }); break;
      case 'pickup': this.tone({ f: 600, f2: 1200, t: 0.16, type: 'sine', g: 0.3, pos }); this.tone({ f: 900, f2: 1500, t: 0.2, type: 'sine', g: 0.2, pos }); break;
      case 'power': this.tone({ f: 300, f2: 900, t: 0.3, type: 'sawtooth', g: 0.25, pos }); break;
      case 'shatter': this.noise({ t: 0.35, g: 0.4, f: 3500, q: 0.4, type: 'highpass', pos }); break;
      case 'slip': this.tone({ f: 700, f2: 250, t: 0.18, type: 'sine', g: 0.2, pos }); break;
      case 'steal': this.tone({ f: 500, f2: 250, t: 0.14, type: 'square', g: 0.2, pos }); break;
      case 'click': this.tone({ f: 1400, t: 0.04, type: 'square', g: 0.15, pos }); break;
      case 'burn': this.noise({ t: 0.5, g: 0.3, f: 900, f2: 200, pos }); break;
      case 'fall': this.tone({ f: 500, f2: 80, t: 0.5, type: 'sine', g: 0.3 }); break;
      case 'crumble': this.noise({ t: 0.5, g: 0.3, f: 300, q: 0.5, type: 'lowpass', pos }); break;
      case 'chomp': this.tone({ f: 120, f2: 40, t: 0.4, type: 'sawtooth', g: 0.5, pos }); this.noise({ t: 0.3, g: 0.4, f: 500, pos }); break;
      case 'door': this.tone({ f: 90, f2: 60, t: 1.2, type: 'sawtooth', g: 0.35, pos }); break;
      case 'descend': this.tone({ f: 400, f2: 60, t: 1.4, type: 'sine', g: 0.4 }); break;
      case 'shot': this.noise({ t: 0.2, g: 0.5, f: 1800, f2: 300, pos }); break;
      case 'whack': this.tone({ f: 220, f2: 90, t: 0.15, type: 'square', g: 0.4, pos }); this.noise({ t: 0.1, g: 0.3, f: 1200, pos }); break;
      case 'hit': this.tone({ f: 180, f2: 80, t: 0.14, type: 'square', g: 0.3, pos }); break;
      case 'ice': this.tone({ f: 1800, f2: 1000, t: 0.4, type: 'triangle', g: 0.2, pos }); break;
      case 'boom': this.noise({ t: 0.8, g: 0.8, f: 400, f2: 60, type: 'lowpass', pos }); break;
      case 'ui': this.tone({ f: 880, t: 0.05, type: 'triangle', g: 0.18 }); break;
      case 'ok': this.tone({ f: 520, f2: 780, t: 0.14, type: 'triangle', g: 0.22 }); break;
      case 'no': this.tone({ f: 200, f2: 150, t: 0.18, type: 'square', g: 0.2 }); break;
      case 'tick': this.tone({ f: 1000, t: 0.03, type: 'square', g: 0.12 }); break;
      case 'win': [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => this.tone({ f, t: 0.3, type: 'triangle', g: 0.3 }), i * 130)); break;
      case 'lose': [400, 330, 262].forEach((f, i) => setTimeout(() => this.tone({ f, t: 0.35, type: 'sawtooth', g: 0.25 }), i * 180)); break;
      default: break;
    }
  }

  // Looping ambience. Backrooms get a fluorescent hum that gets louder when a monster is near.
  setAmbient(kind) {
    if (!this.ctx || this.ambientKind === kind) return;
    this.stopAmbient();
    this.ambientKind = kind;
    const c = this.ctx;
    const g = c.createGain();
    g.gain.value = 0;
    g.connect(this.master);
    const nodes = [g];
    const osc = (f, type, gain) => { const o = c.createOscillator(), og = c.createGain(); o.type = type; o.frequency.value = f; og.gain.value = gain; o.connect(og); og.connect(g); o.start(); nodes.push(o, og); return o; };
    if (kind === 'backrooms') { osc(60, 'sawtooth', 0.05); osc(120.5, 'sine', 0.04); osc(2000, 'sine', 0.004); }
    else if (kind === 'night') { osc(110, 'sine', 0.03); osc(165, 'sine', 0.02); }
    else if (kind === 'lava') { osc(48, 'sawtooth', 0.05); osc(52, 'sawtooth', 0.04); }
    else { osc(196, 'sine', 0.012); osc(294, 'sine', 0.01); }
    g.gain.linearRampToValueAtTime(1, c.currentTime + 1.5);
    this.ambient = { g, nodes };
  }

  stopAmbient() {
    this.ambientKind = null;
    if (!this.ambient) return;
    const a = this.ambient;
    this.ambient = null;
    try { a.g.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.5); } catch { /* context closed */ }
    setTimeout(() => a.nodes.forEach((n) => { try { n.stop && n.stop(); n.disconnect(); } catch { /* already stopped */ } }), 700);
  }

  // 0..1, how close a threat is. Drives the hum.
  setDanger(x) { if (this.ambient) this.ambient.g.gain.value = 0.6 + 0.8 * Math.max(0, Math.min(1, x)); }
}
