// A session is where the game state comes from. The rest of the client does not care which kind it is.
//
//   LocalSession : the whole game runs inside the browser (the same Sim the server runs). Used for the
//                  spawn plaza and solo play with bots. Works with no server at all.
//   NetSession   : talks to the multiplayer server. Your own movement is predicted locally with the same
//                  shared locomotion code so it feels instant, then softly corrected by the server.
//
// Both expose: info, id, roster, update(dt, pose) -> { snap, events, me }, act(a), leave().

import { Sim } from '../../shared/sim.js';
import { DT, LOCO } from '../../shared/constants.js';
import { todaySeed } from '../../shared/util.js';
import { buildArena } from '../../shared/arenas.js';
import { buildBackroomsLevel } from '../../shared/backrooms/levels.js';
import { newLoco, newPoseState, stepLoco, setPoseTarget, approachPose, tryAnchor, handWorld } from '../../shared/loco.js';

export function arenaFor(info) {
  const a = info.kind === 'backrooms' ? buildBackroomsLevel(info.level || 1, info.seed) : buildArena(info.kind, info.theme, info.seed);
  a.colliders.forEach((c, i) => { c.id = i; });
  return a;
}

export const infoSig = (i) => (i ? `${i.kind}|${i.theme}|${i.seed}|${i.level || 0}` : '');

// ---------------------------------------------------------------------------------------------------
export class LocalSession {
  constructor({ mode = 'hub', opts = {}, name = 'Player', cos = {}, bots = 0 }) {
    this.kind = 'local';
    this.id = 'me';
    const seed = opts.daily ? todaySeed() : (opts.seed ?? (Math.random() * 4294967296) >>> 0);
    this.sim = new Sim({ mode, seed, difficulty: opts.difficulty || 'normal', level: opts.level, mods: opts.mods || [], kidSafe: !!opts.kid, daily: !!opts.daily });
    this.sim.addPlayer('me', { name, cos });
    if (bots > 0) this.sim.fillBots(1 + bots);
    this.acc = 0;
    this.seq = 0;
    this.error = null;
    if (!this.sim.mode.auto) this.sim.start(); // solo matches begin straight away
    this.lastPhase = this.sim.phase;
  }

  get info() { return this.sim.info(); }
  get phase() { return this.sim.phase; }
  get modeId() { return this.sim.modeId; }
  get result() { return this.sim.result; }
  get roster() {
    const m = new Map();
    for (const p of this.sim.players.values()) m.set(p.id, { name: p.name, cos: p.cos, bot: p.bot });
    return m;
  }
  get inRoom() { return false; }

  update(dt, pose) {
    this.acc += Math.min(dt, 0.1);
    this.sim.setPose('me', pose, ++this.seq);
    let n = 0;
    while (this.acc >= DT && n < 6) { this.sim.dt = DT; this.sim.tick(DT); this.acc -= DT; n++; }
    const snap = this.sim.snapshot();
    const events = this.sim.drainEvents();
    return { snap, events, me: this.sim.players.get('me') };
  }

  act(a) { this.sim.action('me', a); }
  start() { return this.sim.start(); }
  restart() { return this.sim.phase === 'over'; }
  leave() { /* nothing to close */ }
}

// ---------------------------------------------------------------------------------------------------
function newPred() {
  const ps = newPoseState();
  return { root: [0, 0, 0], vel: [0, 0, 0], rel: ps.rel, target: ps.target, grip: [0, 0], use: [0, 0], prevGrip: [0, 0], stamina: 1, loco: newLoco(), handScale: [1, 1], reach: 1, fx: {}, yaw: 0 };
}

export class NetSession {
  constructor({ url, name, cos, WS = globalThis.WebSocket }) {
    this.kind = 'net';
    this.name = name;
    this.cos = cos;
    this.id = null;
    this.room = null; // last room message
    this.latest = null;
    this.fresh = false;
    this.events = [];
    this.error = null;
    this.rosterMap = new Map();
    this.closed = false;
    this.pred = newPred();
    this.predSig = '';
    this.cols = [];
    this.acc = 0;
    this.sendT = 0;
    this.seq = 0;
    this.lastRoot = null;
    this.handlers = {};
    this.ws = new WS(url);
    this.opened = new Promise((res, rej) => {
      this.ws.onopen = () => { this.send({ t: 'hello', name, cos }); res(); };
      this.ws.onerror = () => rej(new Error('Could not reach the server'));
    });
    this.welcomed = new Promise((res) => { this._welcome = res; });
    this.opened.catch(() => { this.error = 'Could not reach the server'; this.closed = true; });
    this.ws.onmessage = (e) => this.onMessage(e.data);
    this.ws.onclose = () => { this.closed = true; this.emit('close'); };
  }

  on(k, f) { this.handlers[k] = f; }
  emit(k, v) { if (this.handlers[k]) this.handlers[k](v); }
  send(o) { if (this.ws.readyState === 1) this.ws.send(JSON.stringify(o)); }

  onMessage(text) {
    let m;
    try { m = JSON.parse(text); } catch { return; }
    if (!m || typeof m.t !== 'string') return;
    if (m.t === 'welcome') { this.id = m.id; this._welcome(); this.emit('welcome', m); }
    else if (m.t === 'room') {
      this.room = m;
      this.rosterMap = new Map(m.players.map((p) => [p.id, { name: p.name, cos: p.cos || {}, bot: p.bot, ready: p.ready, team: p.team }]));
      this.emit('room', m);
    } else if (m.t === 'snap') {
      this.latest = m;
      this.fresh = true;
      if (m.ev) for (const e of m.ev) this.events.push(e);
    } else if (m.t === 'err') { this.error = m.msg; this.emit('error', m); }
    else if (m.t === 'left' && m.self) { this.room = null; this.latest = null; this.emit('left'); }
    else if (m.t === 'kicked') { this.room = null; this.latest = null; this.error = 'You were removed from the room'; this.emit('kicked'); }
  }

  get info() { return this.room ? { mode: this.room.mode, kind: this.room.kind, theme: this.room.theme, seed: this.room.seed, level: (this.latest && this.latest.md && this.latest.md.level) || this.room.level || 0 } : null; }
  get phase() { return this.latest ? this.latest.ph : 'lobby'; }
  get roster() { return this.rosterMap; }
  get inRoom() { return !!this.room; }
  get host() { return this.room && this.room.host === this.id; }
  get result() { return this.endResult || null; }

  create(opts) { this.error = null; this.send({ t: 'create', ...opts }); }
  join(code) { this.error = null; this.send({ t: 'join', code }); }
  leave() { this.send({ t: 'leave' }); }
  start() { this.send({ t: 'start' }); return true; }
  act(a) { this.send({ t: 'act', a }); }
  close() { try { this.ws.close(); } catch { /* already closed */ } }

  // ---- prediction ----
  rebuildPred(info) {
    this.predSig = infoSig(info);
    this.arena = arenaFor(info);
    this.cols = this.arena.colliders;
    this.pred = newPred();
    if (this.latest) {
      const me = this.latest.pl.find((p) => p.i === this.id);
      if (me) { this.pred.root = me.p.slice(); }
    }
    this.pendingSnap = true;
  }

  update(dt, pose) {
    const info = this.info;
    if (!info || !this.latest) return null;
    if (infoSig(info) !== this.predSig) this.rebuildPred(info);
    const P = this.pred;

    // apply server doors and platforms to our collision copy
    const snap = this.latest;
    if (this.fresh) {
      if (snap.dc) for (const d of snap.dc) {
        let c = this.cols[d[0]];
        if (!c) { c = { on: true, mat: 'ice', dyn: true, id: d[0], min: [0, 0, 0], max: [0, 0, 0] }; this.cols[d[0]] = c; }
        c.on = !!d[1]; c.min = [d[2], d[3], d[4]]; c.max = [d[5], d[6], d[7]];
      }
      const me = snap.pl.find((p) => p.i === this.id);
      if (me) {
        P.fx = {};
        for (const k of me.fx) P.fx[k] = Infinity;
        P.stamina = me.st;
        const err = Math.hypot(me.p[0] - P.root[0], me.p[1] - P.root[1], me.p[2] - P.root[2]);
        if (err > 1.6) { P.root = me.p.slice(); P.vel = me.v.slice(); }
        else { for (let i = 0; i < 3; i++) P.root[i] += (me.p[i] - P.root[i]) * 0.12; }
        this.me = me;
      }
      this.fresh = false;
    }

    setPoseTarget(P, pose, 1);
    this.acc += Math.min(dt, 0.1);
    let n = 0;
    while (this.acc >= DT && n < 6) {
      approachPose(P, DT);
      const stun = P.fx.stun || P.fx.hold || P.fx.frozen;
      if (P.fx.frozen) P.vel = [0, 0, 0];
      else {
        for (let i = 0; i < 2; i++) if (P.grip[i] >= LOCO.gripOn && P.prevGrip[i] < LOCO.gripOn && !stun) tryAnchor(P, i, this.cols);
        stepLoco(P, DT, this.cols, { gravity: snap.env ? snap.env.g : 9.8, waterY: this.arena.waterY, handMask: stun ? [false, false] : [true, true], noAnchor: !!stun });
      }
      P.prevGrip = [P.grip[0], P.grip[1]];
      this.acc -= DT;
      n++;
    }

    this.sendT += dt;
    if (this.sendT >= 1 / 60) {
      this.sendT = 0;
      this.send({ t: 'pose', q: ++this.seq, p: { h: pose.h, l: pose.l, r: pose.r, y: pose.y } });
    }
    const events = this.events;
    this.events = [];
    for (const e of events) if (e.e === 'end') this.endResult = e.res;
    return { snap, events, me: P };
  }
}

export { handWorld };
