// Pure HUD logic (no DOM, no Three.js) so it can be tested in Node.
import { MODES } from '../../shared/modes/index.js';

const fmt = (s) => { s = Math.max(0, Math.ceil(s)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };

export function hudModel(snap, id, info, roster = new Map()) {
  if (!snap) return { top: '', left: '', right: '', bars: [], center: '' };
  const me = snap.pl.find((p) => p.i === id);
  const md = snap.md || {};
  const mode = info && MODES[info.mode] ? MODES[info.mode].name : '';
  const m = { top: '', left: '', right: '', bars: [], center: '', mode };
  if (snap.ph === 'countdown') m.center = String(Math.max(1, Math.ceil(snap.cd)));
  if (snap.ph === 'play' && snap.tl > 0 && info && info.mode !== 'backrooms') m.top = fmt(snap.tl);
  if (me) {
    m.right = `${me.sc} pts`;
    if (me.ro === 'it') m.left = 'YOU ARE IT';
    else if (me.fx.includes('frozen')) m.left = 'FROZEN: wait for a friend';
    else if (me.a === 0) m.left = 'You are out';
    if (info && info.kind !== 'hub') m.bars.push({ k: 'stamina', v: me.st, c: '#7be0c3' });
    if (info && info.mode === 'backrooms') {
      m.bars.push({ k: 'sanity', v: me.sn, c: '#c4a7ff' });
      m.bars.push({ k: 'health', v: Math.max(0, me.hp) / 100, c: '#ff8787' });
    }
  }
  if (md.level) {
    m.top = `LEVEL ${md.level}: ${md.name}`;
    m.left = m.left || `${md.have ? Object.values(md.have).reduce((a, b) => a + b, 0) : 0}/${md.need ? Object.values(md.need).reduce((a, b) => a + b, 0) : 0} parts` + (md.open ? '  EXIT OPEN' : '');
    m.sub = md.monsters ? `${md.monsters} monsters hunting` : '';
  }
  if (md.wave !== undefined) { m.top = `WAVE ${md.wave}/${md.total}`; m.sub = `${md.left} zombies left`; }
  if (md.bossHp !== undefined) { m.top = `BOSS ${md.bossHp}%`; m.sub = `phase ${md.phase}`; }
  if (md.order) { m.sub = `Order: ${md.orderId} (${md.order.join(' + ')})`; }
  if (md.its && md.its.length) m.sub = `${md.left} runners left`;
  if (md.score) m.right = `${md.score[0]} : ${md.score[1]}`;
  if (md.holder !== undefined && me && md.holder === id) m.left = 'YOU HAVE IT';
  return m;
}

