// Head-up display. It is drawn on a canvas and shown as a small panel locked in front of the camera,
// so it works the same on a flat screen and in the headset (where DOM overlays are invisible).
//
// hudModel() is pure and has no DOM or Three.js dependency, so it is tested in Node.

import * as THREE from './three.js';
export { hudModel } from './hudmodel.js';

export class Hud {
  constructor(camera) {
    this.canvas = document.createElement('canvas');
    this.canvas.width = 768; this.canvas.height = 384;
    this.ctx = this.canvas.getContext('2d');
    this.tex = new THREE.CanvasTexture(this.canvas);
    this.tex.colorSpace = THREE.SRGBColorSpace;
    this.mesh = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.6), new THREE.MeshBasicMaterial({ map: this.tex, transparent: true, depthTest: false, depthWrite: false }));
    this.mesh.position.set(0, -0.02, -1.4);
    this.mesh.renderOrder = 999;
    camera.add(this.mesh);
    // comfort vignette: a dark ring that grows when you are moving fast
    const vc = document.createElement('canvas'); vc.width = vc.height = 256;
    const g = vc.getContext('2d');
    const grd = g.createRadialGradient(128, 128, 60, 128, 128, 128);
    grd.addColorStop(0, 'rgba(0,0,0,0)'); grd.addColorStop(1, 'rgba(0,0,0,1)');
    g.fillStyle = grd; g.fillRect(0, 0, 256, 256);
    this.vig = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.6), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(vc), transparent: true, opacity: 0, depthTest: false, depthWrite: false }));
    this.vig.position.set(0, 0, -0.5);
    this.vig.renderOrder = 998;
    camera.add(this.vig);
    this.toasts = [];
    this.sig = '';
  }

  toast(text, secs = 2.5) { this.toasts.push({ text, t: secs }); if (this.toasts.length > 3) this.toasts.shift(); this.sig = ''; }

  update(dt, model, speed = 0, vignetteOn = true, damage = 0) {
    this.vig.material.opacity = vignetteOn ? Math.min(0.85, Math.max(0, (speed - 5) * 0.12)) : 0;
    for (const t of this.toasts) t.t -= dt;
    this.toasts = this.toasts.filter((t) => t.t > 0);
    const sig = JSON.stringify([model, this.toasts.map((t) => t.text)]);
    if (sig === this.sig) return;
    this.sig = sig;
    const g = this.ctx, W = 768, H = 384;
    g.clearRect(0, 0, W, H);
    g.textBaseline = 'middle';
    const shadow = (txt, x, y, font, col, align = 'left') => { g.font = font; g.textAlign = align; g.fillStyle = '#000a'; g.fillText(txt, x + 2, y + 2); g.fillStyle = col; g.fillText(txt, x, y); };
    if (model.top) shadow(model.top, W / 2, 28, 'bold 34px system-ui, sans-serif', '#fff', 'center');
    if (model.sub) shadow(model.sub, W / 2, 62, '22px system-ui, sans-serif', '#ffd8a8', 'center');
    if (model.left) shadow(model.left, 20, 28, 'bold 26px system-ui, sans-serif', '#ffb347');
    if (model.right) shadow(model.right, W - 20, 28, 'bold 26px system-ui, sans-serif', '#9fe8d0', 'right');
    if (model.center) shadow(model.center, W / 2, H / 2, 'bold 120px system-ui, sans-serif', '#fff', 'center');
    model.bars.forEach((b, i) => {
      const y = H - 28 - i * 26;
      g.fillStyle = '#0008'; g.fillRect(20, y - 8, 180, 16);
      g.fillStyle = b.c; g.fillRect(20, y - 8, 180 * Math.max(0, Math.min(1, b.v)), 16);
      shadow(b.k, 210, y, '16px system-ui, sans-serif', '#fff');
    });
    this.toasts.forEach((t, i) => shadow(t.text, W / 2, H - 80 - i * 34, 'bold 26px system-ui, sans-serif', '#fff', 'center'));
    this.tex.needsUpdate = true;
  }
}
