// Builds and updates everything you see: the arena, items, monsters, lava, water, effects and the other
// players. The arena is rebuilt from the same shared code the server uses, so no geometry is sent.

import * as THREE from './three.js';
import { buildArena } from '../../shared/arenas.js';
import { buildBackroomsLevel } from '../../shared/backrooms/levels.js';
import { ITEMS } from '../../shared/items.js';
import { buildAvatar } from './avatar.js';

const TAU = Math.PI * 2;
const lerp = (a, b, t) => a + (b - a) * t;

// ---- merge all static boxes into one mesh with vertex colours (a few draw calls, not hundreds) ----------
const FACES = [
  { n: [1, 0, 0], v: [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]] },
  { n: [-1, 0, 0], v: [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]] },
  { n: [0, 1, 0], v: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]] },
  { n: [0, -1, 0], v: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]] },
  { n: [0, 0, 1], v: [[1, 0, 1], [1, 1, 1], [0, 1, 1], [0, 0, 1]] },
  { n: [0, 0, -1], v: [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]] },
];

function mergeBoxes(list) {
  const pos = [], nor = [], col = [], idx = [];
  let base = 0;
  for (const { min, max, color, shade } of list) {
    const c = new THREE.Color(color);
    for (const f of FACES) {
      for (const v of f.v) {
        pos.push(v[0] ? max[0] : min[0], v[1] ? max[1] : min[1], v[2] ? max[2] : min[2]);
        nor.push(f.n[0], f.n[1], f.n[2]);
        const k = (v[1] ? 1 : 0.78) * shade;
        col.push(c.r * k, c.g * k, c.b * k);
      }
      idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
      base += 4;
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  g.computeBoundingSphere();
  return g;
}

function hash(n) { const x = Math.sin(n * 12.9898) * 43758.5453; return x - Math.floor(x); }

// ---- items -------------------------------------------------------------------------------------------------
const BOXY = new Set(['brick', 'crate', 'block', 'goldbar', 'anvil', 'dodgeball_x', 'keycard', 'note', 'flaregun', 'slingshot', 'baton', 'magnet', 'confetti', 'trophy', 'relic']);
const LONG = new Set(['bat', 'pipe', 'flashlight']);
const CYL = new Set(['fuse', 'battery', 'glowstick', 'honey', 'bomb_x']);

const geoCache = new Map();
function itemGeo(type) {
  if (geoCache.has(type)) return geoCache.get(type);
  const r = ITEMS[type].r;
  let g;
  if (type === 'keycard') g = new THREE.BoxGeometry(r * 2.4, r * 0.25, r * 1.6);
  else if (type === 'note') g = new THREE.BoxGeometry(r * 2.2, r * 0.12, r * 2.8);
  else if (type === 'goldbar') g = new THREE.BoxGeometry(r * 2.6, r * 0.9, r * 1.4);
  else if (BOXY.has(type)) g = new THREE.BoxGeometry(r * 2, r * 2, r * 2);
  else if (LONG.has(type)) g = new THREE.CylinderGeometry(r * 0.35, r * 0.28, r * 6, 8);
  else if (CYL.has(type)) g = new THREE.CylinderGeometry(r * 0.6, r * 0.6, r * 2.4, 10);
  else if (type === 'pu_boots' || type.startsWith('pu_')) g = new THREE.OctahedronGeometry(r * 1.1, 0);
  else if (type === 'gem' || type === 'fakegem') g = new THREE.OctahedronGeometry(r * 1.2, 0);
  else if (type === 'flag') g = new THREE.CylinderGeometry(r * 0.15, r * 0.15, r * 7, 6);
  else if (type === 'balloon') g = new THREE.SphereGeometry(r, 10, 8);
  else g = new THREE.SphereGeometry(r, 12, 9);
  geoCache.set(type, g);
  return g;
}
const matCache = new Map();
function itemMat(type) {
  if (matCache.has(type)) return matCache.get(type);
  const d = ITEMS[type];
  const shiny = d.rar === 'golden' || (d.flags && (d.flags.includes('pu') || d.flags.includes('loot')));
  const m = new THREE.MeshStandardMaterial({ color: d.col, roughness: shiny ? 0.25 : 0.7, metalness: shiny ? 0.4 : 0.05, emissive: shiny ? d.col : '#000000', emissiveIntensity: shiny ? 0.35 : 0 });
  matCache.set(type, m);
  return m;
}

// ---- monsters ------------------------------------------------------------------------------------------------
function buildMonster(kind) {
  const g = new THREE.Group();
  const dark = new THREE.MeshStandardMaterial({ color: '#0d0c12', roughness: 1 });
  const pale = new THREE.MeshStandardMaterial({ color: '#d9d4c7', roughness: 0.9 });
  if (kind === 'stalker') {
    // tall, thin and faceless
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 1.5, 8), dark);
    body.position.y = 0.95;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.19, 10, 8), pale);
    head.scale.set(0.85, 1.15, 0.85);
    head.position.y = 1.95;
    g.add(body, head);
    for (const s of [-1, 1]) {
      const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.03, 1.3, 5), dark);
      arm.position.set(s * 0.26, 0.9, 0);
      arm.rotation.z = s * 0.06;
      g.add(arm);
    }
  } else {
    // low and long limbed with two small white eyes
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.4, 10, 8), dark);
    body.scale.set(1.2, 0.7, 1.5);
    body.position.y = 0.55;
    g.add(body);
    for (let i = 0; i < 4; i++) {
      const limb = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.03, 1.1, 5), dark);
      limb.position.set(i % 2 ? 0.45 : -0.45, 0.5, i < 2 ? 0.4 : -0.4);
      limb.rotation.z = i % 2 ? -0.7 : 0.7;
      g.add(limb);
    }
    const eyeM = new THREE.MeshBasicMaterial({ color: '#ffffff' });
    for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 5), eyeM); e.position.set(s * 0.12, 0.62, 0.58); g.add(e); }
  }
  g.userData.kind = kind;
  return g;
}

function nameTag(text, color = '#ffffff') {
  const c = document.createElement('canvas');
  c.width = 256; c.height = 64;
  const x = c.getContext('2d');
  x.font = 'bold 34px system-ui, sans-serif';
  x.textAlign = 'center';
  x.textBaseline = 'middle';
  x.fillStyle = 'rgba(0,0,0,0.55)';
  x.fillRect(8, 8, 240, 48);
  x.fillStyle = color;
  x.fillText(text.slice(0, 14), 128, 33);
  const tex = new THREE.CanvasTexture(c);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
  s.scale.set(0.55, 0.14, 1);
  s.renderOrder = 10;
  s.userData.text = text;
  s.userData.color = color;
  return s;
}

export class World {
  constructor(scene) {
    this.scene = scene;
    this.root = new THREE.Group();
    scene.add(this.root);
    this.dyn = new Map(); // collider id -> mesh
    this.itemMeshes = new Map();
    this.entMeshes = new Map();
    this.players = new Map();
    this.puffs = [];
    this.info = null;
    this.arena = null;
    this.localId = null;
    this.flash = null;
    this.t = 0;
    this.lights = [];
    this.roster = new Map(); // player id -> { name, cos }
  }

  clear() {
    for (const o of [...this.root.children]) {
      this.root.remove(o);
      o.traverse((n) => { if (n.geometry && !geoCache.has(n.userData.gk)) n.geometry.dispose(); });
    }
    this.dyn.clear(); this.itemMeshes.clear(); this.entMeshes.clear(); this.puffs = []; this.flash = null; this.lights = [];
    this.scene.background = null;
  }

  // info: { mode, kind, theme, seed, level }
  load(info) {
    this.clear();
    this.info = info;
    const a = info.kind === 'backrooms' ? buildBackroomsLevel(info.level || 1, info.seed) : buildArena(info.kind, info.theme, info.seed);
    a.colliders.forEach((c, i) => { c.id = i; });
    this.arena = a;
    const th = a.theme;
    const dark = !!th.dark || ['space', 'attic', 'night', 'volcano', 'market'].includes(info.theme);
    this.dark = !!th.dark;
    this.scene.background = new THREE.Color(th.sky);
    this.scene.fog = new THREE.Fog(th.fog, this.dark ? 3 : 28, this.dark ? 15 : 95);

    const hemi = new THREE.HemisphereLight(th.sky, th.floor, this.dark ? 0.35 : dark ? 0.7 : 1.0);
    this.root.add(hemi);
    if (!this.dark) { const sun = new THREE.DirectionalLight('#ffffff', dark ? 0.5 : 0.8); sun.position.set(20, 40, 10); this.root.add(sun); }
    // a soft light that follows the player so dark levels are not pitch black
    this.glow = new THREE.PointLight('#ffe9b0', this.dark ? 0.9 : 0.0, 9, 1.6);
    this.root.add(this.glow);
    this.flashSpot = new THREE.SpotLight('#fff6d0', 0, 18, 0.45, 0.5, 1);
    this.flashSpot.target = new THREE.Object3D();
    this.root.add(this.flashSpot, this.flashSpot.target);

    // static geometry, merged
    const stat = [], pal = { floor: th.floor, platform: th.platform, wall: th.wall, accent: th.accent, door: '#5b3a1f' };
    for (const c of a.colliders) {
      if (c.dyn) { this.addDyn(c, th); continue; }
      stat.push({ min: c.min, max: c.max, color: pal[c.c] || th.platform, shade: 0.94 + hash(c.id) * 0.12 });
    }
    if (stat.length) {
      const mesh = new THREE.Mesh(mergeBoxes(stat), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, flatShading: true }));
      this.root.add(mesh);
    }

    // props
    this.buildProps(a, th);
    // lava and water
    if (a.lava) {
      this.lava = new THREE.Mesh(new THREE.PlaneGeometry(220, 220), new THREE.MeshBasicMaterial({ color: '#ff5a1f' }));
      this.lava.rotation.x = -Math.PI / 2;
      this.lava.position.y = a.lava.y0;
      this.root.add(this.lava);
    } else this.lava = null;
    if (a.waterY !== undefined) {
      this.water = new THREE.Mesh(new THREE.PlaneGeometry(220, 220), new THREE.MeshStandardMaterial({ color: th.water ? '#3bc9db' : '#1c7ed6', transparent: true, opacity: 0.42, roughness: 0.2 }));
      this.water.rotation.x = -Math.PI / 2;
      this.water.position.y = a.waterY;
      this.root.add(this.water);
    } else this.water = null;
    if (['night', 'space', 'attic'].includes(info.theme)) this.stars();
    this.terminalMesh = null;
    return a;
  }

  stars() {
    const p = [];
    for (let i = 0; i < 400; i++) { const a = hash(i) * TAU, b = hash(i + 999) * 0.9 + 0.1, r = 150; p.push(Math.cos(a) * r * b, 30 + hash(i + 5) * 120, Math.sin(a) * r * b); }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3));
    this.root.add(new THREE.Points(g, new THREE.PointsMaterial({ color: '#ffffff', size: 1.2, sizeAttenuation: false })));
  }

  addDyn(c, th) {
    const pal = { door: '#5b3a1f', platform: th.platform, accent: th.accent, wall: th.wall };
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial({ color: c.mat === 'ice' ? '#a5d8ff' : (pal[c.c] || th.platform), roughness: c.mat === 'ice' ? 0.15 : 0.9, transparent: c.mat === 'ice', opacity: c.mat === 'ice' ? 0.75 : 1 }));
    this.setBox(mesh, c.min, c.max);
    this.root.add(mesh);
    this.dyn.set(c.id, mesh);
  }

  setBox(mesh, min, max) {
    mesh.position.set((min[0] + max[0]) / 2, (min[1] + max[1]) / 2, (min[2] + max[2]) / 2);
    mesh.scale.set(Math.max(0.001, max[0] - min[0]), Math.max(0.001, max[1] - min[1]), Math.max(0.001, max[2] - min[2]));
  }

  buildProps(a, th) {
    const std = (c, r = 0.8) => new THREE.MeshStandardMaterial({ color: c, roughness: r });
    const lights = [];
    for (const p of a.props) {
      let m = null;
      const s = p.s || [1, 1, 1];
      switch (p.k) {
        case 'light': lights.push(p); break;
        case 'desk': m = new THREE.Mesh(new THREE.BoxGeometry(...s), std('#6d4c8f')); break;
        case 'monitor': m = new THREE.Mesh(new THREE.BoxGeometry(...s), std('#15131f', 0.4)); break;
        case 'pad': m = new THREE.Mesh(new THREE.CylinderGeometry(3.6, 3.6, 0.06, 24), std('#ffd43b', 0.5)); break;
        case 'hoop': { m = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.03, 6, 18), std('#ff6b3d')); m.rotation.x = Math.PI / 2; break; }
        case 'trophywall': m = new THREE.Mesh(new THREE.BoxGeometry(...s), std('#2f2b57')); break;
        case 'photobooth': m = new THREE.Mesh(new THREE.BoxGeometry(...s), std('#f06595')); break;
        case 'claw': m = new THREE.Mesh(new THREE.BoxGeometry(...s), std('#4dabf7', 0.4)); m.material.transparent = true; m.material.opacity = 0.7; break;
        case 'socket': { m = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.4, 1.2, 8), std('#3b3b46', 0.5)); const gl = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 6), new THREE.MeshBasicMaterial({ color: '#7be0c3' })); gl.position.y = 0.8; m.add(gl); break; }
        case 'exitdoor': { m = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.01), new THREE.MeshBasicMaterial({ color: '#7be0c3', transparent: true, opacity: 0.0 })); break; }
        case 'flower': { m = new THREE.Mesh(new THREE.ConeGeometry(0.35, 0.9, 6), std('#ff8fab')); break; }
        case 'lollipop': case 'gumdrop': m = new THREE.Mesh(new THREE.SphereGeometry(0.6, 8, 6), std('#ff7eb3')); break;
        case 'abcblock': case 'toycar': case 'crate': m = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.9, 0.9), std('#ffd43b')); break;
        case 'pod': case 'antenna': m = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.3, s[1], 6), std('#8a94a6')); break;
        case 'coral': case 'stall': m = new THREE.Mesh(new THREE.ConeGeometry(0.4, 1.4, 5), std('#ff6b81')); break;
        case 'rock': case 'ember': m = new THREE.Mesh(new THREE.DodecahedronGeometry(0.6, 0), std('#4a3a35')); break;
        case 'lamp': case 'banner': m = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.4, 5), std('#5f6f94')); break;
        default: break;
      }
      if (!m) continue;
      m.position.set(...p.pos);
      if (p.rot) m.rotation.y = p.rot;
      if (p.k === 'flower' || p.k === 'lollipop' || p.k === 'gumdrop' || p.k === 'coral' || p.k === 'stall' || p.k === 'rock' || p.k === 'ember' || p.k === 'lamp' || p.k === 'banner' || p.k === 'pod' || p.k === 'antenna' || p.k === 'abcblock' || p.k === 'toycar' || p.k === 'crate') m.position.y = (s[1] ? s[1] / 2 : 0.5);
      this.root.add(m);
      if (p.k === 'socket') this.socketMesh = m;
      if (p.k === 'exitdoor') this.exitMesh = m;
    }
    // ceiling light panels (backrooms): one merged mesh of bright boxes
    if (lights.length) {
      const boxes = lights.map((p) => ({ min: [p.pos[0] - 0.6, p.pos[1] - 0.03, p.pos[2] - 0.25], max: [p.pos[0] + 0.6, p.pos[1] + 0.01, p.pos[2] + 0.25], color: th.dark ? '#cdd8ff' : '#fff7d0', shade: 1 }));
      this.panels = new THREE.Mesh(mergeBoxes(boxes), new THREE.MeshBasicMaterial({ vertexColors: true, fog: false }));
      this.root.add(this.panels);
    }
    // terminal: a canvas screen drawn by the UI module
    if (a.terminal) {
      const geo = new THREE.PlaneGeometry(a.terminal.size[0], a.terminal.size[1]);
      this.terminalMesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: '#ffffff' }));
      this.terminalMesh.position.set(...a.terminal.pos);
      this.root.add(this.terminalMesh);
    }
  }

  // ---- per frame -----------------------------------------------------------------------------------------------
  update(snap, dt, camPos, held) {
    this.t += dt;
    const k = 1 - Math.exp(-14 * dt);
    if (this.glow) this.glow.position.set(camPos[0], camPos[1] + 0.2, camPos[2]);
    if (this.lava && snap.lv !== null && snap.lv !== undefined) {
      this.lava.position.y = snap.lv;
      const pulse = 0.5 + 0.5 * Math.sin(this.t * 3);
      this.lava.material.color.setRGB(1, 0.28 + 0.12 * pulse, 0.08);
    }
    // dynamic colliders (doors, crumbling platforms, ice)
    if (snap.dc) {
      for (const d of snap.dc) {
        const [id, on, x0, y0, z0, x1, y1, z1] = d;
        let m = this.dyn.get(id);
        if (!m) { m = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial({ color: '#a5d8ff', transparent: true, opacity: 0.75, roughness: 0.15 })); this.root.add(m); this.dyn.set(id, m); }
        m.visible = !!on;
        this.setBox(m, [x0, y0, z0], [x1, y1, z1]);
      }
    }
    // items
    const seen = new Set();
    let flashOn = null;
    for (const it of snap.it) {
      const def = ITEMS[it.t];
      if (!def) continue;
      seen.add(it.i);
      let o = this.itemMeshes.get(it.i);
      if (!o) {
        const mesh = new THREE.Mesh(itemGeo(it.t), itemMat(it.t));
        mesh.userData.type = it.t;
        this.root.add(mesh);
        o = { mesh, p: it.p.slice() };
        this.itemMeshes.set(it.i, o);
      }
      const held_ = held && held.has(it.i) ? held.get(it.i) : null;
      const tp = held_ || it.p;
      const kk = held_ ? 1 : k;
      o.p[0] = lerp(o.p[0], tp[0], kk); o.p[1] = lerp(o.p[1], tp[1], kk); o.p[2] = lerp(o.p[2], tp[2], kk);
      const pu = it.t.startsWith('pu_') || def.rar === 'golden' || (def.flags && def.flags.includes('loot'));
      const bob = pu && !it.h ? Math.sin(this.t * 2.5 + it.i) * 0.04 : 0;
      o.mesh.position.set(o.p[0], o.p[1] + bob, o.p[2]);
      if (pu && !it.h) o.mesh.rotation.y += dt * 1.5;
      if (it.s !== undefined) o.mesh.material.emissive && (o.mesh.material = this.heatMat(o.mesh, it.s));
      if (it.t === 'flashlight' && it.on) flashOn = o.mesh;
    }
    for (const [id, o] of this.itemMeshes) if (!seen.has(id)) { this.root.remove(o.mesh); this.itemMeshes.delete(id); }
    // a lit flashlight shines a cone
    if (flashOn) {
      this.flashSpot.intensity = 2.2;
      this.flashSpot.position.copy(flashOn.position);
      const q = flashOn.getWorldDirection ? new THREE.Vector3(0, 0, -1) : null;
      const dir = new THREE.Vector3(camPos[0] - flashOn.position.x, 0, camPos[2] - flashOn.position.z);
      this.flashSpot.target.position.set(flashOn.position.x - dir.x * 6, flashOn.position.y - 0.2, flashOn.position.z - dir.z * 6);
    } else if (this.flashSpot) this.flashSpot.intensity = 0;
    // monsters and other entities
    const eseen = new Set();
    for (const e of snap.en || []) {
      eseen.add(e.i);
      let o = this.entMeshes.get(e.i);
      if (!o) {
        const g = e.k === 'stalker' || e.k === 'lurker' ? buildMonster(e.k) : buildMonster('lurker');
        this.root.add(g);
        o = { g, p: e.p.slice(), y: e.y };
        this.entMeshes.set(e.i, o);
      }
      o.p[0] = lerp(o.p[0], e.p[0], k); o.p[1] = lerp(o.p[1], e.p[1], k); o.p[2] = lerp(o.p[2], e.p[2], k);
      o.y = e.y;
      o.g.position.set(o.p[0], o.p[1] - 1.0, o.p[2]);
      o.g.rotation.y = -o.y + Math.PI / 2;
      const sc = e.sc || 1;
      o.g.scale.set(sc, sc, sc);
      o.g.visible = e.s !== 'dead';
      const sway = Math.sin(this.t * (e.s === 'chase' || e.s === 'lunge' ? 14 : 4) + e.i) * 0.05;
      o.g.rotation.z = sway;
      if (e.s === 'lunge') o.g.position.y -= 0.15;
    }
    for (const [id, o] of this.entMeshes) if (!eseen.has(id)) { this.root.remove(o.g); this.entMeshes.delete(id); }
    // smoke zones
    this.updateSmoke(snap.zn || []);
    // puffs
    for (let i = this.puffs.length - 1; i >= 0; i--) {
      const p = this.puffs[i];
      p.life -= dt;
      if (p.life <= 0) { this.root.remove(p.mesh); this.puffs.splice(i, 1); continue; }
      const f = 1 - p.life / p.max;
      p.mesh.scale.setScalar(p.size * (0.3 + f * 1.4));
      p.mesh.material.opacity = (1 - f) * 0.8;
      p.mesh.position.y += dt * (p.rise || 0);
    }
  }

  heatMat(mesh, heat) {
    if (!mesh.userData.hot) mesh.userData.hot = mesh.material.clone();
    mesh.userData.hot.emissive = mesh.userData.hot.emissive || new THREE.Color();
    mesh.userData.hot.emissive.setRGB(heat, heat * 0.15, 0);
    mesh.userData.hot.emissiveIntensity = 0.4 + heat;
    return mesh.userData.hot;
  }

  updateSmoke(zones) {
    this.smoke = this.smoke || new Map();
    const seen = new Set();
    for (const z of zones) {
      if (z.kind !== 'smoke') continue;
      seen.add(z.id);
      if (!this.smoke.has(z.id)) {
        const m = new THREE.Mesh(new THREE.SphereGeometry(1, 10, 8), new THREE.MeshBasicMaterial({ color: '#b0b4bd', transparent: true, opacity: 0.55, depthWrite: false }));
        m.position.set((z.min[0] + z.max[0]) / 2, (z.min[1] + z.max[1]) / 2, (z.min[2] + z.max[2]) / 2);
        m.scale.setScalar((z.max[0] - z.min[0]) / 2);
        this.root.add(m);
        this.smoke.set(z.id, m);
      }
    }
    for (const [id, m] of this.smoke) if (!seen.has(id)) { this.root.remove(m); this.smoke.delete(id); }
  }

  puff(pos, color = '#ffffff', size = 0.6, life = 0.5, rise = 0) {
    if (this.puffs.length > 60) return;
    const m = new THREE.Mesh(new THREE.SphereGeometry(1, 8, 6), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.8, depthWrite: false }));
    m.position.set(pos[0], pos[1], pos[2]);
    this.root.add(m);
    this.puffs.push({ mesh: m, life, max: life, size, rise });
  }

  // server events that have a visual
  event(ev) {
    switch (ev.e) {
      case 'boom': this.puff(ev.pos, '#ff9a3d', 1.8, 0.7); this.puff(ev.pos, '#fff2a0', 1.0, 0.45); break;
      case 'confetti': for (let i = 0; i < 8; i++) this.puff([ev.pos[0] + (hash(i) - 0.5), ev.pos[1] + hash(i + 3), ev.pos[2] + (hash(i + 7) - 0.5)], ['#ff6b6b', '#ffd43b', '#4dabf7', '#69db7c'][i % 4], 0.2, 1.0, 1); break;
      case 'craft': this.puff(ev.pos, '#ffd43b', 0.7, 0.5, 0.6); break;
      case 'sfx':
        if (ev.k === 'pickup') this.puff(ev.pos, '#7be0c3', 0.5, 0.4, 0.8);
        else if (ev.k === 'shatter') this.puff(ev.pos, '#a5d8ff', 0.5, 0.4);
        else if (ev.k === 'thud' && ev.v > 0.5) this.puff(ev.pos, '#e9e2d0', 0.25, 0.3);
        break;
      default: break;
    }
  }

  // ---- other players -------------------------------------------------------------------------------------------
  updatePlayers(snap, localId, dt, tags = true) {
    const k = 1 - Math.exp(-16 * dt);
    const seen = new Set();
    for (const p of snap.pl) {
      if (p.i === localId) continue;
      seen.add(p.i);
      let o = this.players.get(p.i);
      const rs = this.roster.get(p.i) || { name: 'Player', cos: {} };
      const cosKey = JSON.stringify(rs.cos || {});
      if (o && o.cosKey !== cosKey) { this.root.remove(o.av.root); this.root.remove(o.tag); this.players.delete(p.i); o = null; }
      if (!o) {
        const av = buildAvatar(rs.cos || {});
        this.root.add(av.root);
        const tag = nameTag(rs.name || 'Player');
        this.root.add(tag);
        o = { av, tag, h: null, l: null, r: null, yaw: p.y, root: p.p.slice(), cosKey };
        this.players.set(p.i, o);
      }
      const wp = (rel) => [p.p[0] + rel[0], p.p[1] + rel[1], p.p[2] + rel[2]];
      const th = wp(p.h), tl = wp(p.l), tr = wp(p.r);
      if (!o.h) { o.h = th; o.l = tl; o.r = tr; }
      for (let i = 0; i < 3; i++) { o.h[i] = lerp(o.h[i], th[i], k); o.l[i] = lerp(o.l[i], tl[i], k); o.r[i] = lerp(o.r[i], tr[i], k); }
      let dy = p.y - o.yaw;
      while (dy > Math.PI) dy -= TAU;
      while (dy < -Math.PI) dy += TAU;
      o.yaw += dy * k;
      o.av.root.visible = p.a === 1;
      o.av.update(o.h, o.l, o.r, o.yaw);
      const it = p.ro === 'it';
      o.av.setGlow(it, '#ff4d4d');
      o.av.setCoreColor(p.ro === 'it' ? '#ff4d4d' : ['#ff6b6b', '#4dabf7', '#ffd43b', '#69db7c'][p.t % 4] || '#7be0c3');
      const label = (rs.name || 'Player') + (p.fx && p.fx.includes('frozen') ? ' (frozen)' : '');
      if (o.tag.userData.text !== label) { this.root.remove(o.tag); o.tag = nameTag(label, it ? '#ff8a8a' : '#ffffff'); this.root.add(o.tag); }
      o.tag.visible = tags && p.a === 1;
      o.tag.position.set(o.h[0], o.h[1] + 0.45, o.h[2]);
    }
    for (const [id, o] of this.players) if (!seen.has(id)) { this.root.remove(o.av.root); this.root.remove(o.tag); this.players.delete(id); }
  }

  dispose() { this.clear(); this.scene.remove(this.root); }
}
