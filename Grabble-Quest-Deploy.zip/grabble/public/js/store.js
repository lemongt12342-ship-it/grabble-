// Saves the player's name, look and settings in this browser. Nothing here is sent anywhere except the
// name and look, which are shared with other players in a room. Every access is wrapped because browser
// storage can be missing or blocked (private windows, some headset browsers).

import { DEFAULT_COS } from '../../shared/cosmetics.js';
import { cleanName } from '../../shared/util.js';

const KEY = 'grabble.profile.v1';
export const DEFAULT_SETTINGS = { volume: 0.7, vignette: true, names: true, kid: false, handed: 'right' };

export function loadProfile() {
  let raw = null;
  try { raw = JSON.parse(localStorage.getItem(KEY)); } catch { raw = null; }
  const p = raw && typeof raw === 'object' ? raw : {};
  return {
    name: cleanName(p.name, 'Grabber'),
    cos: sanitizeCos({ ...DEFAULT_COS, ...(p.cos || {}) }),
    settings: { ...DEFAULT_SETTINGS, ...(p.settings && typeof p.settings === 'object' ? p.settings : {}) },
    best: p.best && typeof p.best === 'object' ? p.best : {},
  };
}

export function saveProfile(p) {
  try { localStorage.setItem(KEY, JSON.stringify(p)); } catch { /* storage unavailable: settings last for this visit only */ }
}

const HEX = /^#[0-9a-fA-F]{6}$/;
export function sanitizeCos(c) {
  const out = {};
  for (const k of ['fur', 'accent', 'pad', 'eyes']) out[k] = HEX.test(c[k]) ? c[k] : DEFAULT_COS[k];
  for (const k of ['glove', 'hat', 'trail']) out[k] = typeof c[k] === 'string' && /^[a-z0-9_]{1,24}$/.test(c[k]) ? c[k] : DEFAULT_COS[k];
  return out;
}
