// The spawn computer. A touch screen drawn on a canvas: solo play, create a room, join with a code,
// leave a room, change name and colours, settings. Used on the in-world monitor and as a floating panel
// you can call up anywhere (Tab on screen, the left X/Y button in VR).
//
// The logic here is a plain state machine with no DOM or Three.js dependency, so it can be tested in Node.
// click(x, y) takes pixel coordinates on the 1024x640 screen. Anything the game must do is reported through
// the onAction callback as a small object, e.g. { a: 'join', code: 'ABCDE' }.

import { MODES, MODE_IDS } from '../../shared/modes/index.js';
import { HATS, FUR_COLORS, FACE_COLORS, PAD_COLORS, EYE_COLORS, DEFAULT_COS } from '../../shared/cosmetics.js';

export const W = 1024, H = 640;
export const CODE_LETTERS = 'ABCDEFGHJKLMNPQRSTUVWXYZ'.split(''); // matches the server (no I or O)
export const NAME_LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'.split('');
const DIFFS = ['chill', 'normal', 'hard'];
const SOLO_MODES = MODE_IDS.filter((m) => MODES[m].min <= 1 || true);

export class Terminal {
  constructor({ profile, onAction = () => {}, connected = false }) {
    this.profile = profile;
    this.onAction = onAction;
    this.connected = connected;
    this.screen = 'home';
    this.code = '';
    this.msg = '';
    this.room = null; // { code, host, players, mode, phase } when in a room
    this.sel = { mode: 'tag', level: 1, diff: 'normal', daily: false, bots: 3, priv: false };
    this.page = 0;
    this.tab = 'fur';
    this.nameDraft = profile.name;
    this.buttons = [];
    this.dirty = true;
  }

  setRoom(room) { this.room = room; if (room && ['join', 'create', 'solo'].includes(this.screen)) this.screen = 'lobby'; if (!room && this.screen === 'lobby') this.screen = 'home'; this.dirty = true; }
  setMessage(m) { this.msg = m || ''; this.dirty = true; }
  go(s) { this.screen = s; this.msg = ''; this.dirty = true; }

  // ---- input ----
  click(x, y) {
    for (const b of this.buttons) {
      if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) { if (!b.off) { b.fn(); this.dirty = true; return true; } return false; }
    }
    return false;
  }

  key(ch) { // physical keyboard, handy on screen
    if (this.screen === 'join') {
      if (ch === 'Backspace') this.code = this.code.slice(0, -1);
      else if (ch === 'Enter') this.doJoin();
      else if (/^[a-zA-Z]$/.test(ch) && this.code.length < 5) this.code += ch.toUpperCase();
      this.dirty = true;
    } else if (this.screen === 'name') {
      if (ch === 'Backspace') this.nameDraft = this.nameDraft.slice(0, -1);
      else if (ch === 'Enter') this.saveName();
      else if (/^[a-zA-Z0-9 ]$/.test(ch) && this.nameDraft.length < 14) this.nameDraft += ch.toUpperCase();
      this.dirty = true;
    }
  }

  doJoin() {
    if (!/^[A-Z]{5}$/.test(this.code)) { this.msg = 'Codes are 5 letters.'; return; }
    this.msg = 'Joining...';
    this.onAction({ a: 'join', code: this.code });
  }

  saveName() {
    const n = this.nameDraft.trim();
    if (n.length < 2) { this.msg = 'Pick a name with at least 2 characters.'; return; }
    this.profile.name = n;
    this.onAction({ a: 'name', name: n });
    this.go('custom');
  }

  setCos(k, v) {
    this.profile.cos = { ...this.profile.cos, [k]: v };
    this.onAction({ a: 'cos', cos: this.profile.cos });
  }

  // ---- layout ----
  btn(x, y, w, h, label, fn, o = {}) { this.buttons.push({ x, y, w, h, label, fn, ...o }); }

  layout() {
    this.buttons = [];
    const s = this.screen;
    const back = () => this.btn(24, 560, 150, 56, 'Back', () => this.go(this.room ? 'lobby' : 'home'), { style: 'dim' });
    if (s === 'home') {
      const items = this.room
        ? [['Room ' + this.room.code, () => this.go('lobby')], ['Customize', () => this.go('custom')], ['Settings', () => this.go('settings')], ['Leave Room', () => { this.onAction({ a: 'leave' }); }]]
        : [['Play Solo', () => this.go('solo')], ['Create Room', () => this.go('create')], ['Join Code', () => { this.code = ''; this.go('join'); }], ['Customize', () => this.go('custom')], ['Settings', () => this.go('settings')]];
      items.forEach(([l, f], i) => this.btn(312, 130 + i * 84, 400, 68, l, f, { off: !this.connected && (l === 'Create Room' || l === 'Join Code'), sub: !this.connected && (l === 'Create Room' || l === 'Join Code') ? 'no server' : '' }));
    } else if (s === 'join') {
      CODE_LETTERS.forEach((c, i) => this.btn(212 + (i % 8) * 76, 200 + Math.floor(i / 8) * 76, 68, 68, c, () => { if (this.code.length < 5) this.code += c; }));
      this.btn(212, 450, 220, 64, 'Delete', () => { this.code = this.code.slice(0, -1); }, { style: 'dim' });
      this.btn(592, 450, 220, 64, 'Join', () => this.doJoin(), { style: 'go' });
      back();
    } else if (s === 'solo' || s === 'create') {
      this.modePicker(s);
      back();
    } else if (s === 'custom') {
      ['fur', 'accent', 'pad', 'eyes', 'hat'].forEach((t, i) => this.btn(24 + i * 110, 90, 104, 50, { fur: 'Fur', accent: 'Face', pad: 'Pads', eyes: 'Eyes', hat: 'Hat' }[t], () => { this.tab = t; }, { on: this.tab === t }));
      const list = { fur: FUR_COLORS, accent: FACE_COLORS, pad: PAD_COLORS, eyes: EYE_COLORS, hat: HATS }[this.tab];
      list.forEach((v, i) => this.btn(24 + (i % 6) * 104, 170 + Math.floor(i / 6) * 104, 96, 96, this.tab === 'hat' ? v : '', () => this.setCos(this.tab, v), { swatch: this.tab === 'hat' ? null : v, on: this.profile.cos[this.tab] === v }));
      this.btn(660, 90, 340, 56, 'Name: ' + this.profile.name, () => { this.nameDraft = this.profile.name; this.go('name'); });
      this.btn(660, 156, 340, 56, 'Reset look', () => { this.profile.cos = { ...DEFAULT_COS }; this.onAction({ a: 'cos', cos: this.profile.cos }); }, { style: 'dim' });
      back();
    } else if (s === 'name') {
      NAME_LETTERS.forEach((c, i) => this.btn(64 + (i % 12) * 74, 190 + Math.floor(i / 12) * 76, 66, 66, c, () => { if (this.nameDraft.length < 14) this.nameDraft += c; }));
      this.btn(64, 450, 200, 64, 'Delete', () => { this.nameDraft = this.nameDraft.slice(0, -1); }, { style: 'dim' });
      this.btn(752, 450, 200, 64, 'Save', () => this.saveName(), { style: 'go' });
      this.btn(24, 560, 150, 56, 'Back', () => this.go('custom'), { style: 'dim' });
    } else if (s === 'settings') {
      const st = this.profile.settings;
      const row = (i, label, fn) => this.btn(212, 120 + i * 76, 600, 64, label, fn);
      row(0, `Volume: ${Math.round(st.volume * 100)}%`, () => { st.volume = st.volume >= 1 ? 0 : Math.round((st.volume + 0.25) * 100) / 100; this.onAction({ a: 'settings' }); });
      row(1, `Name tags: ${st.names ? 'on' : 'off'}`, () => { st.names = !st.names; this.onAction({ a: 'settings' }); });
      row(2, `Comfort vignette: ${st.vignette ? 'on' : 'off'}`, () => { st.vignette = !st.vignette; this.onAction({ a: 'settings' }); });
      row(3, `Kid-safe rooms: ${st.kid ? 'on' : 'off'}`, () => { st.kid = !st.kid; this.onAction({ a: 'settings' }); });
      row(4, `Dominant hand: ${st.handed}`, () => { st.handed = st.handed === 'right' ? 'left' : 'right'; this.onAction({ a: 'settings' }); });
      back();
    } else if (s === 'lobby') {
      const r = this.room;
      if (r) {
        this.btn(24, 560, 220, 56, 'Leave Room', () => this.onAction({ a: 'leave' }), { style: 'dim' });
        this.btn(660, 90, 340, 56, 'Ready / Unready', () => this.onAction({ a: 'ready' }));
        this.btn(660, 156, 340, 56, r.host ? 'Start Match' : 'Host starts', () => this.onAction({ a: 'start' }), { off: !r.host, style: 'go' });
        this.btn(660, 222, 340, 56, 'Customize', () => this.go('custom'), { style: 'dim' });
      } else back();
    }
  }

  modePicker(s) {
    const ids = s === 'solo' ? SOLO_MODES : MODE_IDS.filter((m) => m !== 'sandbox' || true);
    const per = 8;
    const pages = Math.ceil(ids.length / per);
    this.page = Math.min(this.page, pages - 1);
    ids.slice(this.page * per, this.page * per + per).forEach((m, i) => this.btn(24 + (i % 2) * 260, 90 + Math.floor(i / 2) * 76, 252, 68, MODES[m].name, () => { this.sel.mode = m; }, { on: this.sel.mode === m }));
    if (pages > 1) { this.btn(24, 400, 120, 48, '< Page', () => { this.page = (this.page + pages - 1) % pages; }, { style: 'dim' }); this.btn(152, 400, 120, 48, 'Page >', () => { this.page = (this.page + 1) % pages; }, { style: 'dim' }); }
    const o = this.sel;
    if (o.mode === 'backrooms') {
      this.btn(560, 90, 440, 56, `Level ${o.level}: ${'The Lobby,Pipe Dreams,The Poolrooms,Parking Garage,Office Floors,The Warehouse,Lights Out,The Sewers,The Void'.split(',')[o.level - 1]}`, () => { o.level = (o.level % 9) + 1; });
    }
    this.btn(560, 156, 440, 56, 'Difficulty: ' + o.diff, () => { o.diff = DIFFS[(DIFFS.indexOf(o.diff) + 1) % 3]; });
    this.btn(560, 222, 440, 56, 'Daily seed: ' + (o.daily ? 'on' : 'off'), () => { o.daily = !o.daily; });
    if (s === 'solo') this.btn(560, 288, 440, 56, 'Bots: ' + o.bots, () => { o.bots = (o.bots + 1) % 7; });
    else this.btn(560, 288, 440, 56, 'Private room: ' + (o.priv ? 'yes' : 'no'), () => { o.priv = !o.priv; });
    this.btn(560, 450, 440, 72, s === 'solo' ? 'Start' : 'Create', () => {
      const cfg = { mode: o.mode, difficulty: o.diff, daily: o.daily, kid: !!this.profile.settings.kid };
      if (o.mode === 'backrooms') cfg.level = o.level;
      if (s === 'solo') this.onAction({ a: 'solo', ...cfg, bots: o.bots });
      else { cfg.priv = o.priv; cfg.bots = 0; this.onAction({ a: 'create', ...cfg }); }
    }, { style: 'go' });
  }

  // ---- drawing (browser only) ----
  attach(canvas) { this.canvas = canvas; this.ctx = canvas.getContext('2d'); this.draw(); }

  draw() {
    this.layout();
    const g = this.ctx;
    if (!g) return;
    g.clearRect(0, 0, W, H);
    g.fillStyle = '#10142a'; g.fillRect(0, 0, W, H);
    g.fillStyle = '#1b2147'; g.fillRect(0, 0, W, 72);
    g.fillStyle = '#ffb347'; g.font = 'bold 36px system-ui, sans-serif'; g.textBaseline = 'middle';
    g.fillText('GRABBLE TERMINAL', 24, 38);
    g.font = '22px system-ui, sans-serif'; g.fillStyle = '#9fe8d0'; g.textAlign = 'right';
    g.fillText(this.room ? `Room ${this.room.code}` : (this.connected ? 'online' : 'offline: solo only'), W - 24, 38);
    g.textAlign = 'left';
    const title = { home: '', join: 'Enter a room code', solo: 'Play solo', create: 'Create a room', custom: 'Customize', name: 'Your name', settings: 'Settings', lobby: 'Lobby' }[this.screen];
    if (title) { g.fillStyle = '#cfc9ff'; g.font = 'bold 26px system-ui, sans-serif'; g.fillText(title, 24, 110 - (this.screen === 'custom' || this.screen === 'solo' || this.screen === 'create' ? 30 : 0) + (this.screen === 'custom' ? 0 : 0)); }
    if (this.screen === 'join') { g.fillStyle = '#fff'; g.font = 'bold 64px ui-monospace, monospace'; g.textAlign = 'center'; g.fillText((this.code + '_____').slice(0, 5).split('').join(' '), W / 2, 150); g.textAlign = 'left'; }
    if (this.screen === 'name') { g.fillStyle = '#fff'; g.font = 'bold 56px ui-monospace, monospace'; g.textAlign = 'center'; g.fillText(this.nameDraft || '_', W / 2, 140); g.textAlign = 'left'; }
    if (this.screen === 'lobby' && this.room) {
      g.font = '26px system-ui, sans-serif';
      (this.room.players || []).slice(0, 10).forEach((p, i) => { g.fillStyle = p.ready ? '#9fe8d0' : '#d6d1ff'; g.fillText(`${p.ready ? '✓' : '•'} ${p.name}${p.id === this.room.hostId ? ' (host)' : ''}`, 24, 150 + i * 36); });
      g.fillStyle = '#ffb347'; g.fillText(`${MODES[this.room.mode]?.name || this.room.mode}`, 660, 330);
      g.fillStyle = '#b9b3e6'; g.font = '20px system-ui, sans-serif'; g.fillText('Share the code so friends can join.', 660, 366);
    }
    if (this.screen === 'solo' || this.screen === 'create') {
      g.fillStyle = '#b9b3e6'; g.font = '20px system-ui, sans-serif';
      const m = MODES[this.sel.mode];
      wrap(g, m ? m.desc : '', 24, 490, 500, 26);
    }
    for (const b of this.buttons) this.drawButton(g, b);
    if (this.msg) { g.fillStyle = '#ffd43b'; g.font = '22px system-ui, sans-serif'; g.textAlign = 'center'; g.fillText(this.msg, W / 2, 540); g.textAlign = 'left'; }
    this.dirty = false;
    if (this.texture) this.texture.needsUpdate = true;
  }

  drawButton(g, b) {
    const bg = b.off ? '#2a2e4d' : b.style === 'go' ? '#2f9e6a' : b.style === 'dim' ? '#34396a' : b.on ? '#ffb347' : '#3f46a0';
    if (b.hot) { g.fillStyle = '#fff'; g.fillRect(b.x - 3, b.y - 3, b.w + 6, b.h + 6); }
    g.fillStyle = b.swatch || bg;
    roundRect(g, b.x, b.y, b.w, b.h, 12); g.fill();
    if (b.on) { g.strokeStyle = '#fff'; g.lineWidth = 4; roundRect(g, b.x, b.y, b.w, b.h, 12); g.stroke(); }
    if (b.label) {
      g.fillStyle = b.on && !b.swatch ? '#2a1b00' : b.off ? '#7a7fa8' : '#fff';
      g.font = `bold ${b.h < 60 ? 22 : 26}px system-ui, sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(b.sub ? `${b.label} (${b.sub})` : b.label, b.x + b.w / 2, b.y + b.h / 2);
      g.textAlign = 'left';
    }
  }

  // Convert a hit on the screen's uv (0..1, origin top-left) to a click.
  clickUV(u, v) { return this.click(u * W, v * H); }
  hover(u, v) {
    const x = u * W, y = v * H;
    let changed = false;
    for (const b of this.buttons) { const h = x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h; if (!!b.hot !== h) { b.hot = h; changed = true; } }
    if (changed && this.ctx) this.draw();
  }
}

function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
function wrap(g, text, x, y, maxW, lh) {
  let line = '';
  for (const word of text.split(' ')) {
    const t = line ? line + ' ' + word : word;
    if (g.measureText(t).width > maxW && line) { g.fillText(line, x, y); y += lh; line = word; } else line = t;
  }
  if (line) g.fillText(line, x, y);
}
