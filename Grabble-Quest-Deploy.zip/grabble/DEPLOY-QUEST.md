# Grabble - Meta Quest 3 deployment

## What this package is
Grabble is a WebXR browser game with a Node.js + WebSocket multiplayer server. The Quest 3 can run the VR experience in Meta Quest Browser after the game is hosted at an HTTPS address.

## Deploy the multiplayer game
1. Create a hosting account with a Node.js web-service provider that supports WebSockets and HTTPS (for example Render).
2. Create a new service from this project repository or upload the project to a Git repository first.
3. The included `render.yaml` provides the Node start command and health check for Render.
4. Wait for the provider to give the service an HTTPS URL.
5. Open that HTTPS URL in Meta Quest Browser on the Quest 3.
6. Press **Enter VR**.

The hosting account and deployment must be completed by the account owner. Do not publish private keys or passwords in this project.

## Test before publishing
- `npm test` runs the automated tests.
- `npm run check` checks JavaScript syntax.
- `npm start` starts the local server (defaults to localhost:8080).

## APK note
This is a WebXR game, not a native Unity/Unreal Android project. A PWA wrapper can create an Android APK, but the APK's embedded browser may not expose WebXR on Quest. The reliable first release path is the HTTPS game link in Meta Quest Browser. Test any APK on the headset before distributing it.
