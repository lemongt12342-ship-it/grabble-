# Grabble

A Gorilla Tag style VR party game for the browser (WebXR), with arm-swing movement, tag modes, rising lava
and Escape the Backrooms (9 levels, 2 monsters per level that get stronger as you go). Zero npm dependencies.

## What is and is not verified

Verified by automated tests (`npm test`, 69 tests): the shared physics and arm-swing movement, every game
mode running with bots, all 9 Backrooms levels being solvable with 2 scaling monsters each, the hardened
multiplayer server (malformed, oversized, flooded and spoofed traffic), client sessions with prediction, the
computer's menus (join code, name, colours) and the HUD logic.

**Not verified:** the Three.js rendering and the headset/controller code, because the build environment could
not download Three.js or run a headset. The first time you open it, expect to find visual or input bugs.
Built since: Vault Heist, Kitchen Rush, Conveyor Sort, Treasure Dive, Zombie Survival (8 waves) and Boss Fight, tested by rule-level unit tests (85 tests total). Not built: voice chat, an installable APK, persistent accounts, the level editor and the progression
systems (coins, season pass, trading); the plan for those is in "Roadmap".

## Run it

    node --version          # 20 or newer
    npm run setup           # optional: downloads Three.js so the game does not need a CDN
    npm test                # optional
    PORT=8080 node server/server.js

Open http://localhost:8080 and press "Play on screen" (mouse look, W to swing along, Space to leap,
Q/E to grip, click to use, Tab for the computer).

## Play in a Quest headset

WebXR only works on **https** (or localhost), so the headset needs a secure address.

Option A, quick test over USB (no certificate needed):
1. Enable Developer Mode on the Quest and connect it by USB.
2. `adb reverse tcp:8080 tcp:8080`
3. In the Meta Quest Browser open `http://localhost:8080` and press **Enter VR**.

Option B, a real link to share (recommended):
1. Put the folder on any host that runs Node and gives you https (Render, Fly.io, Railway, a VPS behind Caddy or nginx).
2. Start it with `HOST=0.0.0.0 PORT=8080 TRUST_PROXY=1 node server/server.js` behind the https proxy, or give it a
   certificate directly with `TLS_KEY=key.pem TLS_CERT=cert.pem`.
3. If players reach it through a different domain than the page, add `ALLOWED_ORIGINS=your.domain`.
4. Open the https link in the Quest Browser and press **Enter VR**. Add it to your bookmarks.

## Getting an APK

A hosted page cannot be turned into an APK from inside this project. Once the game is on an https link you can
wrap it: create a Progressive Web App manifest and use PWABuilder (pwabuilder.com) or Bubblewrap to produce an
Android package, then sideload it with SideQuest or `adb install`. The Quest Browser link works without this.

## Controls (VR)

No thumbstick. Push your hands against floors, walls and objects to move; squeeze grip to hold on or grab,
trigger to use. Left X/Y opens the computer anywhere; right A waves; right B toggles ready.
The computer on the desk at spawn lets you play solo, create a room, join or leave with a code, and change
your name and colours.

## Security notes

Server is authoritative: it clamps every reported pose (arm length, head box, hand speed), validates every
message, rate-limits per connection and per IP, checks Origin, caps message size, strikes and drops abusers,
serves static files with path-traversal protection, and sends CSP and other security headers. It binds to
localhost unless you set HOST. Names are sanitised and room codes avoid look-alike characters. There are no
accounts yet, so nothing sensitive is stored; the profile lives in the browser's local storage.

## Roadmap

Coins and quests,
season pass, trading, level editor with validated map codes, replays, voice chat.
